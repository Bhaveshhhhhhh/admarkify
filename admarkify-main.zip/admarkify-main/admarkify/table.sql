-- Table: admarkify.channel_providers

-- DROP TABLE IF EXISTS admarkify.channel_providers;

CREATE TABLE IF NOT EXISTS admarkify.channel_providers
(
    id integer NOT NULL DEFAULT nextval('admarkify.channel_providers_id_seq'::regclass),
    code character varying(64) COLLATE pg_catalog."default" NOT NULL,
    name character varying(128) COLLATE pg_catalog."default" NOT NULL,
    channel character varying(32) COLLATE pg_catalog."default" NOT NULL,
    description text COLLATE pg_catalog."default",
    logo_url text COLLATE pg_catalog."default",
    credentials_schema jsonb NOT NULL DEFAULT '{}'::jsonb,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    providers_schema jsonb,
    main_providers character varying(128) COLLATE pg_catalog."default",
    end_point text COLLATE pg_catalog."default",
    CONSTRAINT channel_providers_pkey PRIMARY KEY (id),
    CONSTRAINT channel_providers_code_key UNIQUE (code),
    CONSTRAINT chk_provider_channel CHECK (channel::text = ANY (ARRAY['sms'::character varying::text, 'whatsapp'::character varying::text, 'email'::character varying::text, 'voice'::character varying::text, 'push'::character varying::text]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.channel_providers
    OWNER to postgres;
-- Index: idx_channel_providers_channel

-- DROP INDEX IF EXISTS admarkify.idx_channel_providers_channel;

CREATE INDEX IF NOT EXISTS idx_channel_providers_channel
    ON admarkify.channel_providers USING btree
    (channel COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_channel_providers_code

-- DROP INDEX IF EXISTS admarkify.idx_channel_providers_code;

CREATE INDEX IF NOT EXISTS idx_channel_providers_code
    ON admarkify.channel_providers USING btree
    (code COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    -- Table: admarkify.login_attempts

-- DROP TABLE IF EXISTS admarkify.login_attempts;

CREATE TABLE IF NOT EXISTS admarkify.login_attempts
(
    id bigint NOT NULL DEFAULT nextval('admarkify.login_attempts_id_seq'::regclass),
    email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    ip_address inet,
    success boolean NOT NULL DEFAULT false,
    failure_reason character varying(100) COLLATE pg_catalog."default",
    attempted_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT login_attempts_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.login_attempts
    OWNER to postgres;
-- Index: idx_login_attempts_email

-- DROP INDEX IF EXISTS admarkify.idx_login_attempts_email;

CREATE INDEX IF NOT EXISTS idx_login_attempts_email
    ON admarkify.login_attempts USING btree
    (email COLLATE pg_catalog."default" ASC NULLS LAST, attempted_at ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_login_attempts_ip

-- DROP INDEX IF EXISTS admarkify.idx_login_attempts_ip;

CREATE INDEX IF NOT EXISTS idx_login_attempts_ip
    ON admarkify.login_attempts USING btree
    (ip_address ASC NULLS LAST, attempted_at ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;

    -- Table: admarkify.org_provider_configs

-- DROP TABLE IF EXISTS admarkify.org_provider_configs;

CREATE TABLE IF NOT EXISTS admarkify.org_provider_configs
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL,
    provider_id integer NOT NULL,
    label character varying(128) COLLATE pg_catalog."default" NOT NULL,
    credentials jsonb NOT NULL DEFAULT '{}'::jsonb,
    settings jsonb NOT NULL DEFAULT '{}'::jsonb,
    is_default boolean NOT NULL DEFAULT false,
    is_active boolean NOT NULL DEFAULT true,
    created_by uuid NOT NULL,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT org_provider_configs_pkey PRIMARY KEY (id),
    CONSTRAINT org_provider_configs_created_by_fkey FOREIGN KEY (created_by)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT org_provider_configs_org_id_fkey FOREIGN KEY (org_id)
        REFERENCES admarkify.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT org_provider_configs_provider_id_fkey FOREIGN KEY (provider_id)
        REFERENCES admarkify.channel_providers (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.org_provider_configs
    OWNER to postgres;
-- Index: idx_org_providers_org

-- DROP INDEX IF EXISTS admarkify.idx_org_providers_org;

CREATE INDEX IF NOT EXISTS idx_org_providers_org
    ON admarkify.org_provider_configs USING btree
    (org_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_org_providers_provider

-- DROP INDEX IF EXISTS admarkify.idx_org_providers_provider;

CREATE INDEX IF NOT EXISTS idx_org_providers_provider
    ON admarkify.org_provider_configs USING btree
    (provider_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: uq_org_default_provider

-- DROP INDEX IF EXISTS admarkify.uq_org_default_provider;

CREATE UNIQUE INDEX IF NOT EXISTS uq_org_default_provider
    ON admarkify.org_provider_configs USING btree
    (org_id ASC NULLS LAST, provider_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default
    WHERE is_default = true;


    -- Table: admarkify.organization_members

-- DROP TABLE IF EXISTS admarkify.organization_members;

CREATE TABLE IF NOT EXISTS admarkify.organization_members
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role character varying(32) COLLATE pg_catalog."default" NOT NULL DEFAULT 'executive'::character varying,
    status character varying(32) COLLATE pg_catalog."default" NOT NULL DEFAULT 'invited'::character varying,
    invited_by uuid,
    joined_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT organization_members_pkey PRIMARY KEY (id),
    CONSTRAINT uq_org_member UNIQUE (org_id, user_id),
    CONSTRAINT organization_members_invited_by_fkey FOREIGN KEY (invited_by)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT organization_members_org_id_fkey FOREIGN KEY (org_id)
        REFERENCES admarkify.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT organization_members_user_id_fkey FOREIGN KEY (user_id)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT chk_member_role CHECK (role::text = ANY (ARRAY['admin'::character varying::text, 'manager'::character varying::text, 'lead'::character varying::text, 'executive'::character varying::text])),
    CONSTRAINT chk_member_status CHECK (status::text = ANY (ARRAY['active'::character varying::text, 'invited'::character varying::text, 'suspended'::character varying::text]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.organization_members
    OWNER to postgres;
-- Index: idx_members_org

-- DROP INDEX IF EXISTS admarkify.idx_members_org;

CREATE INDEX IF NOT EXISTS idx_members_org
    ON admarkify.organization_members USING btree
    (org_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_members_user

-- DROP INDEX IF EXISTS admarkify.idx_members_user;

CREATE INDEX IF NOT EXISTS idx_members_user
    ON admarkify.organization_members USING btree
    (user_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    -- Table: admarkify.organizations

-- DROP TABLE IF EXISTS admarkify.organizations;

CREATE TABLE IF NOT EXISTS admarkify.organizations
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    slug character varying(100) COLLATE pg_catalog."default" NOT NULL,
    plan_id integer NOT NULL DEFAULT 1,
    plan_expires_at timestamp with time zone,
    owner_email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    timezone character varying(64) COLLATE pg_catalog."default" NOT NULL DEFAULT 'UTC'::character varying,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT organizations_pkey PRIMARY KEY (id),
    CONSTRAINT organizations_slug_key UNIQUE (slug),
    CONSTRAINT organizations_plan_id_fkey FOREIGN KEY (plan_id)
        REFERENCES admarkify.subscription_plans (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.organizations
    OWNER to postgres;
-- Index: idx_orgs_slug

-- DROP INDEX IF EXISTS admarkify.idx_orgs_slug;

CREATE INDEX IF NOT EXISTS idx_orgs_slug
    ON admarkify.organizations USING btree
    (slug COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    -- Table: admarkify.subscription_plans

-- DROP TABLE IF EXISTS admarkify.subscription_plans;

CREATE TABLE IF NOT EXISTS admarkify.subscription_plans
(
    id integer NOT NULL DEFAULT nextval('admarkify.subscription_plans_id_seq'::regclass),
    name character varying(64) COLLATE pg_catalog."default" NOT NULL,
    plan_type character varying(32) COLLATE pg_catalog."default" NOT NULL,
    max_team_members integer DEFAULT 3,
    is_active boolean NOT NULL DEFAULT true,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    price integer,
    CONSTRAINT subscription_plans_pkey PRIMARY KEY (id),
    CONSTRAINT subscription_plans_name_key UNIQUE (name)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.subscription_plans
    OWNER to postgres;


    -- Table: admarkify.team_invitations

-- DROP TABLE IF EXISTS admarkify.team_invitations;

CREATE TABLE IF NOT EXISTS admarkify.team_invitations
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL,
    invited_by uuid NOT NULL,
    email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    role character varying(32) COLLATE pg_catalog."default" NOT NULL DEFAULT 'executive'::character varying,
    token_hash text COLLATE pg_catalog."default" NOT NULL,
    status character varying(32) COLLATE pg_catalog."default" NOT NULL DEFAULT 'pending'::character varying,
    expires_at timestamp with time zone NOT NULL DEFAULT (now() + '48:00:00'::interval),
    accepted_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT team_invitations_pkey PRIMARY KEY (id),
    CONSTRAINT team_invitations_token_hash_key UNIQUE (token_hash),
    CONSTRAINT team_invitations_invited_by_fkey FOREIGN KEY (invited_by)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT team_invitations_org_id_fkey FOREIGN KEY (org_id)
        REFERENCES admarkify.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT chk_invite_role CHECK (role::text = ANY (ARRAY['admin'::character varying::text, 'manager'::character varying::text, 'lead'::character varying::text, 'executive'::character varying::text])),
    CONSTRAINT chk_invite_status CHECK (status::text = ANY (ARRAY['pending'::character varying::text, 'accepted'::character varying::text, 'expired'::character varying::text, 'cancelled'::character varying::text]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.team_invitations
    OWNER to postgres;
-- Index: idx_invites_email

-- DROP INDEX IF EXISTS admarkify.idx_invites_email;

CREATE INDEX IF NOT EXISTS idx_invites_email
    ON admarkify.team_invitations USING btree
    (email COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_invites_org

-- DROP INDEX IF EXISTS admarkify.idx_invites_org;

CREATE INDEX IF NOT EXISTS idx_invites_org
    ON admarkify.team_invitations USING btree
    (org_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_invites_token

-- DROP INDEX IF EXISTS admarkify.idx_invites_token;

CREATE INDEX IF NOT EXISTS idx_invites_token
    ON admarkify.team_invitations USING btree
    (token_hash COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;

    -- Table: admarkify.templates

-- DROP TABLE IF EXISTS admarkify.templates;

CREATE TABLE IF NOT EXISTS admarkify.templates
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    org_id uuid NOT NULL,
    provider_config_id uuid,
    name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    channel character varying(32) COLLATE pg_catalog."default" NOT NULL,
    external_template_name character varying(255) COLLATE pg_catalog."default",
    subject text COLLATE pg_catalog."default",
    body text COLLATE pg_catalog."default" NOT NULL,
    variables jsonb NOT NULL DEFAULT '[]'::jsonb,
    addonjson jsonb NOT NULL DEFAULT '{}'::jsonb,
    status character varying(32) COLLATE pg_catalog."default" NOT NULL DEFAULT 'draft'::character varying,
    is_active boolean NOT NULL DEFAULT true,
    created_by uuid NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    provider_response jsonb,
    provider_request jsonb,
    provider_template_id text COLLATE pg_catalog."default",
    template_slug text COLLATE pg_catalog."default",
    editable boolean DEFAULT false,
    CONSTRAINT templates_pkey PRIMARY KEY (id),
    CONSTRAINT uq_template_name_per_org UNIQUE (org_id, channel, name),
    CONSTRAINT templates_created_by_fkey FOREIGN KEY (created_by)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT templates_org_id_fkey FOREIGN KEY (org_id)
        REFERENCES admarkify.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT templates_provider_config_id_fkey FOREIGN KEY (provider_config_id)
        REFERENCES admarkify.org_provider_configs (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE SET NULL,
    CONSTRAINT templates_updated_by_fkey FOREIGN KEY (updated_by)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT chk_template_channel CHECK (channel::text = ANY (ARRAY['sms'::character varying::text, 'whatsapp'::character varying::text, 'email'::character varying::text, 'voice'::character varying::text, 'push'::character varying::text])),
    CONSTRAINT chk_template_status CHECK (status::text = ANY (ARRAY['draft'::character varying, 'pending'::character varying, 'failed'::character varying, 'active'::character varying, 'archived'::character varying, 'published'::character varying]::text[]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.templates
    OWNER to postgres;
-- Index: idx_templates_channel

-- DROP INDEX IF EXISTS admarkify.idx_templates_channel;

CREATE INDEX IF NOT EXISTS idx_templates_channel
    ON admarkify.templates USING btree
    (org_id ASC NULLS LAST, channel COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_templates_org

-- DROP INDEX IF EXISTS admarkify.idx_templates_org;

CREATE INDEX IF NOT EXISTS idx_templates_org
    ON admarkify.templates USING btree
    (org_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_templates_status

-- DROP INDEX IF EXISTS admarkify.idx_templates_status;

CREATE INDEX IF NOT EXISTS idx_templates_status
    ON admarkify.templates USING btree
    (org_id ASC NULLS LAST, status COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    -- Table: admarkify.user_otps

-- DROP TABLE IF EXISTS admarkify.user_otps;

CREATE TABLE IF NOT EXISTS admarkify.user_otps
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    otp_code character varying(6) COLLATE pg_catalog."default" NOT NULL,
    otp_type character varying(20) COLLATE pg_catalog."default" NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    is_used boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    CONSTRAINT user_otps_pkey PRIMARY KEY (id)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.user_otps
    OWNER to postgres;



    -- Table: admarkify.user_sessions

-- DROP TABLE IF EXISTS admarkify.user_sessions;

CREATE TABLE IF NOT EXISTS admarkify.user_sessions
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    user_id uuid NOT NULL,
    org_id uuid,
    token_hash text COLLATE pg_catalog."default" NOT NULL,
    role character varying(32) COLLATE pg_catalog."default" NOT NULL,
    ip_address inet,
    user_agent text COLLATE pg_catalog."default",
    is_active boolean NOT NULL DEFAULT true,
    expires_at timestamp with time zone NOT NULL DEFAULT (now() + '7 days'::interval),
    last_used_at timestamp with time zone NOT NULL DEFAULT now(),
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    CONSTRAINT user_sessions_pkey PRIMARY KEY (id),
    CONSTRAINT user_sessions_token_hash_key UNIQUE (token_hash),
    CONSTRAINT user_sessions_org_id_fkey FOREIGN KEY (org_id)
        REFERENCES admarkify.organizations (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT user_sessions_user_id_fkey FOREIGN KEY (user_id)
        REFERENCES admarkify.users (id) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE CASCADE,
    CONSTRAINT chk_session_role CHECK (role::text = ANY (ARRAY['admin'::character varying::text, 'manager'::character varying::text, 'lead'::character varying::text, 'executive'::character varying::text]))
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.user_sessions
    OWNER to postgres;
-- Index: idx_sessions_active

-- DROP INDEX IF EXISTS admarkify.idx_sessions_active;

CREATE INDEX IF NOT EXISTS idx_sessions_active
    ON admarkify.user_sessions USING btree
    (is_active ASC NULLS LAST, expires_at ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_sessions_org

-- DROP INDEX IF EXISTS admarkify.idx_sessions_org;

CREATE INDEX IF NOT EXISTS idx_sessions_org
    ON admarkify.user_sessions USING btree
    (org_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_sessions_token

-- DROP INDEX IF EXISTS admarkify.idx_sessions_token;

CREATE INDEX IF NOT EXISTS idx_sessions_token
    ON admarkify.user_sessions USING btree
    (token_hash COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;
-- Index: idx_sessions_user

-- DROP INDEX IF EXISTS admarkify.idx_sessions_user;

CREATE INDEX IF NOT EXISTS idx_sessions_user
    ON admarkify.user_sessions USING btree
    (user_id ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    -- Table: admarkify.users

-- DROP TABLE IF EXISTS admarkify.users;

CREATE TABLE IF NOT EXISTS admarkify.users
(
    id uuid NOT NULL DEFAULT gen_random_uuid(),
    email character varying(255) COLLATE pg_catalog."default" NOT NULL,
    password_hash text COLLATE pg_catalog."default" NOT NULL,
    full_name character varying(255) COLLATE pg_catalog."default" NOT NULL,
    avatar_url text COLLATE pg_catalog."default",
    is_verified boolean NOT NULL DEFAULT false,
    is_active boolean NOT NULL DEFAULT true,
    last_login_at timestamp with time zone,
    created_at timestamp with time zone NOT NULL DEFAULT now(),
    updated_at timestamp with time zone NOT NULL DEFAULT now(),
    mobile character varying(15) COLLATE pg_catalog."default",
    is_email_verified boolean DEFAULT false,
    is_mobile_verified boolean DEFAULT false,
    CONSTRAINT users_pkey PRIMARY KEY (id),
    CONSTRAINT users_email_key UNIQUE (email)
)

TABLESPACE pg_default;

ALTER TABLE IF EXISTS admarkify.users
    OWNER to postgres;
-- Index: idx_users_email

-- DROP INDEX IF EXISTS admarkify.idx_users_email;

CREATE INDEX IF NOT EXISTS idx_users_email
    ON admarkify.users USING btree
    (email COLLATE pg_catalog."default" ASC NULLS LAST)
    WITH (fillfactor=100, deduplicate_items=True)
    TABLESPACE pg_default;


    