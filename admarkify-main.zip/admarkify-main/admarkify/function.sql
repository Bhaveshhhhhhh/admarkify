-- FUNCTION: admarkify.fn_accept_invite(text, character varying, text, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_accept_invite(text, character varying, text, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_accept_invite(
	p_raw_token text,
	p_full_name character varying DEFAULT NULL::character varying,
	p_password text DEFAULT NULL::text,
	p_mobile character varying DEFAULT NULL::character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_token_hash  TEXT;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_user        admarkify.users%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_email_otp   TEXT;
    v_mobile_otp  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    -- 🔍 Validate invite — do NOT consume yet
    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: token not found or already used';
    END IF;

    IF v_invite.expires_at < NOW() THEN
        UPDATE admarkify.team_invitations
        SET status = 'expired', updated_at = NOW()
        WHERE id = v_invite.id;
        RAISE EXCEPTION 'INVITE_EXPIRED: expired at %', v_invite.expires_at;
    END IF;

    -- 🔍 Get org
    SELECT * INTO v_org FROM admarkify.organizations WHERE id = v_invite.org_id;

    -- 🔍 Find user by invite email
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = v_invite.email;

    IF FOUND AND (v_user.is_email_verified AND v_user.is_mobile_verified) THEN

        -- ════════════════════════════════════════════════════
        -- ✅ EXISTING + FULLY VERIFIED USER
        -- Skip OTP → check limit, consume invite,
        --            activate membership, create session
        -- ════════════════════════════════════════════════════

        SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

        -- 🚫 Check seat limit before activating membership
        PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

        -- Consume invite
        UPDATE admarkify.team_invitations
        SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
        WHERE id = v_invite.id;

        -- Activate membership
        INSERT INTO admarkify.organization_members
            (org_id, user_id, role, status, invited_by, joined_at)
        VALUES
            (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
        ON CONFLICT (org_id, user_id) DO UPDATE
            SET role       = EXCLUDED.role,
                status     = 'active',
                joined_at  = NOW(),
                updated_at = NOW()
        RETURNING * INTO v_member;

        -- Create session
        v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
        v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

        INSERT INTO admarkify.user_sessions
            (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
        VALUES
            (v_user.id, v_org.id, v_token_hash2, v_member.role,
             p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
        RETURNING id INTO v_session_id;

        UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;

        RETURN jsonb_build_object(
            'is_new_user', FALSE,
            'raw_token',   v_raw_token,
            'session_id',  v_session_id,
            'expires_at',  NOW() + INTERVAL '7 days',
            'user', jsonb_build_object(
                'id',          v_user.id,
                'email',       v_user.email,
                'full_name',   v_user.full_name,
                'avatar_url',  v_user.avatar_url,
                'is_verified', TRUE
            ),
            'org', jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            ),
            'membership', jsonb_build_object(
                'role',      v_member.role,
                'status',    'active',
                'joined_at', v_member.joined_at
            ),
            'plan', jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
        );

    ELSE

        -- ════════════════════════════════════════════════════
        -- 🆕 NEW USER  ── or ──  EXISTING BUT UNVERIFIED USER
        -- Validate fields, create/update user, send OTPs
        -- Limit check deferred to fn_verify_invite_otp
        -- ════════════════════════════════════════════════════

        -- 🚫 Validate required fields
        IF p_full_name IS NULL OR TRIM(p_full_name) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: full_name is required';
        END IF;

        IF p_password IS NULL OR TRIM(p_password) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: password is required';
        END IF;

        IF p_mobile IS NULL OR TRIM(p_mobile) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: mobile is required';
        END IF;

        IF NOT FOUND THEN
            -- Brand new user — create record (inactive until verified)
            INSERT INTO admarkify.users (email, password_hash, full_name, mobile, is_active)
            VALUES (
                v_invite.email,
                public.crypt(p_password, public.gen_salt('bf', 10)),
                p_full_name,
                p_mobile,
                FALSE
            )
            RETURNING * INTO v_user;

        ELSE
            -- Exists but unverified — refresh details + reset verification flags
            UPDATE admarkify.users
            SET password_hash      = public.crypt(p_password, public.gen_salt('bf', 10)),
                full_name          = p_full_name,
                mobile             = p_mobile,
                is_email_verified  = FALSE,
                is_mobile_verified = FALSE,
                is_active          = FALSE,
                updated_at         = NOW()
            WHERE id = v_user.id
            RETURNING * INTO v_user;
        END IF;

        -- 🔢 Expire any leftover invite OTPs
        UPDATE admarkify.user_otps
        SET is_used = TRUE
        WHERE user_id = v_user.id
          AND otp_type IN ('invite_email', 'invite_mobile')
          AND is_used = FALSE;

        -- 🔢 Generate fresh OTPs
        v_email_otp  := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');
        v_mobile_otp := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

        INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
        VALUES
            (v_user.id, v_email_otp,  'invite_email',  NOW() + INTERVAL '10 minutes'),
            (v_user.id, v_mobile_otp, 'invite_mobile', NOW() + INTERVAL '10 minutes');

        RETURN jsonb_build_object(
            'is_new_user',   TRUE,
            'user_id',       v_user.id,
            'email',         v_user.email,
            'email_masked',  CONCAT(
                                 LEFT(v_user.email, 2),
                                 '***@',
                                 SPLIT_PART(v_user.email, '@', 2)
                             ),
            'mobile',        v_user.mobile,
            'mobile_masked', CONCAT('***', RIGHT(v_user.mobile, 3)),
            'email_otp',     v_email_otp,
            'mobile_otp',    v_mobile_otp
        );

    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_accept_invite(text, character varying, text, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_add_org_provider(uuid, uuid, character varying, character varying, jsonb, jsonb)

-- DROP FUNCTION IF EXISTS admarkify.fn_add_org_provider(uuid, uuid, character varying, character varying, jsonb, jsonb);

CREATE OR REPLACE FUNCTION admarkify.fn_add_org_provider(
	p_org_id uuid,
	p_actor_id uuid,
	p_provider_code character varying,
	p_label character varying,
	p_credentials jsonb,
	p_settings jsonb DEFAULT '{}'::jsonb)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_provider        admarkify.channel_providers%ROWTYPE;
    v_actor_role      VARCHAR;
    v_config_id       UUID;
    v_is_default      BOOLEAN;
    v_existing_count  INT;

    -- schema validation
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    jsonb;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Actor must be admin or manager
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id   = p_org_id
      AND user_id  = p_actor_id
      AND status   = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin', 'manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can add providers';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Load provider from master list
    -- ----------------------------------------------------------------
    SELECT * INTO v_provider
    FROM admarkify.channel_providers
    WHERE code      = p_provider_code
      AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'PROVIDER_NOT_FOUND: "%" is not a supported provider', p_provider_code;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Validate p_credentials against credentials_schema
    --
    --    Supported schema types : "string", "number", "boolean"
    --
    --    Rules per field:
    --      • field must be present and non-null          → MISSING
    --      • string  → jsonb type must be string,
    --                   value must not be empty/whitespace,
    --                   value must not be a literal
    --                   placeholder ("string","number","boolean","null")
    --      • number  → jsonb type must be number
    --      • boolean → jsonb type must be boolean
    --
    --    All errors are collected first, then raised together.
    -- ----------------------------------------------------------------
    IF v_provider.credentials_schema IS NOT NULL
       AND v_provider.credentials_schema <> '{}'::jsonb
    THEN
        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'       -- unwrap quoted string value
            FROM jsonb_each(v_provider.credentials_schema)
        LOOP
            v_actual_value := p_credentials -> v_field_name;

            -- 3a) field must exist and not be JSON null
            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;                    -- no point type-checking a missing field
            END IF;

            -- 3b) type + value check
            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}')) IN ('string','number','boolean','null')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE
                    -- unknown schema type → skip silently
                    NULL;

            END CASE;
        END LOOP;

        -- 3c) raise ONE combined error listing every problem
        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_CREDENTIALS: provider "%" schema validation failed.%s%s',
                p_provider_code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Auto-default if no active config exists yet for this channel
    -- ----------------------------------------------------------------
    SELECT COUNT(*) INTO v_existing_count
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers    cp  ON cp.id = opc.provider_id
    WHERE opc.org_id    = p_org_id
      AND cp.channel    = v_provider.channel
      AND opc.is_active = TRUE;

    v_is_default := (v_existing_count = 0);

    -- ----------------------------------------------------------------
    -- 5) Insert
    -- ----------------------------------------------------------------
    INSERT INTO admarkify.org_provider_configs
        (org_id, provider_id, label, credentials, settings, is_default, created_by)
    VALUES
        (p_org_id, v_provider.id, p_label, p_credentials, p_settings,
         v_is_default, p_actor_id)
    RETURNING id INTO v_config_id;

    -- ----------------------------------------------------------------
    -- 6) Return summary
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'config_id',  v_config_id,
        'provider',   v_provider.code,
        'channel',    v_provider.channel,
        'label',      p_label,
        'is_default', v_is_default
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_add_org_provider(uuid, uuid, character varying, character varying, jsonb, jsonb)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_archive_template(uuid, uuid, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_archive_template(uuid, uuid, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_archive_template(
	p_org_id uuid,
	p_actor_id uuid,
	p_template_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin/manager can archive templates';
    END IF;

    UPDATE admarkify.templates
    SET status     = 'archived',
        is_active  = FALSE,
        updated_by = p_actor_id,
        updated_at = NOW()
    WHERE id = p_template_id AND org_id = p_org_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND';
    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_archive_template(uuid, uuid, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_change_email(character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_change_email(character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_change_email(
	p_email character varying,
	p_otp character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user      admarkify.users%ROWTYPE;
    v_otp       admarkify.user_otps%ROWTYPE;
    v_new_email TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_email'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new email from metadata
    v_new_email := v_otp.metadata ->> 'new_email';

    IF v_new_email IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing email metadata';
    END IF;

    -- Double-check new email not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = v_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', v_new_email;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update email
    UPDATE admarkify.users
    SET email             = v_new_email,
        is_email_verified = TRUE,
        updated_at        = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',   'Email changed successfully',
        'old_email', p_email,
        'new_email', v_new_email
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_change_email(character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_change_mobile(character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_change_mobile(character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_change_mobile(
	p_email character varying,
	p_otp character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_otp        admarkify.user_otps%ROWTYPE;
    v_new_mobile TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_mobile'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new mobile from metadata
    v_new_mobile := v_otp.metadata ->> 'new_mobile';

    IF v_new_mobile IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing mobile metadata';
    END IF;

    -- Double-check not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = v_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', v_new_mobile;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update mobile
    UPDATE admarkify.users
    SET mobile             = v_new_mobile,
        is_mobile_verified = TRUE,
        updated_at         = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'Mobile changed successfully',
        'email',      v_user.email,
        'new_mobile', v_new_mobile
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_change_mobile(character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_change_password(character varying, character varying, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_change_password(character varying, character varying, text);

CREATE OR REPLACE FUNCTION admarkify.fn_change_password(
	p_email character varying,
	p_otp character varying,
	p_new_password text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user admarkify.users%ROWTYPE;
    v_otp  admarkify.user_otps%ROWTYPE;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_password'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update password
    UPDATE admarkify.users
    SET password_hash = public.crypt(p_new_password, public.gen_salt('bf', 10)),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- Revoke all sessions for security
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = v_user.id AND is_active = TRUE;

    RETURN jsonb_build_object(
        'message',          'Password changed successfully',
        'email',            v_user.email,
        'sessions_revoked', TRUE
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_change_password(character varying, character varying, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_check_team_member_limit(uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_check_team_member_limit(uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_check_team_member_limit(
	p_org_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_org   admarkify.organizations%ROWTYPE;
    v_plan  admarkify.subscription_plans%ROWTYPE;
    v_count INT;
BEGIN
    SELECT * INTO v_org
    FROM admarkify.organizations WHERE id = p_org_id;

    IF NOT FOUND          THEN RAISE EXCEPTION 'ORG_NOT_FOUND: %', p_org_id; END IF;
    IF NOT v_org.is_active THEN RAISE EXCEPTION 'ORG_INACTIVE';               END IF;

    IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
        RAISE EXCEPTION 'PLAN_EXPIRED: expired at %', v_org.plan_expires_at;
    END IF;

    SELECT * INTO v_plan
    FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- NULL max_team_members = unlimited (Pro)
    IF v_plan.max_team_members IS NULL THEN RETURN; END IF;

    SELECT COUNT(*) INTO v_count
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND status = 'active';

    IF v_count >= v_plan.max_team_members THEN
        RAISE EXCEPTION
            'PLAN_LIMIT_TEAM_MEMBERS: plan "%" allows max % members (currently %)',
            v_plan.name, v_plan.max_team_members, v_count;
    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_check_team_member_limit(uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_cleanup_expired_invites()

-- DROP FUNCTION IF EXISTS admarkify.fn_cleanup_expired_invites();

CREATE OR REPLACE FUNCTION admarkify.fn_cleanup_expired_invites(
	)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_n INT;
BEGIN
    UPDATE admarkify.team_invitations
    SET status = 'expired', updated_at = NOW()
    WHERE status = 'pending' AND expires_at < NOW();

    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_cleanup_expired_invites()
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_cleanup_expired_sessions()

-- DROP FUNCTION IF EXISTS admarkify.fn_cleanup_expired_sessions();

CREATE OR REPLACE FUNCTION admarkify.fn_cleanup_expired_sessions(
	)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_n INT;
BEGIN
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE is_active = TRUE AND expires_at < NOW();

    DELETE FROM admarkify.user_sessions
    WHERE is_active = FALSE
      AND expires_at < NOW() - INTERVAL '30 days';

    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_cleanup_expired_sessions()
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_create_organization(uuid, character varying, character varying, integer, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_create_organization(uuid, character varying, character varying, integer, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_create_organization(
	p_owner_user_id uuid,
	p_org_name character varying,
	p_slug character varying,
	p_plan_id integer DEFAULT 1,
	p_timezone character varying DEFAULT 'UTC'::character varying)
    RETURNS uuid
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_org_id     UUID;
    v_email      VARCHAR;
    v_session_id UUID;
BEGIN
    -- Normalize slug
    p_slug := LOWER(TRIM(p_slug));

    -- Check slug uniqueness
    IF EXISTS (
        SELECT 1 FROM admarkify.organizations WHERE slug = p_slug
    ) THEN
        RAISE EXCEPTION 'SLUG_TAKEN: "%" is already in use', p_slug;
    END IF;

    -- Validate plan
    IF NOT EXISTS (
        SELECT 1 FROM admarkify.subscription_plans
        WHERE id = p_plan_id AND is_active = TRUE
    ) THEN
        RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=% is invalid or inactive', p_plan_id;
    END IF;

    -- Validate user
    SELECT email INTO v_email
    FROM admarkify.users
    WHERE id = p_owner_user_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: user_id=% does not exist', p_owner_user_id;
    END IF;

    -- Create organization
    INSERT INTO admarkify.organizations (name, slug, plan_id, owner_email, timezone)
    VALUES (p_org_name, p_slug, p_plan_id, v_email, p_timezone)
    RETURNING id INTO v_org_id;

    -- Add owner as admin
    INSERT INTO admarkify.organization_members (
        org_id, user_id, role, status, joined_at
    )
    VALUES (
        v_org_id, p_owner_user_id, 'admin', 'active', NOW()
    );

    -- ✅ Update latest active session (IMPORTANT PART)
    UPDATE admarkify.user_sessions
    SET org_id = v_org_id,
        role   = 'admin'
    WHERE id = (
        SELECT id
        FROM admarkify.user_sessions
        WHERE user_id = p_owner_user_id
          AND expires_at > NOW()
        ORDER BY created_at DESC
        LIMIT 1
    )
    RETURNING id INTO v_session_id;

    -- Optional: if no session found, do nothing (safe fallback)

    RETURN v_org_id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_create_organization(uuid, character varying, character varying, integer, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_create_template(uuid, uuid, character varying, character varying, uuid, character varying, jsonb, jsonb)

-- DROP FUNCTION IF EXISTS admarkify.fn_create_template(uuid, uuid, character varying, character varying, uuid, character varying, jsonb, jsonb);

CREATE OR REPLACE FUNCTION admarkify.fn_create_template(
	p_org_id uuid,
	p_actor_id uuid,
	p_name character varying,
	p_channel character varying,
	p_provider_config_id uuid DEFAULT NULL::uuid,
	p_external_template_name character varying DEFAULT NULL::character varying,
	p_provider_payload jsonb DEFAULT NULL::jsonb,
	p_variables jsonb DEFAULT NULL::jsonb)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role      VARCHAR;
    v_template_id     UUID;
    v_variables       JSONB;
    v_provider        admarkify.channel_providers%ROWTYPE;
    v_body            TEXT;
    v_subject         TEXT;

    -- schema validation
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    JSONB;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Permission check
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can create templates';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Validate channel
    -- ----------------------------------------------------------------
    IF p_channel NOT IN ('sms','whatsapp','email','voice','push') THEN
        RAISE EXCEPTION 'INVALID_CHANNEL: "%"', p_channel;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Validate provider config + load provider master row
    -- ----------------------------------------------------------------
    IF p_provider_config_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM admarkify.org_provider_configs
            WHERE id       = p_provider_config_id
              AND org_id   = p_org_id
              AND is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config does not belong to this org';
        END IF;

        SELECT cp.* INTO v_provider
        FROM admarkify.org_provider_configs opc
        JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
        WHERE opc.id = p_provider_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Validate p_provider_payload against providers_schema
    --    and extract body/subject dynamically from payload
    -- ----------------------------------------------------------------
    IF v_provider.providers_schema IS NOT NULL
       AND v_provider.providers_schema <> '{}'::jsonb
    THEN
        IF p_provider_payload IS NULL THEN
            RAISE EXCEPTION
                'PROVIDER_PAYLOAD_REQUIRED: provider "%" requires a payload with fields: %',
                v_provider.code,
                (SELECT string_agg(key, ', ')
                 FROM jsonb_each_text(v_provider.providers_schema));
        END IF;

        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'
            FROM jsonb_each(v_provider.providers_schema)
        LOOP
            v_actual_value := p_provider_payload -> v_field_name;

            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;
            END IF;

            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}'))
                              IN ('string','number','boolean','null','html','slug_string')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'html' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name || ': expected non-empty HTML string');
                    ELSE
                        v_body := v_actual_value #>> '{}';
                    END IF;

                WHEN 'slug_string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR (v_actual_value #>> '{}') !~ '^[a-zA-Z0-9_-]+$'
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a slug (letters, digits, _ or - only), received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE
                    NULL;

            END CASE;

            IF v_field_name = 'subject'
               AND jsonb_typeof(v_actual_value) = 'string'
               AND TRIM(v_actual_value #>> '{}') <> ''
            THEN
                v_subject := v_actual_value #>> '{}';
            END IF;

        END LOOP;

        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_PROVIDER_PAYLOAD: provider "%" payload validation failed.%s%s',
                v_provider.code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Email requires subject
    -- ----------------------------------------------------------------
    IF p_channel = 'email' AND (v_subject IS NULL OR TRIM(v_subject) = '') THEN
        RAISE EXCEPTION 'SUBJECT_REQUIRED: email templates must have a subject field in payload';
    END IF;

    -- ----------------------------------------------------------------
    -- 6) Use caller-supplied variables (default to empty array)
    -- ----------------------------------------------------------------
    v_variables := COALESCE(p_variables, '[]'::jsonb);

    -- ----------------------------------------------------------------
    -- 7) Insert template
    -- ----------------------------------------------------------------
    INSERT INTO admarkify.templates
        (org_id, provider_config_id, name, channel, subject, body,
         variables, external_template_name, provider_request,
         status, created_by)
    VALUES
        (p_org_id, p_provider_config_id, TRIM(p_name), p_channel,
         v_subject, v_body, v_variables, p_external_template_name,
         p_provider_payload, 'draft', p_actor_id)
    RETURNING id INTO v_template_id;

    -- ----------------------------------------------------------------
    -- 8) Return
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'template_id',      v_template_id,
        'name',             TRIM(p_name),
        'channel',          p_channel,
        'status',           'draft',
        'variables',        v_variables,
        'end_point',        v_provider.end_point,
        'provider_payload', p_provider_payload
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_create_template(uuid, uuid, character varying, character varying, uuid, character varying, jsonb, jsonb)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_create_user_only(character varying, text, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_create_user_only(character varying, text, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_create_user_only(
	p_email character varying,
	p_password text,
	p_full_name character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS uuid
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_user_id    UUID;
BEGIN
    p_email := LOWER(TRIM(p_email));

    -- Check email not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_email) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_email;
    END IF;

    -- Create user only
    INSERT INTO admarkify.users (email, password_hash, full_name, is_verified)
    VALUES (
        p_email,
        public.crypt(p_password, public.gen_salt('bf', 10)),
        p_full_name,
        TRUE  -- auto-verify since they came via invite link
    )
    RETURNING * INTO v_user;

    RETURN v_user.id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_create_user_only(character varying, text, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_all_channel_providers(character varying, character varying, integer)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_all_channel_providers(character varying, character varying, integer);

CREATE OR REPLACE FUNCTION admarkify.fn_get_all_channel_providers(
	p_channel character varying DEFAULT NULL::character varying,
	p_code character varying DEFAULT NULL::character varying,
	p_id integer DEFAULT NULL::integer)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'id',                 id,
            'code',               code,
            'name',               name,
            'main_providers',               main_providers,
            'channel',            channel,
            'description',        description,
            'logo_url',           logo_url,
            'credentials_schema', credentials_schema,
            'providers_schema', providers_schema,
            'is_active',          is_active,
            'created_at',         created_at
        )
        ORDER BY channel, name
    )
    INTO v_result
    FROM admarkify.channel_providers
    WHERE is_active = TRUE
      AND (p_channel IS NULL OR channel = p_channel)
      AND (p_code    IS NULL OR code    = p_code)
      AND (p_id      IS NULL OR id      = p_id);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_all_channel_providers(character varying, character varying, integer)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_all_plans(boolean)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_all_plans(boolean);

CREATE OR REPLACE FUNCTION admarkify.fn_get_all_plans(
	p_only_active boolean DEFAULT true)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN

    RETURN (
        SELECT COALESCE(jsonb_agg(row_data), '[]'::jsonb)
        FROM (
            SELECT
                sp.id,
                sp.name,
                sp.plan_type,
                sp.price,
                sp.max_team_members,
                sp.is_active,
                sp.created_at
            FROM admarkify.subscription_plans sp
            WHERE
                (p_only_active IS FALSE OR sp.is_active = TRUE)
            ORDER BY sp.price ASC NULLS FIRST
        ) row_data
    );

END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_all_plans(boolean)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_org_members(uuid, character varying, character varying, character varying, integer, integer)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_org_members(uuid, character varying, character varying, character varying, integer, integer);

CREATE OR REPLACE FUNCTION admarkify.fn_get_org_members(
	p_org_id uuid,
	p_status character varying DEFAULT NULL::character varying,
	p_role character varying DEFAULT NULL::character varying,
	p_search character varying DEFAULT NULL::character varying,
	p_page integer DEFAULT 1,
	p_page_size integer DEFAULT 10)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_result     JSONB;
    v_total      INT;
    v_offset     INT;
BEGIN
    -- Validate org exists
    IF NOT EXISTS (SELECT 1 FROM admarkify.organizations WHERE id = p_org_id) THEN
        RAISE EXCEPTION 'ORG_NOT_FOUND: organization does not exist';
    END IF;

    v_offset := (GREATEST(p_page, 1) - 1) * GREATEST(p_page_size, 1);

    -- Total count
    SELECT COUNT(*) INTO v_total
    FROM admarkify.organization_members om
    JOIN admarkify.users u ON u.id = om.user_id
    WHERE om.org_id = p_org_id
      AND (p_status IS NULL OR om.status = p_status)
      AND (p_role   IS NULL OR om.role   = p_role)
      AND (
            p_search IS NULL
            OR u.full_name ILIKE '%' || p_search || '%'
            OR u.email     ILIKE '%' || p_search || '%'
          );

    -- Paged result
    SELECT jsonb_agg(
        jsonb_build_object(
            'member_id',  om.id,
            'user_id',    u.id,
            'full_name',  u.full_name,
            'email',      u.email,
            'avatar_url', u.avatar_url,
            'role',       om.role,
            'status',     om.status,
            'joined_at',  om.joined_at,
            'invited_by', om.invited_by,
            'created_at', om.created_at
        )
        ORDER BY om.joined_at DESC NULLS LAST
    )
    INTO v_result
    FROM admarkify.organization_members om
    JOIN admarkify.users u ON u.id = om.user_id
    WHERE om.org_id = p_org_id
      AND (p_status IS NULL OR om.status = p_status)
      AND (p_role   IS NULL OR om.role   = p_role)
      AND (
            p_search IS NULL
            OR u.full_name ILIKE '%' || p_search || '%'
            OR u.email     ILIKE '%' || p_search || '%'
          )
    LIMIT  p_page_size
    OFFSET v_offset;

    RETURN jsonb_build_object(
        'members',    COALESCE(v_result, '[]'::JSONB),
        'pagination', jsonb_build_object(
            'total',       v_total,
            'page',        p_page,
            'page_size',   p_page_size,
            'total_pages', CEIL(v_total::FLOAT / GREATEST(p_page_size, 1))
        )
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_org_members(uuid, character varying, character varying, character varying, integer, integer)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_org_providers(uuid, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_org_providers(uuid, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_get_org_providers(
	p_org_id uuid,
	p_channel character varying DEFAULT NULL::character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'config_id',    opc.id,
            'label',        opc.label,
            'provider_code',cp.code,
            'provider_name',cp.name,
            'channel',      cp.channel,
            'is_default',   opc.is_default,
            'is_active',    opc.is_active,
            'settings',     opc.settings,
            'providers_schema',     cp.providers_schema,
            'credentials',     opc.credentials,
            'created_at',   opc.created_at
            -- Note: credentials intentionally excluded from read response
        )
        ORDER BY cp.channel, opc.is_default DESC, opc.created_at
    )
    INTO v_result
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.org_id    = p_org_id
      AND opc.is_active = TRUE
      AND (p_channel IS NULL OR cp.channel = p_channel);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_org_providers(uuid, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_organization_details(uuid, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_organization_details(uuid, text);

CREATE OR REPLACE FUNCTION admarkify.fn_get_organization_details(
	p_org_id uuid DEFAULT NULL::uuid,
	p_slug text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_result JSONB;
BEGIN

    SELECT jsonb_build_object(
        'id', o.id,
        'name', o.name,
        'slug', o.slug,
        'owner_email', o.owner_email,
        'timezone', o.timezone,
        'is_active', o.is_active,
        'created_at', o.created_at,

        'plan', jsonb_build_object(
            'id', sp.id,
            'name', sp.name,
            'plan_type', sp.plan_type,
            'price', sp.price,
            'max_team_members', sp.max_team_members,
            'is_active', sp.is_active
        )
    )
    INTO v_result
    FROM admarkify.organizations o
    JOIN admarkify.subscription_plans sp
        ON sp.id = o.plan_id
    WHERE
        (p_org_id IS NOT NULL AND o.id = p_org_id)
        OR
        (p_slug IS NOT NULL AND LOWER(o.slug) = LOWER(p_slug))
    LIMIT 1;

    RETURN COALESCE(v_result, '{}'::jsonb);

END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_organization_details(uuid, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_provider_config(uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_provider_config(uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_get_provider_config(
	p_config_id uuid)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_result jsonb;
BEGIN
    SELECT jsonb_build_object(
        -- ── org_provider_configs fields ──────────────────────────
        'config_id',         opc.id,
        'org_id',            opc.org_id,
        'label',             opc.label,
        'credentials',       opc.credentials,
        'settings',          opc.settings,
        'is_default',        opc.is_default,
        'is_active',         opc.is_active,
        'created_by',        opc.created_by,
        'created_at',        opc.created_at,
        'updated_at',        opc.updated_at,
        'providers_schema',        cp.providers_schema,

        -- ── channel_providers fields ─────────────────────────────
        'provider', jsonb_build_object(
            'provider_id',         cp.id,
            'code',                cp.code,
            'name',                cp.name,
            'channel',             cp.channel,
            'description',         cp.description,
            'logo_url',            cp.logo_url,
            'credentials_schema',  cp.credentials_schema,
            'providers_schema',    cp.providers_schema,
            'main_providers',      cp.main_providers,
            'end_point',           cp.end_point,
            'is_active',           cp.is_active,
            'created_at',          cp.created_at
        )
    )
    INTO v_result
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
    WHERE opc.id = p_config_id;

    IF v_result IS NULL THEN
        RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config "%" does not exist', p_config_id;
    END IF;

    RETURN v_result;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_provider_config(uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_session_by_token(text)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_session_by_token(text);

CREATE OR REPLACE FUNCTION admarkify.fn_get_session_by_token(
	p_raw_token text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_token_hash TEXT;

    v_session    admarkify.user_sessions%ROWTYPE;
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
BEGIN

    ------------------------------------------------------------
    -- 1️⃣ HASH TOKEN
    ------------------------------------------------------------
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    ------------------------------------------------------------
    -- 2️⃣ GET SESSION
    ------------------------------------------------------------
    SELECT *
    INTO v_session
    FROM admarkify.user_sessions
    WHERE token_hash = v_token_hash
      AND is_active = TRUE
      AND (expires_at IS NULL OR expires_at > NOW())
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_SESSION';
    END IF;

    ------------------------------------------------------------
    -- 3️⃣ GET USER
    ------------------------------------------------------------
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE id = v_session.user_id;

    ------------------------------------------------------------
    -- 4️⃣ GET ORG
    ------------------------------------------------------------
    SELECT * INTO v_org
    FROM admarkify.organizations
    WHERE id = v_session.org_id;

    ------------------------------------------------------------
    -- 5️⃣ GET MEMBERSHIP
    ------------------------------------------------------------
    SELECT * INTO v_member
    FROM admarkify.organization_members
    WHERE org_id = v_org.id
      AND user_id = v_user.id;

    ------------------------------------------------------------
    -- 6️⃣ GET PLAN
    ------------------------------------------------------------
    SELECT * INTO v_plan
    FROM admarkify.subscription_plans
    WHERE id = v_org.plan_id;

    ------------------------------------------------------------
    -- 7️⃣ RETURN SAME STRUCTURE AS LOGIN
    ------------------------------------------------------------
    RETURN jsonb_build_object(
        'session_id',   v_session.id,
        'expires_at',   v_session.expires_at,

        'user', jsonb_build_object(
            'id',           v_user.id,
            'email',        v_user.email,
            'full_name',    v_user.full_name,
            'avatar_url',   v_user.avatar_url,
            'is_verified',  v_user.is_verified
        ),

        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),

        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    v_member.status,
            'joined_at', v_member.joined_at
        ),

        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );

END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_session_by_token(text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_template_by_id(uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_template_by_id(uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_get_template_by_id(
	p_template_id uuid)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN
    RETURN (
        SELECT row_to_json(t)::jsonb
        FROM admarkify.templates t
        WHERE id = p_template_id
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_template_by_id(uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_get_templates(uuid, character varying, character varying, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_get_templates(uuid, character varying, character varying, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_get_templates(
	p_org_id uuid,
	p_channel character varying DEFAULT NULL::character varying,
	p_status character varying DEFAULT NULL::character varying,
	p_provider_config_id uuid DEFAULT NULL::uuid)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'template_id',              t.id,
            'name',                     t.name,
            'channel',                  t.channel,
            'subject',                  t.subject,
            'body',                     t.body,
            'variables',                t.variables,
            'external_template_name',   t.external_template_name,
            'status',                   t.status,
            'provider_config_id',       t.provider_config_id,
            'provider_label',           opc.label,
            'provider_code',            cp.code,
            'created_by',               t.created_by,
            'created_at',               t.created_at,
            'updated_at',               t.updated_at
        )
        ORDER BY t.channel, t.name
    )
    INTO v_result
    FROM admarkify.templates t
    LEFT JOIN admarkify.org_provider_configs opc ON opc.id = t.provider_config_id
    LEFT JOIN admarkify.channel_providers    cp  ON cp.id  = opc.provider_id
    WHERE t.org_id    = p_org_id
      AND t.is_active = TRUE
      AND (p_channel            IS NULL OR t.channel             = p_channel)
      AND (p_provider_config_id IS NULL OR t.provider_config_id  = p_provider_config_id)
      AND (
            p_status IS NOT NULL
            OR t.status != 'archived'           -- default: hide archived
          )
      AND (p_status IS NULL OR t.status = p_status);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$BODY$;

ALTER FUNCTION admarkify.fn_get_templates(uuid, character varying, character varying, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_invite_member(uuid, uuid, character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_invite_member(uuid, uuid, character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_invite_member(
	p_org_id uuid,
	p_invited_by uuid,
	p_email character varying,
	p_role character varying DEFAULT 'executive'::character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_invite_id  UUID;
BEGIN
    p_email := LOWER(TRIM(p_email));

    IF p_role NOT IN ('admin','manager','lead','executive') THEN
        RAISE EXCEPTION 'INVALID_ROLE: "%" — use admin|manager|lead|executive', p_role;
    END IF;

    -- Plan seat check
    PERFORM admarkify.fn_check_team_member_limit(p_org_id);

    -- Already an active/invited member?
    IF EXISTS (
        SELECT 1
        FROM admarkify.organization_members om
        JOIN admarkify.users u ON u.id = om.user_id
        WHERE om.org_id = p_org_id
          AND u.email   = p_email
          AND om.status != 'suspended'
    ) THEN
        RAISE EXCEPTION 'ALREADY_MEMBER: % is already in this organization', p_email;
    END IF;

    -- Cancel any outstanding invite for same email + org
    UPDATE admarkify.team_invitations
    SET status = 'cancelled', updated_at = NOW()
    WHERE org_id = p_org_id AND email = p_email AND status = 'pending';

    -- Generate invite token (64-char hex; only hash stored)
    v_raw_token  := encode(public.gen_random_bytes(32), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.team_invitations (org_id, invited_by, email, role, token_hash)
    VALUES (p_org_id, p_invited_by, p_email, p_role, v_token_hash)
    RETURNING id INTO v_invite_id;

    RETURN jsonb_build_object(
        'invite_id',  v_invite_id,
        'raw_token',  v_raw_token,      -- ⚠ embed in e-mail URL, NEVER log
        'email',      p_email,
        'role',       p_role,
        'expires_at', NOW() + INTERVAL '48 hours'
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_invite_member(uuid, uuid, character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_login(character varying, text, character varying, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_login(character varying, text, character varying, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_login(
	p_email character varying,
	p_password text DEFAULT NULL::text,
	p_otp character varying DEFAULT NULL::character varying,
	p_org_slug character varying DEFAULT NULL::character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_otp        admarkify.user_otps%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    p_email    := LOWER(TRIM(p_email));
    p_org_slug := LOWER(TRIM(COALESCE(p_org_slug, '')));

    -- 🚫 Must provide either password or OTP
    IF p_password IS NULL AND p_otp IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: password or otp is required';
    END IF;

    -- ─── Step 1: Find user ────────────────────────────────────
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = p_email;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
    END IF;

    -- ─── Step 2: Verify credential ───────────────────────────
    IF p_otp IS NOT NULL THEN

        -- 🔢 OTP path
        SELECT * INTO v_otp
        FROM admarkify.user_otps
        WHERE user_id  = v_user.id
          AND otp_code = p_otp
          AND otp_type = 'login'
          AND is_used  = FALSE
          AND expires_at > NOW();

        IF NOT FOUND THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'invalid_otp');
            RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
        END IF;

        -- ✅ Consume OTP
        UPDATE admarkify.user_otps
        SET is_used = TRUE
        WHERE id = v_otp.id;

    ELSE

        -- 🔑 Password path
        IF v_user.password_hash != public.crypt(p_password, v_user.password_hash) THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'wrong_password');
            RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
        END IF;

    END IF;

    -- ─── Step 3: Account active? ──────────────────────────────
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- ─── Steps 4–8: Org resolution (unchanged logic) ─────────
    IF p_org_slug IS NOT NULL AND p_org_slug != '' THEN

        SELECT * INTO v_org
        FROM admarkify.organizations WHERE slug = p_org_slug;

        IF NOT FOUND THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'org_not_found');
            RAISE EXCEPTION 'ORG_NOT_FOUND: "%" does not exist', p_org_slug;
        END IF;

        IF NOT v_org.is_active THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'org_inactive');
            RAISE EXCEPTION 'ORG_INACTIVE: organization has been disabled';
        END IF;

        SELECT * INTO v_member
        FROM admarkify.organization_members
        WHERE org_id = v_org.id AND user_id = v_user.id;

        IF NOT FOUND THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'not_a_member');
            RAISE EXCEPTION 'NOT_A_MEMBER: user is not in org "%"', v_org.slug;
        END IF;

        IF v_member.status = 'invited' THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'invite_pending');
            RAISE EXCEPTION 'INVITE_PENDING: accept the invitation before logging in';
        END IF;

        IF v_member.status = 'suspended' THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'member_suspended');
            RAISE EXCEPTION 'MEMBER_SUSPENDED: user is suspended from "%"', v_org.slug;
        END IF;

        IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'plan_expired');
            RAISE EXCEPTION 'PLAN_EXPIRED: subscription expired at %', v_org.plan_expires_at;
        END IF;

        SELECT * INTO v_plan
        FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    ELSE

        -- Auto-pick first active org
        SELECT o.* INTO v_org
        FROM admarkify.organizations o
        JOIN admarkify.organization_members om ON om.org_id = o.id
        WHERE om.user_id  = v_user.id
          AND om.status   = 'active'
          AND o.is_active = TRUE
        ORDER BY om.joined_at ASC
        LIMIT 1;

        IF FOUND THEN
            SELECT * INTO v_member
            FROM admarkify.organization_members
            WHERE org_id = v_org.id AND user_id = v_user.id;

            IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
                INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
                VALUES (p_email, p_ip_address, FALSE, 'plan_expired');
                RAISE EXCEPTION 'PLAN_EXPIRED: subscription expired at %', v_org.plan_expires_at;
            END IF;

            SELECT * INTO v_plan
            FROM admarkify.subscription_plans WHERE id = v_org.plan_id;
        END IF;

    END IF;

    -- ─── Step 8: Create session ───────────────────────────────
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES (
        v_user.id,
        CASE WHEN v_org.id IS NOT NULL THEN v_org.id ELSE NULL END,
        v_token_hash,
        CASE WHEN v_member.role IS NOT NULL THEN v_member.role ELSE 'admin' END,
        p_ip_address,
        p_user_agent,
        NOW() + INTERVAL '7 days'
    )
    RETURNING id INTO v_session_id;

    UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;

    INSERT INTO admarkify.login_attempts (email, ip_address, success)
    VALUES (p_email, p_ip_address, TRUE);

    -- ─── Step 9: Return session ───────────────────────────────
    RETURN jsonb_build_object(
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'auth_method', CASE WHEN p_otp IS NOT NULL THEN 'otp' ELSE 'password' END,
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', v_user.is_verified
        ),
        'org', CASE
            WHEN v_org.id IS NOT NULL THEN jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            )
            ELSE NULL
        END,
        'membership', CASE
            WHEN v_member.role IS NOT NULL THEN jsonb_build_object(
                'role',      v_member.role,
                'status',    v_member.status,
                'joined_at', v_member.joined_at
            )
            ELSE NULL
        END,
        'plan', CASE
            WHEN v_plan.id IS NOT NULL THEN jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
            ELSE NULL
        END
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_login(character varying, text, character varying, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_logout(text)

-- DROP FUNCTION IF EXISTS admarkify.fn_logout(text);

CREATE OR REPLACE FUNCTION admarkify.fn_logout(
	p_raw_token text)
    RETURNS boolean
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_token_hash TEXT;
    v_rows       INT;
BEGIN
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE token_hash = v_token_hash AND is_active = TRUE;

    GET DIAGNOSTICS v_rows = ROW_COUNT;
    RETURN v_rows > 0;      -- TRUE  = session was revoked
                            -- FALSE = token was already inactive / not found
END;
$BODY$;

ALTER FUNCTION admarkify.fn_logout(text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_logout_all(uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_logout_all(uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_logout_all(
	p_user_id uuid)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_count INT;
BEGIN
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = p_user_id AND is_active = TRUE;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_logout_all(uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_logout_all_by_token(text)

-- DROP FUNCTION IF EXISTS admarkify.fn_logout_all_by_token(text);

CREATE OR REPLACE FUNCTION admarkify.fn_logout_all_by_token(
	p_raw_token text)
    RETURNS integer
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_token_hash TEXT;
    v_user_id UUID;
    v_count INT;
BEGIN
    ------------------------------------------------------------
    -- 1️⃣ HASH TOKEN (same as login/logout)
    ------------------------------------------------------------
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    ------------------------------------------------------------
    -- 2️⃣ GET USER FROM SESSION
    ------------------------------------------------------------
    SELECT us.user_id
    INTO v_user_id
    FROM admarkify.user_sessions us
    WHERE us.token_hash = v_token_hash
      AND us.is_active = TRUE
    LIMIT 1;

    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'INVALID_TOKEN';
    END IF;

    ------------------------------------------------------------
    -- 3️⃣ LOGOUT ALL SESSIONS FOR USER
    ------------------------------------------------------------
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = v_user_id
      AND is_active = TRUE;

    GET DIAGNOSTICS v_count = ROW_COUNT;

    RETURN v_count;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_logout_all_by_token(text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_old_login(character varying, text, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_old_login(character varying, text, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_old_login(
	p_email character varying,
	p_password text,
	p_org_slug character varying DEFAULT NULL::character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    p_email    := LOWER(TRIM(p_email));
    p_org_slug := LOWER(TRIM(COALESCE(p_org_slug, '')));

    -- Step 1: find user ────────────────────────────────────────
    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
    END IF;

    -- Step 2: verify password ──────────────────────────────────
    IF v_user.password_hash != public.crypt(p_password, v_user.password_hash) THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'wrong_password');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
    END IF;

    -- Step 3: user account active? ─────────────────────────────
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- Step 4: find org ─────────────────────────────────────────
    IF p_org_slug IS NOT NULL AND p_org_slug != '' THEN
        -- Specific org requested
        SELECT * INTO v_org FROM admarkify.organizations WHERE slug = p_org_slug;
        IF NOT FOUND THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'org_not_found');
            RAISE EXCEPTION 'ORG_NOT_FOUND: "%" does not exist', p_org_slug;
        END IF;

        IF NOT v_org.is_active THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'org_inactive');
            RAISE EXCEPTION 'ORG_INACTIVE: organization has been disabled';
        END IF;

        -- Step 5: user is a member? ────────────────────────────
        SELECT * INTO v_member
        FROM admarkify.organization_members
        WHERE org_id = v_org.id AND user_id = v_user.id;

        IF NOT FOUND THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'not_a_member');
            RAISE EXCEPTION 'NOT_A_MEMBER: user is not in org "%"', v_org.slug;
        END IF;

        -- Step 6: membership status ────────────────────────────
        IF v_member.status = 'invited' THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'invite_pending');
            RAISE EXCEPTION 'INVITE_PENDING: accept the invitation before logging in';
        END IF;

        IF v_member.status = 'suspended' THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'member_suspended');
            RAISE EXCEPTION 'MEMBER_SUSPENDED: user is suspended from "%"', v_org.slug;
        END IF;

        -- Step 7: plan expiry ──────────────────────────────────
        IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
            INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
            VALUES (p_email, p_ip_address, FALSE, 'plan_expired');
            RAISE EXCEPTION 'PLAN_EXPIRED: subscription expired at %', v_org.plan_expires_at;
        END IF;

        SELECT * INTO v_plan
        FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

        -- Step 8: create session with org ──────────────────────
        v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
        v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

        INSERT INTO admarkify.user_sessions
            (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
        VALUES
            (v_user.id, v_org.id, v_token_hash, v_member.role,
             p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
        RETURNING id INTO v_session_id;

        UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;
        INSERT INTO admarkify.login_attempts (email, ip_address, success)
        VALUES (p_email, p_ip_address, TRUE);

        RETURN jsonb_build_object(
            'raw_token',  v_raw_token,
            'session_id', v_session_id,
            'expires_at', NOW() + INTERVAL '7 days',
            'user', jsonb_build_object(
                'id',          v_user.id,
                'email',       v_user.email,
                'full_name',   v_user.full_name,
                'avatar_url',  v_user.avatar_url,
                'is_verified', v_user.is_verified
            ),
            'org', jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            ),
            'membership', jsonb_build_object(
                'role',      v_member.role,
                'status',    v_member.status,
                'joined_at', v_member.joined_at
            ),
            'plan', jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
        );

    ELSE
        -- ✅ No org slug → auto-pick first active org
        SELECT o.* INTO v_org
        FROM admarkify.organizations o
        JOIN admarkify.organization_members om ON om.org_id = o.id
        WHERE om.user_id  = v_user.id
          AND om.status   = 'active'
          AND o.is_active = TRUE
        ORDER BY om.joined_at ASC
        LIMIT 1;

        IF FOUND THEN
            -- User has an org → same flow as above
            SELECT * INTO v_member
            FROM admarkify.organization_members
            WHERE org_id = v_org.id AND user_id = v_user.id;

            IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
                INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
                VALUES (p_email, p_ip_address, FALSE, 'plan_expired');
                RAISE EXCEPTION 'PLAN_EXPIRED: subscription expired at %', v_org.plan_expires_at;
            END IF;

            SELECT * INTO v_plan
            FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

            v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
            v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

            INSERT INTO admarkify.user_sessions
                (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
            VALUES
                (v_user.id, v_org.id, v_token_hash, v_member.role,
                 p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
            RETURNING id INTO v_session_id;

            UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;
            INSERT INTO admarkify.login_attempts (email, ip_address, success)
            VALUES (p_email, p_ip_address, TRUE);

            RETURN jsonb_build_object(
                'raw_token',  v_raw_token,
                'session_id', v_session_id,
                'expires_at', NOW() + INTERVAL '7 days',
                'user', jsonb_build_object(
                    'id',          v_user.id,
                    'email',       v_user.email,
                    'full_name',   v_user.full_name,
                    'avatar_url',  v_user.avatar_url,
                    'is_verified', v_user.is_verified
                ),
                'org', jsonb_build_object(
                    'id',       v_org.id,
                    'name',     v_org.name,
                    'slug',     v_org.slug,
                    'timezone', v_org.timezone
                ),
                'membership', jsonb_build_object(
                    'role',      v_member.role,
                    'status',    v_member.status,
                    'joined_at', v_member.joined_at
                ),
                'plan', jsonb_build_object(
                    'name',             v_plan.name,
                    'plan_type',        v_plan.plan_type,
                    'max_team_members', v_plan.max_team_members
                )
            );

        ELSE
            -- ✅ No org at all → session with NULL org_id
            v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
            v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

            INSERT INTO admarkify.user_sessions
                (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
            VALUES
                (v_user.id, NULL, v_token_hash, 'admin',
                 p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
            RETURNING id INTO v_session_id;

            UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;
            INSERT INTO admarkify.login_attempts (email, ip_address, success)
            VALUES (p_email, p_ip_address, TRUE);

            RETURN jsonb_build_object(
                'raw_token',  v_raw_token,
                'session_id', v_session_id,
                'expires_at', NOW() + INTERVAL '7 days',
                'user', jsonb_build_object(
                    'id',          v_user.id,
                    'email',       v_user.email,
                    'full_name',   v_user.full_name,
                    'avatar_url',  v_user.avatar_url,
                    'is_verified', v_user.is_verified
                ),
                'org',     NULL,
                'message', 'No organization found. Create or join one to continue.'
            );
        END IF;
    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_old_login(character varying, text, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_old_register_user(character varying, text, character varying, character varying, character varying, inet, text, integer, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_old_register_user(character varying, text, character varying, character varying, character varying, inet, text, integer, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_old_register_user(
	p_email character varying,
	p_password text,
	p_full_name character varying,
	p_org_name character varying DEFAULT NULL::character varying,
	p_org_slug character varying DEFAULT NULL::character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text,
	p_plan_id integer DEFAULT 4,
	p_timezone character varying DEFAULT 'Asia/Kolkata'::character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
    v_user_id    UUID;
    v_org_id     UUID;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    p_email    := LOWER(TRIM(p_email));
    p_org_slug := LOWER(TRIM(COALESCE(p_org_slug, '')));

    ----------------------------------------------------------------
    -- CHECKS
    ----------------------------------------------------------------
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_email) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_email;
    END IF;

    IF p_org_slug != '' AND EXISTS (
        SELECT 1 FROM admarkify.organizations WHERE slug = p_org_slug
    ) THEN
        RAISE EXCEPTION 'ORG_SLUG_TAKEN: % already exists', p_org_slug;
    END IF;

    ----------------------------------------------------------------
    -- CREATE USER
    ----------------------------------------------------------------
    INSERT INTO admarkify.users (email, password_hash, full_name)
    VALUES (
        p_email,
        public.crypt(p_password, public.gen_salt('bf', 10)),
        p_full_name
    )
    RETURNING * INTO v_user;

    v_user_id := v_user.id;

    ----------------------------------------------------------------
    -- WITH ORG
    ----------------------------------------------------------------
    IF p_org_name IS NOT NULL AND p_org_slug != '' THEN

        INSERT INTO admarkify.organizations (
            name, slug, plan_id, timezone, owner_email, is_active, created_at
        )
        VALUES (
            p_org_name, p_org_slug, p_plan_id, p_timezone, p_email, TRUE, NOW()
        )
        RETURNING * INTO v_org;

        v_org_id := v_org.id;

        INSERT INTO admarkify.organization_members (
            org_id, user_id, role, status, joined_at
        )
        VALUES (v_org_id, v_user_id, 'admin', 'active', NOW())
        RETURNING * INTO v_member;

        SELECT * INTO v_plan
        FROM admarkify.subscription_plans
        WHERE id = v_org.plan_id;

        v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
        v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

        INSERT INTO admarkify.user_sessions
            (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
        VALUES
            (v_user_id, v_org_id, v_token_hash, v_member.role,
             p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
        RETURNING id INTO v_session_id;

        RETURN jsonb_build_object(
            'raw_token',  v_raw_token,
            'session_id', v_session_id,
            'expires_at', NOW() + INTERVAL '7 days',
            'user', jsonb_build_object(
                'id',          v_user.id,
                'email',       v_user.email,
                'full_name',   v_user.full_name,
                'avatar_url',  v_user.avatar_url,
                'is_verified', v_user.is_verified
            ),
            'org', jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            ),
            'membership', jsonb_build_object(
                'role',      v_member.role,
                'status',    v_member.status,
                'joined_at', v_member.joined_at
            ),
            'plan', jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
        );

    END IF;

    ----------------------------------------------------------------
    -- WITHOUT ORG — session still created, org_id is NULL
    -- ✅ user_sessions.org_id must be nullable for this to work
    ----------------------------------------------------------------
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user_id, NULL, v_token_hash, 'admin',
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', v_user.is_verified
        ),
        'org',     NULL,
        'message', 'User created. Create or join an organization to continue.'
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_old_register_user(character varying, text, character varying, character varying, character varying, inet, text, integer, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_publish_template(uuid, uuid, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_publish_template(uuid, uuid, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_publish_template(
	p_org_id uuid,
	p_actor_id uuid,
	p_template_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin/manager can publish templates';
    END IF;

    UPDATE admarkify.templates
    SET status = 'active', updated_by = p_actor_id, updated_at = NOW()
    WHERE id = p_template_id AND org_id = p_org_id AND status = 'draft';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND or already active/archived';
    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_publish_template(uuid, uuid, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_register_user(character varying, text, character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_register_user(character varying, text, character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_register_user(
	p_email character varying,
	p_password text,
	p_full_name character varying,
	p_mobile character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user        admarkify.users%ROWTYPE;
    v_user_id     UUID;
    v_email_otp   VARCHAR(6);
    v_mobile_otp  VARCHAR(6);
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;

    IF FOUND THEN
        IF v_user.is_email_verified = TRUE OR v_user.is_mobile_verified = TRUE THEN
            RAISE EXCEPTION 'ACCOUNT_ALREADY_EXISTS';
        END IF;

        UPDATE admarkify.users
        SET
            password_hash = public.crypt(p_password, public.gen_salt('bf', 10)),
            full_name     = p_full_name,
            mobile        = p_mobile,
            updated_at    = NOW()
        WHERE id = v_user.id
        RETURNING * INTO v_user;

        v_user_id := v_user.id;

    ELSE
        INSERT INTO admarkify.users (
            email, password_hash, full_name, mobile
        )
        VALUES (
            p_email,
            public.crypt(p_password, public.gen_salt('bf', 10)),
            p_full_name,
            p_mobile
        )
        RETURNING * INTO v_user;

        v_user_id := v_user.id;
    END IF;

    -- Generate OTP
    v_email_otp  := LPAD((FLOOR(RANDOM() * 1000000))::TEXT, 6, '0');
    v_mobile_otp := LPAD((FLOOR(RANDOM() * 1000000))::TEXT, 6, '0');

    DELETE FROM admarkify.user_otps
    WHERE user_id = v_user_id AND is_used = FALSE;

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES
        (v_user_id, v_email_otp,  'email',  NOW() + INTERVAL '10 minutes'),
        (v_user_id, v_mobile_otp, 'mobile', NOW() + INTERVAL '10 minutes');

    -- ✅ Return OTP ONLY for backend use
    RETURN jsonb_build_object(
        'user_id', v_user_id,
        'email', p_email,
        'mobile', p_mobile,
        'email_otp', v_email_otp,
        'mobile_otp', v_mobile_otp
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_register_user(character varying, text, character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_remove_member(uuid, uuid, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_remove_member(uuid, uuid, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_remove_member(
	p_org_id uuid,
	p_actor_user_id uuid,
	p_target_user_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_user_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can remove members';
    END IF;

    IF p_actor_user_id = p_target_user_id THEN
        RAISE EXCEPTION 'CANNOT_REMOVE_SELF: admins cannot remove themselves';
    END IF;

    UPDATE admarkify.organization_members
    SET status = 'suspended', updated_at = NOW()
    WHERE org_id = p_org_id AND user_id = p_target_user_id;

    -- Immediately revoke all sessions in this org
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = p_target_user_id AND org_id = p_org_id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_remove_member(uuid, uuid, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_remove_org_provider(uuid, uuid, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_remove_org_provider(uuid, uuid, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_remove_org_provider(
	p_org_id uuid,
	p_actor_id uuid,
	p_config_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role    VARCHAR;
    v_template_count INT;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can remove providers';
    END IF;

    -- Block if active templates are still linked
    SELECT COUNT(*) INTO v_template_count
    FROM admarkify.templates
    WHERE provider_config_id = p_config_id
      AND status != 'archived'
      AND is_active = TRUE;

    IF v_template_count > 0 THEN
        RAISE EXCEPTION
            'PROVIDER_IN_USE: % active template(s) reference this provider — archive them first',
            v_template_count;
    END IF;

    UPDATE admarkify.org_provider_configs
    SET is_active = FALSE, is_default = FALSE, updated_at = NOW()
    WHERE id = p_config_id AND org_id = p_org_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'CONFIG_NOT_FOUND';
    END IF;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_remove_org_provider(uuid, uuid, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_request_change_email(character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_request_change_email(character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_request_change_email(
	p_email character varying,
	p_new_email character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email     := LOWER(TRIM(p_email));
    p_new_email := LOWER(TRIM(p_new_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New email must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_new_email;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_email'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_email',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_email', p_new_email)
    );

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'new_email', p_new_email,
        'otp',       v_otp_code   -- send this to new_email
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_request_change_email(character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_request_change_mobile(character varying, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_request_change_mobile(character varying, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_request_change_mobile(
	p_email character varying,
	p_new_mobile character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New mobile must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = p_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', p_new_mobile;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_mobile'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_mobile',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_mobile', p_new_mobile)
    );

    RETURN jsonb_build_object(
        'user_id',    v_user.id,
        'email',      v_user.email,
        'new_mobile', p_new_mobile,
        'otp',        v_otp_code   -- send this via SMS
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_request_change_mobile(character varying, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_request_change_password(character varying, inet)

-- DROP FUNCTION IF EXISTS admarkify.fn_request_change_password(character varying, inet);

CREATE OR REPLACE FUNCTION admarkify.fn_request_change_password(
	p_email character varying,
	p_ip_address inet DEFAULT NULL::inet)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_password'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'change_password', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id', v_user.id,
        'email',   v_user.email,
        'mobile',  v_user.mobile,
        'otp',     v_otp_code
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_request_change_password(character varying, inet)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_search_organizations(text, integer, boolean, integer, integer, text, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_search_organizations(text, integer, boolean, integer, integer, text, text);

CREATE OR REPLACE FUNCTION admarkify.fn_search_organizations(
	p_search text DEFAULT NULL::text,
	p_plan_id integer DEFAULT NULL::integer,
	p_only_active boolean DEFAULT false,
	p_page integer DEFAULT 1,
	p_page_size integer DEFAULT 10,
	p_sort_by text DEFAULT 'created_at'::text,
	p_sort_order text DEFAULT 'desc'::text)
    RETURNS json
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_offset INT;
    v_sql TEXT;
    v_result JSON;
BEGIN

    ------------------------------------------------------------
    -- 1️⃣ VALIDATE PLAN_ID
    ------------------------------------------------------------
    IF p_plan_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM admarkify.subscription_plans sp
            WHERE sp.id = p_plan_id
              AND sp.is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=%s', p_plan_id;
        END IF;
    END IF;

    ------------------------------------------------------------
    -- 2️⃣ PAGINATION
    ------------------------------------------------------------
    v_offset := (p_page - 1) * p_page_size;

    ------------------------------------------------------------
    -- 3️⃣ SAFE SORT COLUMN
    ------------------------------------------------------------
    IF p_sort_by NOT IN ('name','created_at') THEN
        p_sort_by := 'created_at';
    END IF;

    ------------------------------------------------------------
    -- 4️⃣ BUILD QUERY (ONLY REQUIRED FIELDS)
    ------------------------------------------------------------
    v_sql := format($f$
        SELECT COALESCE(json_agg(row_data), '[]'::json)
            FROM (
                SELECT 
                    o.id,
                    o.name,
                    o.slug,
                    o.created_at
                FROM admarkify.organizations o
                WHERE
                    (%L IS NULL OR
                        o.name ILIKE '%%' || %L || '%%' OR
                        o.slug ILIKE '%%' || %L || '%%'
                    )
                    AND (%L IS NULL OR o.plan_id = %L)
                    AND (%L = FALSE OR o.is_active = TRUE)
                ORDER BY %I %s
                LIMIT %s OFFSET %s
            ) row_data
        $f$,

        p_search, p_search, p_search,
        p_plan_id, p_plan_id,
        p_only_active,

        p_sort_by,
        CASE WHEN LOWER(p_sort_order) = 'asc' THEN 'ASC' ELSE 'DESC' END,

        p_page_size,
        v_offset
    );

    ------------------------------------------------------------
    -- 5️⃣ EXECUTE
    ------------------------------------------------------------
    EXECUTE v_sql INTO v_result;

    RETURN v_result;

END;
$BODY$;

ALTER FUNCTION admarkify.fn_search_organizations(text, integer, boolean, integer, integer, text, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_send_login_otp(character varying, inet)

-- DROP FUNCTION IF EXISTS admarkify.fn_send_login_otp(character varying, inet);

CREATE OR REPLACE FUNCTION admarkify.fn_send_login_otp(
	p_email character varying,
	p_ip_address inet DEFAULT NULL::inet)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    -- 🔍 Find user
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = p_email;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email';
    END IF;

    -- 🚫 Account active?
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- 🚫 Email verified?
    IF NOT v_user.is_email_verified THEN
        RAISE EXCEPTION 'EMAIL_NOT_VERIFIED: verify your email before logging in';
    END IF;

    -- 🔢 Expire any existing unused login OTPs for this user
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'login'
      AND is_used = FALSE;

    -- 🔢 Generate 6-digit OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    -- 💾 Store OTP
    INSERT INTO admarkify.user_otps
        (user_id, otp_code, otp_type, expires_at)
    VALUES
        (v_user.id, v_otp_code, 'login', NOW() + INTERVAL '10 minutes');

    -- ✅ Return OTP to application layer (app will send email/SMS)
    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'mobile',    v_user.mobile,
        'login_otp', v_otp_code
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_send_login_otp(character varying, inet)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_send_login_otp_single(character varying, character varying, inet)

-- DROP FUNCTION IF EXISTS admarkify.fn_send_login_otp_single(character varying, character varying, inet);

CREATE OR REPLACE FUNCTION admarkify.fn_send_login_otp_single(
	p_email character varying DEFAULT NULL::character varying,
	p_mobile character varying DEFAULT NULL::character varying,
	p_ip_address inet DEFAULT NULL::inet)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    IF p_email IS NOT NULL THEN
        p_email := LOWER(TRIM(p_email));
    END IF;

    -- 🔍 Find user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (COALESCE(p_email, p_mobile), p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: user not found';
    END IF;

    -- 🚫 Account active?
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (v_user.email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- 🚫 Verified check based on which identifier was provided
    IF p_email IS NOT NULL AND NOT v_user.is_email_verified THEN
        RAISE EXCEPTION 'EMAIL_NOT_VERIFIED: verify your email before logging in';
    END IF;

    IF p_mobile IS NOT NULL AND NOT v_user.is_mobile_verified THEN
        RAISE EXCEPTION 'MOBILE_NOT_VERIFIED: verify your mobile before logging in';
    END IF;

    -- 🔢 Expire existing unused login OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id  = v_user.id
      AND otp_type = 'login'
      AND is_used  = FALSE;

    -- 🔢 Generate 6-digit OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'login', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'mobile',    v_user.mobile,
        'login_otp', v_otp_code
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_send_login_otp_single(character varying, character varying, inet)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_set_default_provider(uuid, uuid, uuid)

-- DROP FUNCTION IF EXISTS admarkify.fn_set_default_provider(uuid, uuid, uuid);

CREATE OR REPLACE FUNCTION admarkify.fn_set_default_provider(
	p_org_id uuid,
	p_actor_id uuid,
	p_config_id uuid)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role    VARCHAR;
    v_channel       VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can change default provider';
    END IF;

    -- Get channel of the target config
    SELECT cp.channel INTO v_channel
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.id = p_config_id AND opc.org_id = p_org_id AND opc.is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'CONFIG_NOT_FOUND: provider config not found or inactive';
    END IF;

    -- Clear current default for this channel in this org
    UPDATE admarkify.org_provider_configs opc
    SET is_default = FALSE, updated_at = NOW()
    FROM admarkify.channel_providers cp
    WHERE cp.id       = opc.provider_id
      AND opc.org_id  = p_org_id
      AND cp.channel  = v_channel
      AND opc.is_default = TRUE;

    -- Set new default
    UPDATE admarkify.org_provider_configs
    SET is_default = TRUE, updated_at = NOW()
    WHERE id = p_config_id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_set_default_provider(uuid, uuid, uuid)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_update_member_role(uuid, uuid, uuid, character varying)

-- DROP FUNCTION IF EXISTS admarkify.fn_update_member_role(uuid, uuid, uuid, character varying);

CREATE OR REPLACE FUNCTION admarkify.fn_update_member_role(
	p_org_id uuid,
	p_actor_user_id uuid,
	p_target_user_id uuid,
	p_new_role character varying)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_user_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can change member roles';
    END IF;

    IF p_new_role NOT IN ('admin','manager','lead','executive') THEN
        RAISE EXCEPTION 'INVALID_ROLE: "%"', p_new_role;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM admarkify.organization_members
        WHERE org_id = p_org_id AND user_id = p_target_user_id
    ) THEN
        RAISE EXCEPTION 'MEMBER_NOT_FOUND';
    END IF;

    UPDATE admarkify.organization_members
    SET role = p_new_role, updated_at = NOW()
    WHERE org_id = p_org_id AND user_id = p_target_user_id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_update_member_role(uuid, uuid, uuid, character varying)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_update_org_provider(uuid, uuid, uuid, character varying, jsonb, jsonb)

-- DROP FUNCTION IF EXISTS admarkify.fn_update_org_provider(uuid, uuid, uuid, character varying, jsonb, jsonb);

CREATE OR REPLACE FUNCTION admarkify.fn_update_org_provider(
	p_org_id uuid,
	p_actor_id uuid,
	p_config_id uuid,
	p_label character varying DEFAULT NULL::character varying,
	p_credentials jsonb DEFAULT NULL::jsonb,
	p_settings jsonb DEFAULT NULL::jsonb)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role      VARCHAR;
    v_config          admarkify.org_provider_configs%ROWTYPE;
    v_provider        admarkify.channel_providers%ROWTYPE;

    -- schema validation
    v_merged_creds    jsonb;
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    jsonb;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Actor must be admin or manager
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin', 'manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can update providers';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Load existing config
    -- ----------------------------------------------------------------
    SELECT * INTO v_config
    FROM admarkify.org_provider_configs
    WHERE id       = p_config_id
      AND org_id   = p_org_id
      AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'NOT_FOUND: provider config "%" does not exist or is inactive', p_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Load provider info
    -- ----------------------------------------------------------------
    SELECT * INTO v_provider
    FROM admarkify.channel_providers
    WHERE id = v_config.provider_id;

    -- ----------------------------------------------------------------
    -- 4) Validate credentials only when p_credentials is passed
    --    Merge existing credentials with incoming so partial updates
    --    (only sending changed keys) are also fully validated.
    --
    --    e.g. existing: {"authkey":"abc", "integrated_number":"123"}
    --         incoming: {"authkey": "newkey"}
    --         merged:   {"authkey":"newkey", "integrated_number":"123"}
    --    → full schema is always satisfied after merge
    -- ----------------------------------------------------------------
    IF p_credentials IS NOT NULL THEN

        -- merge: existing || incoming  (incoming keys win on conflict)
        v_merged_creds := v_config.credentials || p_credentials;

        IF v_provider.credentials_schema IS NOT NULL
           AND v_provider.credentials_schema <> '{}'::jsonb
        THEN
            FOR v_field_name, v_expected_type IN
                SELECT key, value #>> '{}'
                FROM jsonb_each(v_provider.credentials_schema)
            LOOP
                v_actual_value := v_merged_creds -> v_field_name;

                -- 4a) field must exist and not be JSON null
                IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                    v_missing_fields := v_missing_fields || v_field_name;
                    CONTINUE;
                END IF;

                -- 4b) type + value check
                CASE v_expected_type

                    WHEN 'string' THEN
                        IF jsonb_typeof(v_actual_value) <> 'string'
                           OR TRIM(v_actual_value #>> '{}') = ''
                           OR LOWER(TRIM(v_actual_value #>> '{}')) IN ('string','number','boolean','null')
                        THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected a real non-empty string, received "'
                                    || (v_actual_value #>> '{}') || '"');
                        END IF;

                    WHEN 'number' THEN
                        IF jsonb_typeof(v_actual_value) <> 'number' THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected number, got '
                                    || jsonb_typeof(v_actual_value));
                        END IF;

                    WHEN 'boolean' THEN
                        IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected boolean, got '
                                    || jsonb_typeof(v_actual_value));
                        END IF;

                    ELSE
                        NULL; -- unknown schema type → skip silently

                END CASE;
            END LOOP;

            -- 4c) raise ONE combined error listing every problem
            IF array_length(v_missing_fields, 1) > 0
               OR array_length(v_type_errors,  1) > 0
            THEN
                RAISE EXCEPTION 'INVALID_CREDENTIALS: provider "%" schema validation failed.%s%s',
                    v_provider.code,
                    CASE WHEN array_length(v_missing_fields, 1) > 0
                         THEN E'\n  Missing required fields: '
                              || array_to_string(v_missing_fields, ', ')
                         ELSE ''
                    END,
                    CASE WHEN array_length(v_type_errors, 1) > 0
                         THEN E'\n  Type errors: '
                              || array_to_string(v_type_errors, ' | ')
                         ELSE ''
                    END;
            END IF;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Update only provided fields (COALESCE keeps old value if NULL)
    -- ----------------------------------------------------------------
    UPDATE admarkify.org_provider_configs
    SET
        label       = COALESCE(p_label,       label),
        credentials = COALESCE(p_credentials, credentials),
        settings    = COALESCE(p_settings,    settings),
        updated_at  = NOW()
    WHERE id = p_config_id;

    -- ----------------------------------------------------------------
    -- 6) Return summary
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'config_id',  p_config_id,
        'provider',   v_provider.code,
        'channel',    v_provider.channel,
        'label',      COALESCE(p_label, v_config.label),
        'is_default', v_config.is_default,
        'updated_at', NOW()
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_update_org_provider(uuid, uuid, uuid, character varying, jsonb, jsonb)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_update_template(uuid, uuid, uuid, character varying, uuid, jsonb)

-- DROP FUNCTION IF EXISTS admarkify.fn_update_template(uuid, uuid, uuid, character varying, uuid, jsonb);

CREATE OR REPLACE FUNCTION admarkify.fn_update_template(
	p_org_id uuid,
	p_actor_id uuid,
	p_template_id uuid,
	p_name character varying DEFAULT NULL::character varying,
	p_provider_config_id uuid DEFAULT NULL::uuid,
	p_provider_payload jsonb DEFAULT NULL::jsonb)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role     VARCHAR;
    v_provider       admarkify.channel_providers%ROWTYPE;
    v_body           TEXT;
    v_subject        TEXT;
    v_channel        VARCHAR;
    v_existing       admarkify.templates%ROWTYPE;

    -- schema validation
    v_field_name     TEXT;
    v_expected_type  TEXT;
    v_actual_value   JSONB;
    v_missing_fields TEXT[] := ARRAY[]::TEXT[];
    v_type_errors    TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Permission check
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can update templates';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Load existing template and verify it belongs to this org
    -- ----------------------------------------------------------------
    SELECT * INTO v_existing
    FROM admarkify.templates
    WHERE id     = p_template_id
      AND org_id = p_org_id
      AND is_active = TRUE;

    IF v_existing.id IS NULL THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND: template does not exist or does not belong to this org';
    END IF;

    IF v_existing.status = 'archived' THEN
        RAISE EXCEPTION 'TEMPLATE_ARCHIVED: archived templates cannot be updated';
    END IF;

    -- keep existing channel
    v_channel := v_existing.channel;

    -- ----------------------------------------------------------------
    -- 3) Validate + load provider config if supplied
    -- ----------------------------------------------------------------
    IF p_provider_config_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM admarkify.org_provider_configs
            WHERE id       = p_provider_config_id
              AND org_id   = p_org_id
              AND is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config does not belong to this org';
        END IF;

        SELECT cp.* INTO v_provider
        FROM admarkify.org_provider_configs opc
        JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
        WHERE opc.id = p_provider_config_id;

    ELSIF v_existing.provider_config_id IS NOT NULL THEN
        -- keep existing provider config
        SELECT cp.* INTO v_provider
        FROM admarkify.org_provider_configs opc
        JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
        WHERE opc.id = v_existing.provider_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Validate p_provider_payload against providers_schema
    -- ----------------------------------------------------------------
    IF p_provider_payload IS NOT NULL
       AND v_provider.providers_schema IS NOT NULL
       AND v_provider.providers_schema <> '{}'::jsonb
    THEN
        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'
            FROM jsonb_each(v_provider.providers_schema)
        LOOP
            v_actual_value := p_provider_payload -> v_field_name;

            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;
            END IF;

            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}'))
                              IN ('string','number','boolean','null','html','slug_string')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'html' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name || ': expected non-empty HTML string');
                    ELSE
                        v_body := v_actual_value #>> '{}';
                    END IF;

                WHEN 'slug_string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR (v_actual_value #>> '{}') !~ '^[a-zA-Z0-9_-]+$'
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a slug (letters, digits, _ or - only), received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE NULL;
            END CASE;

            -- extract subject if present
            IF v_field_name = 'subject'
               AND jsonb_typeof(v_actual_value) = 'string'
               AND TRIM(v_actual_value #>> '{}') <> ''
            THEN
                v_subject := v_actual_value #>> '{}';
            END IF;

        END LOOP;

        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_PROVIDER_PAYLOAD: provider "%" payload validation failed.%s%s',
                v_provider.code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Email requires subject (only if payload is being updated)
    -- ----------------------------------------------------------------
    IF v_channel = 'email'
       AND p_provider_payload IS NOT NULL
       AND (v_subject IS NULL OR TRIM(v_subject) = '')
    THEN
        RAISE EXCEPTION 'SUBJECT_REQUIRED: email templates must have a subject field in payload';
    END IF;

    -- ----------------------------------------------------------------
    -- 6) Apply update — only touch columns that were supplied
    -- ----------------------------------------------------------------
    UPDATE admarkify.templates
    SET
        name               = COALESCE(NULLIF(TRIM(p_name), ''),     name),
        provider_config_id = COALESCE(p_provider_config_id,          provider_config_id),
        provider_request   = COALESCE(p_provider_payload,            provider_request),
        subject            = COALESCE(v_subject,                     subject),
        body               = COALESCE(v_body,                        body),
        updated_by         = p_actor_id,
        updated_at         = NOW()
    WHERE id = p_template_id;

    -- ----------------------------------------------------------------
    -- 7) Return
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'template_id',      p_template_id,
        'name',             COALESCE(NULLIF(TRIM(p_name), ''), v_existing.name),
        'channel',          v_channel,
        'status',           v_existing.status,
        'end_point',        v_provider.end_point,
        'provider_payload', p_provider_payload
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_update_template(uuid, uuid, uuid, character varying, uuid, jsonb)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_update_template_external(uuid, text, text, jsonb, jsonb, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_update_template_external(uuid, text, text, jsonb, jsonb, text);

CREATE OR REPLACE FUNCTION admarkify.fn_update_template_external(
	p_template_id uuid,
	p_provider_template_id text,
	p_template_slug text,
	p_provider_request jsonb,
	p_provider_response jsonb,
	p_status text)
    RETURNS void
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
BEGIN
    UPDATE admarkify.templates
    SET provider_template_id = p_provider_template_id,
        template_slug        = p_template_slug,
        provider_request     = p_provider_request,
        provider_response    = p_provider_response,
        -- ✅ if externalId or slug is null, C# sends "failed", else "pending"
        status               = p_status,
        updated_at           = NOW()
    WHERE id = p_template_id;
END;
$BODY$;

ALTER FUNCTION admarkify.fn_update_template_external(uuid, text, text, jsonb, jsonb, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_upgrade_plan(uuid, integer, timestamp with time zone)

-- DROP FUNCTION IF EXISTS admarkify.fn_upgrade_plan(uuid, integer, timestamp with time zone);

CREATE OR REPLACE FUNCTION admarkify.fn_upgrade_plan(
	p_org_id uuid,
	p_new_plan_id integer,
	p_expires_at timestamp with time zone DEFAULT NULL::timestamp with time zone)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_org      admarkify.organizations%ROWTYPE;
    v_old_plan admarkify.subscription_plans%ROWTYPE;
    v_new_plan admarkify.subscription_plans%ROWTYPE;
BEGIN
    SELECT * INTO v_org FROM admarkify.organizations WHERE id = p_org_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'ORG_NOT_FOUND'; END IF;

    SELECT * INTO v_old_plan
    FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    SELECT * INTO v_new_plan
    FROM admarkify.subscription_plans WHERE id = p_new_plan_id AND is_active = TRUE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=% is invalid or inactive', p_new_plan_id;
    END IF;

    UPDATE admarkify.organizations
    SET plan_id = p_new_plan_id, plan_expires_at = p_expires_at, updated_at = NOW()
    WHERE id = p_org_id;

    RETURN jsonb_build_object(
        'org_id',     p_org_id,
        'old_plan',   v_old_plan.name,
        'new_plan',   v_new_plan.name,
        'expires_at', p_expires_at
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_upgrade_plan(uuid, integer, timestamp with time zone)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_verify_invite_otp(character varying, character varying, character varying, character varying, text, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_verify_invite_otp(character varying, character varying, character varying, character varying, text, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp(
	p_email character varying,
	p_mobile character varying,
	p_otp character varying,
	p_type character varying,
	p_raw_token text,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- 🔍 Resolve user by email + mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = p_email AND mobile = p_mobile
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response, no limit check yet
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → validate invite + check limit +
    --                    finalize membership + create session
    -- ════════════════════════════════════════════════════════

    -- 🔍 Validate + consume invite
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    -- 🔍 Get org + plan
    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- 🚫 Check seat limit before activating membership
    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    -- ✅ Consume invite
    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    -- ✅ Create / activate membership
    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    -- ✅ Activate user account
    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- 🎉 Create session
    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_verify_invite_otp(character varying, character varying, character varying, character varying, text, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_verify_invite_otp_single(character varying, character varying, character varying, character varying, text, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_verify_invite_otp_single(character varying, character varying, character varying, character varying, text, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp_single(
	p_email character varying DEFAULT NULL::character varying,
	p_mobile character varying DEFAULT NULL::character varying,
	p_otp character varying DEFAULT NULL::character varying,
	p_type character varying DEFAULT NULL::character varying,
	p_raw_token text DEFAULT NULL::text,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → finalize invite + create session
    -- ════════════════════════════════════════════════════════
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_verify_invite_otp_single(character varying, character varying, character varying, character varying, text, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_verify_otp(character varying, character varying, character varying, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_verify_otp(character varying, character varying, character varying, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_verify_otp(
	p_email character varying,
	p_mobile character varying,
	p_otp character varying,
	p_type character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_otp        RECORD;
    v_user       admarkify.users%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    -- 🔍 Resolve user by email or mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid OTP for resolved user
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP';
    END IF;

    -- ✅ Mark OTP used
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification status
    IF p_type = 'email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE
        WHERE id = v_user.id;

    ELSIF p_type = 'mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE id = v_user.id;

    -- 🚨 Not fully verified → return partial status
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',          'OTP verified',
            'user_id',          v_user.id,
            'email_verified',   v_user.is_email_verified,
            'mobile_verified',  v_user.is_mobile_verified
        );
    END IF;

    -- 🎉 FULLY VERIFIED → CREATE SESSION
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, NULL, v_token_hash, 'admin',
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    UPDATE admarkify.users
    SET last_login_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'User verified successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', NULL
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_verify_otp(character varying, character varying, character varying, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_verify_otp_single(character varying, character varying, character varying, character varying, inet, text)

-- DROP FUNCTION IF EXISTS admarkify.fn_verify_otp_single(character varying, character varying, character varying, character varying, inet, text);

CREATE OR REPLACE FUNCTION admarkify.fn_verify_otp_single(
	p_email character varying,
	p_mobile character varying,
	p_otp character varying,
	p_type character varying,
	p_ip_address inet DEFAULT NULL::inet,
	p_user_agent text DEFAULT NULL::text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_otp        RECORD;
    v_user       admarkify.users%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification status
    IF p_type = 'email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE
        WHERE id = v_user.id;
    ELSIF p_type = 'mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- 🎉 FULLY VERIFIED → CREATE SESSION
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, NULL, v_token_hash, 'admin',
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    UPDATE admarkify.users
    SET last_login_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'User verified successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', NULL
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_verify_otp_single(character varying, character varying, character varying, character varying, inet, text)
    OWNER TO postgres;

-- FUNCTION: admarkify.fn_verify_session(text)

-- DROP FUNCTION IF EXISTS admarkify.fn_verify_session(text);

CREATE OR REPLACE FUNCTION admarkify.fn_verify_session(
	p_raw_token text)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_token_hash TEXT;
    v_session    admarkify.user_sessions%ROWTYPE;
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
BEGIN
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_session
    FROM admarkify.user_sessions
    WHERE token_hash = v_token_hash
      AND is_active   = TRUE
      AND expires_at  > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'SESSION_INVALID: token expired, revoked, or not found';
    END IF;

    -- Slide activity window
    UPDATE admarkify.user_sessions
    SET last_used_at = NOW() WHERE id = v_session.id;

    SELECT * INTO v_user FROM admarkify.users         WHERE id = v_session.user_id;
    SELECT * INTO v_org  FROM admarkify.organizations WHERE id = v_session.org_id;

    IF NOT v_user.is_active THEN RAISE EXCEPTION 'ACCOUNT_SUSPENDED'; END IF;
    IF NOT v_org.is_active  THEN RAISE EXCEPTION 'ORG_INACTIVE';       END IF;

    RETURN jsonb_build_object(
        'session_id',   v_session.id,
        'user_id',      v_session.user_id,
        'org_id',       v_session.org_id,
        'role',         v_session.role,         -- use this for permission checks
        'expires_at',   v_session.expires_at,
        'org_slug',     v_org.slug,
        'org_timezone', v_org.timezone,
        'user_email',   v_user.email,
        'user_name',    v_user.full_name
    );
END;
$BODY$;

ALTER FUNCTION admarkify.fn_verify_session(text)
    OWNER TO postgres;


