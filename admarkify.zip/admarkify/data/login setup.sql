-- ============================================================
--  admarkify — AUTH, TEAM & SESSION
--  Schema: admarkify (every object lives here)
--  Requires: pgcrypto
--  Roles:  admin | manager | lead | executive
--  Plans:  free  | paid    | pro
-- ============================================================

CREATE SCHEMA IF NOT EXISTS admarkify;
CREATE EXTENSION IF NOT EXISTS pgcrypto;


-- ============================================================
--  SECTION 1 — PLAN DEFINITIONS
-- ============================================================

CREATE TABLE IF NOT EXISTS admarkify.subscription_plans (
    id                  SERIAL          PRIMARY KEY,
    name                VARCHAR(64)     NOT NULL UNIQUE,     -- 'Free' | 'Paid' | 'Pro'
    plan_type           VARCHAR(32)     NOT NULL,            -- 'free' | 'paid' | 'pro'
    max_team_members    INT,                                 -- NULL = unlimited (Pro)
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_plan_type CHECK (plan_type IN ('free','paid','pro'))
);

-- Seed plans (safe to re-run)
INSERT INTO admarkify.subscription_plans (name, plan_type, max_team_members) VALUES
    ('Free', 'free',  3),
    ('Paid', 'paid',  10),
    ('Pro',  'pro',   NULL)
ON CONFLICT (name) DO NOTHING;


-- ============================================================
--  SECTION 2 — CORE TABLES
-- ============================================================

-- ------------------------------------------------------------
--  2A. USERS
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.users (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    email           VARCHAR(255)    NOT NULL UNIQUE,
    password_hash   TEXT            NOT NULL,
    full_name       VARCHAR(255)    NOT NULL,
    avatar_url      TEXT,
    is_verified     BOOLEAN         NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    last_login_at   TIMESTAMPTZ,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_users_email
    ON admarkify.users(email);


-- ------------------------------------------------------------
--  2B. ORGANIZATIONS  (one org = one team)
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.organizations (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    name            VARCHAR(255)    NOT NULL,
    slug            VARCHAR(100)    NOT NULL UNIQUE,
    plan_id         INT             NOT NULL
                        REFERENCES admarkify.subscription_plans(id) DEFAULT 1,
    plan_expires_at TIMESTAMPTZ,                    -- NULL = no expiry
    owner_email     VARCHAR(255)    NOT NULL,
    timezone        VARCHAR(64)     NOT NULL DEFAULT 'UTC',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_orgs_slug
    ON admarkify.organizations(slug);


-- ------------------------------------------------------------
--  2C. ORGANIZATION MEMBERS
--  Roles:   admin | manager | lead | executive
--  Status:  active | invited | suspended
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.organization_members (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      UUID        NOT NULL
                    REFERENCES admarkify.organizations(id) ON DELETE CASCADE,
    user_id     UUID        NOT NULL
                    REFERENCES admarkify.users(id)         ON DELETE CASCADE,
    role        VARCHAR(32) NOT NULL DEFAULT 'executive',
    status      VARCHAR(32) NOT NULL DEFAULT 'invited',
    invited_by  UUID        REFERENCES admarkify.users(id),
    joined_at   TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_org_member     UNIQUE (org_id, user_id),
    CONSTRAINT chk_member_role   CHECK (role   IN ('admin','manager','lead','executive')),
    CONSTRAINT chk_member_status CHECK (status IN ('active','invited','suspended'))
);

CREATE INDEX IF NOT EXISTS idx_members_org  ON admarkify.organization_members(org_id);
CREATE INDEX IF NOT EXISTS idx_members_user ON admarkify.organization_members(user_id);


-- ------------------------------------------------------------
--  2D. USER SESSIONS
--  Raw token NEVER stored — only its SHA-256 hash.
--  One user can hold sessions in multiple orgs simultaneously.
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.user_sessions (
    id           UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID        NOT NULL
                    REFERENCES admarkify.users(id)         ON DELETE CASCADE,
    org_id       UUID        NOT NULL
                    REFERENCES admarkify.organizations(id) ON DELETE CASCADE,
    token_hash   TEXT        NOT NULL UNIQUE,
    role         VARCHAR(32) NOT NULL,              -- cached at login time
    ip_address   INET,
    user_agent   TEXT,
    is_active    BOOLEAN     NOT NULL DEFAULT TRUE,
    expires_at   TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
    last_used_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_session_role CHECK (role IN ('admin','manager','lead','executive'))
);

CREATE INDEX IF NOT EXISTS idx_sessions_token  ON admarkify.user_sessions(token_hash);
CREATE INDEX IF NOT EXISTS idx_sessions_user   ON admarkify.user_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_org    ON admarkify.user_sessions(org_id);
CREATE INDEX IF NOT EXISTS idx_sessions_active ON admarkify.user_sessions(is_active, expires_at);


-- ------------------------------------------------------------
--  2E. TEAM INVITATIONS
--  Raw invite token sent in e-mail URL — only hash stored.
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.team_invitations (
    id          UUID        PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id      UUID        NOT NULL
                    REFERENCES admarkify.organizations(id) ON DELETE CASCADE,
    invited_by  UUID        NOT NULL REFERENCES admarkify.users(id),
    email       VARCHAR(255) NOT NULL,
    role        VARCHAR(32) NOT NULL DEFAULT 'executive',
    token_hash  TEXT        NOT NULL UNIQUE,
    status      VARCHAR(32) NOT NULL DEFAULT 'pending',
    expires_at  TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '48 hours'),
    accepted_at TIMESTAMPTZ,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_invite_role   CHECK (role   IN ('admin','manager','lead','executive')),
    CONSTRAINT chk_invite_status CHECK (status IN ('pending','accepted','expired','cancelled'))
);

CREATE INDEX IF NOT EXISTS idx_invites_org   ON admarkify.team_invitations(org_id);
CREATE INDEX IF NOT EXISTS idx_invites_email ON admarkify.team_invitations(email);
CREATE INDEX IF NOT EXISTS idx_invites_token ON admarkify.team_invitations(token_hash);


-- ------------------------------------------------------------
--  2F. LOGIN ATTEMPTS  (brute-force tracking)
-- ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS admarkify.login_attempts (
    id              BIGSERIAL    PRIMARY KEY,
    email           VARCHAR(255) NOT NULL,
    ip_address      INET,
    success         BOOLEAN      NOT NULL DEFAULT FALSE,
    failure_reason  VARCHAR(100),
    --  user_not_found | wrong_password | user_suspended
    --  org_not_found  | org_inactive   | not_a_member
    --  invite_pending | member_suspended | plan_expired
    attempted_at    TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_login_attempts_email
    ON admarkify.login_attempts(email, attempted_at);
CREATE INDEX IF NOT EXISTS idx_login_attempts_ip
    ON admarkify.login_attempts(ip_address, attempted_at);


-- ============================================================
--  SECTION 3 — PLAN LIMIT GUARD
-- ============================================================

CREATE OR REPLACE FUNCTION admarkify.fn_check_team_member_limit(p_org_id UUID)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
    v_org   admarkify.organizations%ROWTYPE;
    v_plan  admarkify.subscription_plans%ROWTYPE;
    v_count INT;
BEGIN
    SELECT * INTO v_org
    FROM admarkify.organizations WHERE id = p_org_id;

    IF NOT FOUND          THEN RAISE EXCEPTION 'ORG_NOT_FOUND: %', p_org_id; END IF;
    IF NOT v_org.is_active THEN RAISE EXCEPTION 'ORG_INACTIVE';               END IF;

    IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
        RAISE EXCEPTION 'PLAN_EXPIRED: expired at %', v_org.plan_expires_at;
    END IF;

    SELECT * INTO v_plan
    FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- NULL max_team_members = unlimited (Pro)
    IF v_plan.max_team_members IS NULL THEN RETURN; END IF;

    SELECT COUNT(*) INTO v_count
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND status = 'active';

    IF v_count >= v_plan.max_team_members THEN
        RAISE EXCEPTION
            'PLAN_LIMIT_TEAM_MEMBERS: plan "%" allows max % members (currently %)',
            v_plan.name, v_plan.max_team_members, v_count;
    END IF;
END;
$$;


-- ============================================================
--  SECTION 4 — AUTHENTICATION FUNCTIONS
-- ============================================================

-- ------------------------------------------------------------
--  4A. admarkify.fn_register_user
--  Creates a new user account. Hashes password with bcrypt.
--  Returns new user UUID.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_register_user(
    p_email     VARCHAR,
    p_password  TEXT,
    p_full_name VARCHAR
)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE v_user_id UUID;
BEGIN
    p_email := LOWER(TRIM(p_email));

    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_email) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_email;
    END IF;

    INSERT INTO admarkify.users (email, password_hash, full_name)
    VALUES (p_email, crypt(p_password, gen_salt('bf', 10)), p_full_name)
    RETURNING id INTO v_user_id;

    RETURN v_user_id;
END;
$$;


-- ------------------------------------------------------------
--  4B. admarkify.fn_create_organization
--  Creates an org and auto-adds the owner as admin member.
--  Returns new org UUID.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_create_organization(
    p_owner_user_id UUID,
    p_org_name      VARCHAR,
    p_slug          VARCHAR,
    p_plan_id       INT         DEFAULT 1,      -- 1=Free 2=Paid 3=Pro
    p_timezone      VARCHAR     DEFAULT 'UTC'
)
RETURNS UUID LANGUAGE plpgsql AS $$
DECLARE
    v_org_id UUID;
    v_email  VARCHAR;
BEGIN
    p_slug := LOWER(TRIM(p_slug));

    IF EXISTS (SELECT 1 FROM admarkify.organizations WHERE slug = p_slug) THEN
        RAISE EXCEPTION 'SLUG_TAKEN: "%" is already in use', p_slug;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM admarkify.subscription_plans
        WHERE id = p_plan_id AND is_active = TRUE
    ) THEN
        RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=% is invalid or inactive', p_plan_id;
    END IF;

    SELECT email INTO v_email FROM admarkify.users WHERE id = p_owner_user_id;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: user_id=% does not exist', p_owner_user_id;
    END IF;

    INSERT INTO admarkify.organizations (name, slug, plan_id, owner_email, timezone)
    VALUES (p_org_name, p_slug, p_plan_id, v_email, p_timezone)
    RETURNING id INTO v_org_id;

    -- Owner auto-joins as admin, no invite required
    INSERT INTO admarkify.organization_members (org_id, user_id, role, status, joined_at)
    VALUES (v_org_id, p_owner_user_id, 'admin', 'active', NOW());

    RETURN v_org_id;
END;
$$;


-- ------------------------------------------------------------
--  4C. admarkify.fn_login
--  Authenticates a user for a specific org (identified by slug).
--
--  10-step check order:
--    1  User exists              → AUTH_FAILED
--    2  Password correct         → AUTH_FAILED
--    3  User account active      → ACCOUNT_SUSPENDED
--    4  Org exists               → ORG_NOT_FOUND
--    5  Org active               → ORG_INACTIVE
--    6  User is member of org    → NOT_A_MEMBER
--    7  Membership status        → INVITE_PENDING / MEMBER_SUSPENDED
--    8  Plan not expired         → PLAN_EXPIRED
--    9  Create session token
--   10  Return JSONB payload
--
--  Returned JSONB keys:
--    raw_token   ← send to client in Authorization header, NEVER log
--    session_id, expires_at
--    user        ← id, email, full_name, avatar_url, is_verified
--    org         ← id, name, slug, timezone
--    membership  ← role, status, joined_at
--    plan        ← name, plan_type, max_team_members
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_login(
    p_email      VARCHAR,
    p_password   TEXT,
    p_org_slug   VARCHAR,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    p_email    := LOWER(TRIM(p_email));
    p_org_slug := LOWER(TRIM(p_org_slug));

    -- Step 1: find user ────────────────────────────────────────
    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
    END IF;

    -- Step 2: verify password ──────────────────────────────────
    IF v_user.password_hash != crypt(p_password, v_user.password_hash) THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'wrong_password');
        RAISE EXCEPTION 'AUTH_FAILED: invalid email or password';
    END IF;

    -- Step 3: user account active? ─────────────────────────────
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- Step 4: find org ─────────────────────────────────────────
    SELECT * INTO v_org FROM admarkify.organizations WHERE slug = p_org_slug;
    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'org_not_found');
        RAISE EXCEPTION 'ORG_NOT_FOUND: "%" does not exist', p_org_slug;
    END IF;

    IF NOT v_org.is_active THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'org_inactive');
        RAISE EXCEPTION 'ORG_INACTIVE: organization has been disabled';
    END IF;

    -- Step 5: user is a member? ────────────────────────────────
    SELECT * INTO v_member
    FROM admarkify.organization_members
    WHERE org_id = v_org.id AND user_id = v_user.id;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'not_a_member');
        RAISE EXCEPTION 'NOT_A_MEMBER: user is not in org "%"', p_org_slug;
    END IF;

    -- Step 6: membership status ────────────────────────────────
    IF v_member.status = 'invited' THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'invite_pending');
        RAISE EXCEPTION 'INVITE_PENDING: accept the invitation before logging in';
    END IF;

    IF v_member.status = 'suspended' THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'member_suspended');
        RAISE EXCEPTION 'MEMBER_SUSPENDED: user is suspended from "%"', p_org_slug;
    END IF;

    -- Step 7: plan expiry ──────────────────────────────────────
    IF v_org.plan_expires_at IS NOT NULL AND v_org.plan_expires_at < NOW() THEN
        INSERT INTO admarkify.login_attempts (email, ip_address, success, failure_reason)
        VALUES (p_email, p_ip_address, FALSE, 'plan_expired');
        RAISE EXCEPTION 'PLAN_EXPIRED: subscription expired at %', v_org.plan_expires_at;
    END IF;

    SELECT * INTO v_plan
    FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- Step 8: create session ───────────────────────────────────
    -- 80-char hex raw token; only SHA-256 hash stored in DB
    v_raw_token  := encode(gen_random_bytes(40), 'hex');
    v_token_hash := encode(digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    -- Step 9: bookkeeping ──────────────────────────────────────
    UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;

    INSERT INTO admarkify.login_attempts (email, ip_address, success)
    VALUES (p_email, p_ip_address, TRUE);

    -- Step 10: return payload ──────────────────────────────────
    RETURN jsonb_build_object(
        'raw_token',    v_raw_token,            -- ⚠ send to client, NEVER log
        'session_id',   v_session_id,
        'expires_at',   NOW() + INTERVAL '7 days',

        'user', jsonb_build_object(
            'id',           v_user.id,
            'email',        v_user.email,
            'full_name',    v_user.full_name,
            'avatar_url',   v_user.avatar_url,
            'is_verified',  v_user.is_verified
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    v_member.status,
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members    -- NULL = unlimited
        )
    );
END;
$$;


-- ------------------------------------------------------------
--  4D. admarkify.fn_verify_session
--  Call on EVERY authenticated API request.
--  Pass the raw token from the Authorization header.
--  Slides last_used_at on each valid call.
--  Returns session context JSONB or raises SESSION_INVALID.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_verify_session(p_raw_token TEXT)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_token_hash TEXT;
    v_session    admarkify.user_sessions%ROWTYPE;
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
BEGIN
    v_token_hash := encode(digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_session
    FROM admarkify.user_sessions
    WHERE token_hash = v_token_hash
      AND is_active   = TRUE
      AND expires_at  > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'SESSION_INVALID: token expired, revoked, or not found';
    END IF;

    -- Slide activity window
    UPDATE admarkify.user_sessions
    SET last_used_at = NOW() WHERE id = v_session.id;

    SELECT * INTO v_user FROM admarkify.users         WHERE id = v_session.user_id;
    SELECT * INTO v_org  FROM admarkify.organizations WHERE id = v_session.org_id;

    IF NOT v_user.is_active THEN RAISE EXCEPTION 'ACCOUNT_SUSPENDED'; END IF;
    IF NOT v_org.is_active  THEN RAISE EXCEPTION 'ORG_INACTIVE';       END IF;

    RETURN jsonb_build_object(
        'session_id',   v_session.id,
        'user_id',      v_session.user_id,
        'org_id',       v_session.org_id,
        'role',         v_session.role,         -- use this for permission checks
        'expires_at',   v_session.expires_at,
        'org_slug',     v_org.slug,
        'org_timezone', v_org.timezone,
        'user_email',   v_user.email,
        'user_name',    v_user.full_name
    );
END;
$$;


-- ------------------------------------------------------------
--  4E. admarkify.fn_logout   — revoke a single session
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_logout(p_raw_token TEXT)
RETURNS BOOLEAN LANGUAGE plpgsql AS $$
DECLARE
    v_token_hash TEXT;
    v_rows       INT;
BEGIN
    v_token_hash := encode(digest(p_raw_token, 'sha256'), 'hex');

    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE token_hash = v_token_hash AND is_active = TRUE;

    GET DIAGNOSTICS v_rows = ROW_COUNT;
    RETURN v_rows > 0;      -- TRUE  = session was revoked
                            -- FALSE = token was already inactive / not found
END;
$$;


-- ------------------------------------------------------------
--  4F. admarkify.fn_logout_all
--  Revokes ALL active sessions for a user across all orgs.
--  Use on password change or account compromise.
--  Returns count of revoked sessions.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_logout_all(p_user_id UUID)
RETURNS INT LANGUAGE plpgsql AS $$
DECLARE v_count INT;
BEGIN
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = p_user_id AND is_active = TRUE;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;


-- ============================================================
--  SECTION 5 — TEAM MANAGEMENT FUNCTIONS
-- ============================================================

-- ------------------------------------------------------------
--  5A. admarkify.fn_invite_member
--  Admin sends an invitation link to a new team member.
--  Checks plan seat limit before issuing the invite.
--  Returns raw_token — embed this in the invite e-mail URL.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_invite_member(
    p_org_id     UUID,
    p_invited_by UUID,
    p_email      VARCHAR,
    p_role       VARCHAR DEFAULT 'executive'    -- admin|manager|lead|executive
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_invite_id  UUID;
BEGIN
    p_email := LOWER(TRIM(p_email));

    IF p_role NOT IN ('admin','manager','lead','executive') THEN
        RAISE EXCEPTION 'INVALID_ROLE: "%" — use admin|manager|lead|executive', p_role;
    END IF;

    -- Plan seat check
    PERFORM admarkify.fn_check_team_member_limit(p_org_id);

    -- Already an active/invited member?
    IF EXISTS (
        SELECT 1
        FROM admarkify.organization_members om
        JOIN admarkify.users u ON u.id = om.user_id
        WHERE om.org_id = p_org_id
          AND u.email   = p_email
          AND om.status != 'suspended'
    ) THEN
        RAISE EXCEPTION 'ALREADY_MEMBER: % is already in this organization', p_email;
    END IF;

    -- Cancel any outstanding invite for same email + org
    UPDATE admarkify.team_invitations
    SET status = 'cancelled', updated_at = NOW()
    WHERE org_id = p_org_id AND email = p_email AND status = 'pending';

    -- Generate invite token (64-char hex; only hash stored)
    v_raw_token  := encode(gen_random_bytes(32), 'hex');
    v_token_hash := encode(digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.team_invitations (org_id, invited_by, email, role, token_hash)
    VALUES (p_org_id, p_invited_by, p_email, p_role, v_token_hash)
    RETURNING id INTO v_invite_id;

    RETURN jsonb_build_object(
        'invite_id',  v_invite_id,
        'raw_token',  v_raw_token,      -- ⚠ embed in e-mail URL, NEVER log
        'email',      p_email,
        'role',       p_role,
        'expires_at', NOW() + INTERVAL '48 hours'
    );
END;
$$;


-- ------------------------------------------------------------
--  5B. admarkify.fn_accept_invite
--  Called when the invited user clicks the e-mail link.
--
--  New user      → supply p_full_name + p_password
--                  account is created & auto-verified
--                  returns full fn_login() JSONB payload
--
--  Existing user → leave p_password NULL
--                  returns ACCEPTED_LOGIN_REQUIRED status
--                  caller must then call fn_login() separately
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_accept_invite(
    p_raw_token  TEXT,
    p_full_name  VARCHAR DEFAULT NULL,
    p_password   TEXT    DEFAULT NULL,
    p_ip_address INET    DEFAULT NULL,
    p_user_agent TEXT    DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_token_hash TEXT;
    v_invite     admarkify.team_invitations%ROWTYPE;
    v_user_id    UUID;
    v_org        admarkify.organizations%ROWTYPE;
BEGIN
    v_token_hash := encode(digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: token not found or already used';
    END IF;

    IF v_invite.expires_at < NOW() THEN
        UPDATE admarkify.team_invitations
        SET status = 'expired', updated_at = NOW()
        WHERE id = v_invite.id;
        RAISE EXCEPTION 'INVITE_EXPIRED: expired at %', v_invite.expires_at;
    END IF;

    SELECT * INTO v_org
    FROM admarkify.organizations WHERE id = v_invite.org_id;

    -- Find or create user account
    SELECT id INTO v_user_id
    FROM admarkify.users WHERE email = v_invite.email;

    IF NOT FOUND THEN
        IF p_password IS NULL OR p_full_name IS NULL THEN
            RAISE EXCEPTION
                'NEW_USER_REQUIRED: provide full_name and password for new accounts';
        END IF;
        v_user_id := admarkify.fn_register_user(v_invite.email, p_password, p_full_name);
        -- Auto-verify — they clicked an org invite link
        UPDATE admarkify.users SET is_verified = TRUE WHERE id = v_user_id;
    END IF;

    -- Upsert membership as active
    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user_id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role      = EXCLUDED.role,
            status    = 'active',
            joined_at = NOW(),
            updated_at = NOW();

    -- Consume invite
    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    -- New user with password → return a ready session
    IF p_password IS NOT NULL THEN
        RETURN admarkify.fn_login(
            v_invite.email, p_password,
            v_org.slug, p_ip_address, p_user_agent
        );
    END IF;

    -- Existing user → instruct caller to log in normally
    RETURN jsonb_build_object(
        'status',   'ACCEPTED_LOGIN_REQUIRED',
        'message',  'Membership activated. Please log in with your existing password.',
        'org_slug', v_org.slug,
        'email',    v_invite.email
    );
END;
$$;


-- ------------------------------------------------------------
--  5C. admarkify.fn_update_member_role
--  Only an active admin of the org may change a member's role.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_update_member_role(
    p_org_id         UUID,
    p_actor_user_id  UUID,
    p_target_user_id UUID,
    p_new_role       VARCHAR
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_user_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can change member roles';
    END IF;

    IF p_new_role NOT IN ('admin','manager','lead','executive') THEN
        RAISE EXCEPTION 'INVALID_ROLE: "%"', p_new_role;
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM admarkify.organization_members
        WHERE org_id = p_org_id AND user_id = p_target_user_id
    ) THEN
        RAISE EXCEPTION 'MEMBER_NOT_FOUND';
    END IF;

    UPDATE admarkify.organization_members
    SET role = p_new_role, updated_at = NOW()
    WHERE org_id = p_org_id AND user_id = p_target_user_id;
END;
$$;


-- ------------------------------------------------------------
--  5D. admarkify.fn_remove_member
--  Admin suspends a member and immediately revokes all their
--  sessions within this org.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_remove_member(
    p_org_id         UUID,
    p_actor_user_id  UUID,
    p_target_user_id UUID
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_user_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can remove members';
    END IF;

    IF p_actor_user_id = p_target_user_id THEN
        RAISE EXCEPTION 'CANNOT_REMOVE_SELF: admins cannot remove themselves';
    END IF;

    UPDATE admarkify.organization_members
    SET status = 'suspended', updated_at = NOW()
    WHERE org_id = p_org_id AND user_id = p_target_user_id;

    -- Immediately revoke all sessions in this org
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = p_target_user_id AND org_id = p_org_id;
END;
$$;


-- ============================================================
--  SECTION 6 — PLAN UPGRADE
-- ============================================================

CREATE OR REPLACE FUNCTION admarkify.fn_upgrade_plan(
    p_org_id      UUID,
    p_new_plan_id INT,
    p_expires_at  TIMESTAMPTZ DEFAULT NULL      -- NULL = no expiry
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_org      admarkify.organizations%ROWTYPE;
    v_old_plan admarkify.subscription_plans%ROWTYPE;
    v_new_plan admarkify.subscription_plans%ROWTYPE;
BEGIN
    SELECT * INTO v_org FROM admarkify.organizations WHERE id = p_org_id;
    IF NOT FOUND THEN RAISE EXCEPTION 'ORG_NOT_FOUND'; END IF;

    SELECT * INTO v_old_plan
    FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    SELECT * INTO v_new_plan
    FROM admarkify.subscription_plans WHERE id = p_new_plan_id AND is_active = TRUE;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=% is invalid or inactive', p_new_plan_id;
    END IF;

    UPDATE admarkify.organizations
    SET plan_id = p_new_plan_id, plan_expires_at = p_expires_at, updated_at = NOW()
    WHERE id = p_org_id;

    RETURN jsonb_build_object(
        'org_id',     p_org_id,
        'old_plan',   v_old_plan.name,
        'new_plan',   v_new_plan.name,
        'expires_at', p_expires_at
    );
END;
$$;


-- ============================================================
--  SECTION 7 — HOUSEKEEPING  (schedule nightly with pg_cron)
-- ============================================================

-- Deactivate expired sessions; hard-delete after 30 days
CREATE OR REPLACE FUNCTION admarkify.fn_cleanup_expired_sessions()
RETURNS INT LANGUAGE plpgsql AS $$
DECLARE v_n INT;
BEGIN
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE is_active = TRUE AND expires_at < NOW();

    DELETE FROM admarkify.user_sessions
    WHERE is_active = FALSE
      AND expires_at < NOW() - INTERVAL '30 days';

    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$;

-- Mark stale pending invitations as expired
CREATE OR REPLACE FUNCTION admarkify.fn_cleanup_expired_invites()
RETURNS INT LANGUAGE plpgsql AS $$
DECLARE v_n INT;
BEGIN
    UPDATE admarkify.team_invitations
    SET status = 'expired', updated_at = NOW()
    WHERE status = 'pending' AND expires_at < NOW();

    GET DIAGNOSTICS v_n = ROW_COUNT;
    RETURN v_n;
END;
$$;


-- ============================================================
--  QUICK REFERENCE
-- ============================================================
--
--  1. Register user
--     SELECT admarkify.fn_register_user('alice@acme.com', 'Pass123!', 'Alice S');
--
--  2. Create org  (owner auto-added as admin)
--     SELECT admarkify.fn_create_organization(
--         '<user_uuid>', 'Acme Corp', 'acme', 1, 'Asia/Kolkata'
--     );
--     -- plan_id:  1 = Free (3 seats)  |  2 = Paid (10 seats)  |  3 = Pro (unlimited)
--
--  3. Login  →  returns raw_token + full context JSONB
--     SELECT admarkify.fn_login(
--         'alice@acme.com', 'Pass123!', 'acme', '1.2.3.4', 'Mozilla/5.0'
--     );
--
--  4. Verify session  (call on EVERY authenticated API request)
--     SELECT admarkify.fn_verify_session('<raw_token_from_Authorization_header>');
--
--  5. Invite team member  →  returns raw_token for invite e-mail URL
--     SELECT admarkify.fn_invite_member(
--         '<org_uuid>', '<admin_uuid>', 'bob@acme.com', 'lead'
--     );
--     -- Roles: admin | manager | lead | executive
--
--  6a. Accept invite — NEW user
--     SELECT admarkify.fn_accept_invite('<invite_token>', 'Bob K', 'BobPass1!');
--
--  6b. Accept invite — EXISTING user  (then call fn_login separately)
--     SELECT admarkify.fn_accept_invite('<invite_token>');
--
--  7. Update member role
--     SELECT admarkify.fn_update_member_role('<org>', '<admin>', '<target>', 'manager');
--
--  8. Remove member  (suspends + revokes sessions in this org)
--     SELECT admarkify.fn_remove_member('<org>', '<admin>', '<target>');
--
--  9. Upgrade plan
--     SELECT admarkify.fn_upgrade_plan('<org_uuid>', 3, NOW() + INTERVAL '1 year');
--     -- plan_id 3 = Pro (unlimited seats)
--
-- 10. Logout
--     SELECT admarkify.fn_logout('<raw_token>');               -- single session
--     SELECT admarkify.fn_logout_all('<user_uuid>');           -- all sessions, all orgs
--
-- 11. Housekeeping  (pg_cron — run nightly)
--     SELECT admarkify.fn_cleanup_expired_sessions();
--     SELECT admarkify.fn_cleanup_expired_invites();
--
-- ============================================================