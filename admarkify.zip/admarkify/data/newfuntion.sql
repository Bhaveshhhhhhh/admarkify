create metadata json user_otps
end_point text  channel_providers 

CREATE OR REPLACE FUNCTION admarkify.fn_accept_invite(
    p_raw_token  TEXT,
    p_full_name  VARCHAR DEFAULT NULL,
    p_password   TEXT    DEFAULT NULL,
    p_mobile     VARCHAR DEFAULT NULL,
    p_ip_address INET    DEFAULT NULL,
    p_user_agent TEXT    DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
AS $BODY$
DECLARE
    v_token_hash  TEXT;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_user        admarkify.users%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_email_otp   TEXT;
    v_mobile_otp  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    -- 🔍 Validate invite — do NOT consume yet
    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: token not found or already used';
    END IF;

    IF v_invite.expires_at < NOW() THEN
        UPDATE admarkify.team_invitations
        SET status = 'expired', updated_at = NOW()
        WHERE id = v_invite.id;
        RAISE EXCEPTION 'INVITE_EXPIRED: expired at %', v_invite.expires_at;
    END IF;

    -- 🔍 Get org
    SELECT * INTO v_org FROM admarkify.organizations WHERE id = v_invite.org_id;

    -- 🔍 Find user by invite email
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = v_invite.email;

    IF FOUND AND (v_user.is_email_verified AND v_user.is_mobile_verified) THEN

        -- ════════════════════════════════════════════════════
        -- ✅ EXISTING + FULLY VERIFIED USER
        -- Skip OTP → check limit, consume invite,
        --            activate membership, create session
        -- ════════════════════════════════════════════════════

        SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

        -- 🚫 Check seat limit before activating membership
        PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

        -- Consume invite
        UPDATE admarkify.team_invitations
        SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
        WHERE id = v_invite.id;

        -- Activate membership
        INSERT INTO admarkify.organization_members
            (org_id, user_id, role, status, invited_by, joined_at)
        VALUES
            (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
        ON CONFLICT (org_id, user_id) DO UPDATE
            SET role       = EXCLUDED.role,
                status     = 'active',
                joined_at  = NOW(),
                updated_at = NOW()
        RETURNING * INTO v_member;

        -- Create session
        v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
        v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

        INSERT INTO admarkify.user_sessions
            (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
        VALUES
            (v_user.id, v_org.id, v_token_hash2, v_member.role,
             p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
        RETURNING id INTO v_session_id;

        UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;

        RETURN jsonb_build_object(
            'is_new_user', FALSE,
            'raw_token',   v_raw_token,
            'session_id',  v_session_id,
            'expires_at',  NOW() + INTERVAL '7 days',
            'user', jsonb_build_object(
                'id',          v_user.id,
                'email',       v_user.email,
                'full_name',   v_user.full_name,
                'avatar_url',  v_user.avatar_url,
                'is_verified', TRUE
            ),
            'org', jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            ),
            'membership', jsonb_build_object(
                'role',      v_member.role,
                'status',    'active',
                'joined_at', v_member.joined_at
            ),
            'plan', jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
        );

    ELSE

        -- ════════════════════════════════════════════════════
        -- 🆕 NEW USER  ── or ──  EXISTING BUT UNVERIFIED USER
        -- Validate fields, create/update user, send OTPs
        -- Limit check deferred to fn_verify_invite_otp
        -- ════════════════════════════════════════════════════

        -- 🚫 Validate required fields
        IF p_full_name IS NULL OR TRIM(p_full_name) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: full_name is required';
        END IF;

        IF p_password IS NULL OR TRIM(p_password) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: password is required';
        END IF;

        IF p_mobile IS NULL OR TRIM(p_mobile) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: mobile is required';
        END IF;

        IF NOT FOUND THEN
            -- Brand new user — create record (inactive until verified)
            INSERT INTO admarkify.users (email, password_hash, full_name, mobile, is_active)
            VALUES (
                v_invite.email,
                public.crypt(p_password, public.gen_salt('bf', 10)),
                p_full_name,
                p_mobile,
                FALSE
            )
            RETURNING * INTO v_user;

        ELSE
            -- Exists but unverified — refresh details + reset verification flags
            UPDATE admarkify.users
            SET password_hash      = public.crypt(p_password, public.gen_salt('bf', 10)),
                full_name          = p_full_name,
                mobile             = p_mobile,
                is_email_verified  = FALSE,
                is_mobile_verified = FALSE,
                is_active          = FALSE,
                updated_at         = NOW()
            WHERE id = v_user.id
            RETURNING * INTO v_user;
        END IF;

        -- 🔢 Expire any leftover invite OTPs
        UPDATE admarkify.user_otps
        SET is_used = TRUE
        WHERE user_id = v_user.id
          AND otp_type IN ('invite_email', 'invite_mobile')
          AND is_used = FALSE;

        -- 🔢 Generate fresh OTPs
        v_email_otp  := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');
        v_mobile_otp := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

        INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
        VALUES
            (v_user.id, v_email_otp,  'invite_email',  NOW() + INTERVAL '10 minutes'),
            (v_user.id, v_mobile_otp, 'invite_mobile', NOW() + INTERVAL '10 minutes');

        RETURN jsonb_build_object(
            'is_new_user',   TRUE,
            'user_id',       v_user.id,
            'email',         v_user.email,
            'email_masked',  CONCAT(
                                 LEFT(v_user.email, 2),
                                 '***@',
                                 SPLIT_PART(v_user.email, '@', 2)
                             ),
            'mobile',        v_user.mobile,
            'mobile_masked', CONCAT('***', RIGHT(v_user.mobile, 3)),
            'email_otp',     v_email_otp,
            'mobile_otp',    v_mobile_otp
        );

    END IF;
END;
$BODY$;


CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp(
    p_email      VARCHAR,
    p_mobile     VARCHAR,
    p_otp        VARCHAR,
    p_type       VARCHAR,
    p_raw_token  TEXT,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
AS $BODY$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- 🔍 Resolve user by email + mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = p_email AND mobile = p_mobile
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response, no limit check yet
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → validate invite + check limit +
    --                    finalize membership + create session
    -- ════════════════════════════════════════════════════════

    -- 🔍 Validate + consume invite
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    -- 🔍 Get org + plan
    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- 🚫 Check seat limit before activating membership
    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    -- ✅ Consume invite
    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    -- ✅ Create / activate membership
    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    -- ✅ Activate user account
    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- 🎉 Create session
    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$BODY$;


-- ============================================================
-- 1. REQUEST OTP FOR CHANGE PASSWORD
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_password(
    p_email      VARCHAR,
    p_ip_address INET DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_password'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'change_password', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id', v_user.id,
        'email',   v_user.email,
        'mobile',  v_user.mobile,
        'otp',     v_otp_code
    );
END;
$$;


-- ============================================================
-- 2. VERIFY OTP + CHANGE PASSWORD
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_password(
    p_email        VARCHAR,
    p_otp          VARCHAR,
    p_new_password TEXT
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user admarkify.users%ROWTYPE;
    v_otp  admarkify.user_otps%ROWTYPE;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_password'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update password
    UPDATE admarkify.users
    SET password_hash = public.crypt(p_new_password, public.gen_salt('bf', 10)),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- Revoke all sessions for security
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = v_user.id AND is_active = TRUE;

    RETURN jsonb_build_object(
        'message',          'Password changed successfully',
        'email',            v_user.email,
        'sessions_revoked', TRUE
    );
END;
$$;


-- ============================================================
-- 3. REQUEST OTP FOR CHANGE EMAIL
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_email(
    p_email     VARCHAR,
    p_new_email VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email     := LOWER(TRIM(p_email));
    p_new_email := LOWER(TRIM(p_new_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New email must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_new_email;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_email'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_email',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_email', p_new_email)
    );

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'new_email', p_new_email,
        'otp',       v_otp_code   -- send this to new_email
    );
END;
$$;


-- ============================================================
-- 4. VERIFY OTP + CHANGE EMAIL
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_email(
    p_email VARCHAR,
    p_otp   VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user      admarkify.users%ROWTYPE;
    v_otp       admarkify.user_otps%ROWTYPE;
    v_new_email TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_email'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new email from metadata
    v_new_email := v_otp.metadata ->> 'new_email';

    IF v_new_email IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing email metadata';
    END IF;

    -- Double-check new email not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = v_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', v_new_email;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update email
    UPDATE admarkify.users
    SET email             = v_new_email,
        is_email_verified = TRUE,
        updated_at        = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',   'Email changed successfully',
        'old_email', p_email,
        'new_email', v_new_email
    );
END;
$$;


-- ============================================================
-- 5. REQUEST OTP FOR CHANGE MOBILE
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_mobile(
    p_email      VARCHAR,
    p_new_mobile VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New mobile must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = p_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', p_new_mobile;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_mobile'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_mobile',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_mobile', p_new_mobile)
    );

    RETURN jsonb_build_object(
        'user_id',    v_user.id,
        'email',      v_user.email,
        'new_mobile', p_new_mobile,
        'otp',        v_otp_code   -- send this via SMS
    );
END;
$$;


-- ============================================================
-- 6. VERIFY OTP + CHANGE MOBILE
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_mobile(
    p_email VARCHAR,
    p_otp   VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_otp        admarkify.user_otps%ROWTYPE;
    v_new_mobile TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_mobile'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new mobile from metadata
    v_new_mobile := v_otp.metadata ->> 'new_mobile';

    IF v_new_mobile IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing mobile metadata';
    END IF;

    -- Double-check not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = v_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', v_new_mobile;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update mobile
    UPDATE admarkify.users
    SET mobile             = v_new_mobile,
        is_mobile_verified = TRUE,
        updated_at         = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'Mobile changed successfully',
        'email',      v_user.email,
        'new_mobile', v_new_mobile
    );
END;
$$;


CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp_single(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_otp        VARCHAR  DEFAULT NULL,
    p_type       VARCHAR  DEFAULT NULL,
    p_raw_token  TEXT     DEFAULT NULL,
    p_ip_address INET     DEFAULT NULL,
    p_user_agent TEXT     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → finalize invite + create session
    -- ════════════════════════════════════════════════════════
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$$;


-- ============================================================
-- fn_verify_otp — email OR mobile (not both required)
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_verify_otp(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_otp        VARCHAR,
    p_type       VARCHAR,
    p_ip_address INET     DEFAULT NULL,
    p_user_agent TEXT     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_otp        RECORD;
    v_user       admarkify.users%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification status
    IF p_type = 'email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE
        WHERE id = v_user.id;
    ELSIF p_type = 'mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- 🎉 FULLY VERIFIED → CREATE SESSION
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, NULL, v_token_hash, 'admin',
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    UPDATE admarkify.users
    SET last_login_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'User verified successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', NULL
    );
END;
$$;


-- ============================================================
-- fn_send_login_otp — email OR mobile (not both required)
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_send_login_otp(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_ip_address INET     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    IF p_email IS NOT NULL THEN
        p_email := LOWER(TRIM(p_email));
    END IF;

    -- 🔍 Find user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (COALESCE(p_email, p_mobile), p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: user not found';
    END IF;

    -- 🚫 Account active?
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (v_user.email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- 🚫 Verified check based on which identifier was provided
    IF p_email IS NOT NULL AND NOT v_user.is_email_verified THEN
        RAISE EXCEPTION 'EMAIL_NOT_VERIFIED: verify your email before logging in';
    END IF;

    IF p_mobile IS NOT NULL AND NOT v_user.is_mobile_verified THEN
        RAISE EXCEPTION 'MOBILE_NOT_VERIFIED: verify your mobile before logging in';
    END IF;

    -- 🔢 Expire existing unused login OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id  = v_user.id
      AND otp_type = 'login'
      AND is_used  = FALSE;

    -- 🔢 Generate 6-digit OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'login', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'mobile',    v_user.mobile,
        'login_otp', v_otp_code
    );
END;
$$;