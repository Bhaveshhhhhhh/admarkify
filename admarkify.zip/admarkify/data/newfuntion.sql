create metadata json user_otps
end_point text  channel_providers 

CREATE OR REPLACE FUNCTION admarkify.fn_accept_invite(
    p_raw_token  TEXT,
    p_full_name  VARCHAR DEFAULT NULL,
    p_password   TEXT    DEFAULT NULL,
    p_mobile     VARCHAR DEFAULT NULL,
    p_ip_address INET    DEFAULT NULL,
    p_user_agent TEXT    DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
AS $BODY$
DECLARE
    v_token_hash  TEXT;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_user        admarkify.users%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_email_otp   TEXT;
    v_mobile_otp  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    -- 🔍 Validate invite — do NOT consume yet
    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: token not found or already used';
    END IF;

    IF v_invite.expires_at < NOW() THEN
        UPDATE admarkify.team_invitations
        SET status = 'expired', updated_at = NOW()
        WHERE id = v_invite.id;
        RAISE EXCEPTION 'INVITE_EXPIRED: expired at %', v_invite.expires_at;
    END IF;

    -- 🔍 Get org
    SELECT * INTO v_org FROM admarkify.organizations WHERE id = v_invite.org_id;

    -- 🔍 Find user by invite email
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = v_invite.email;

    IF FOUND AND (v_user.is_email_verified AND v_user.is_mobile_verified) THEN

        -- ════════════════════════════════════════════════════
        -- ✅ EXISTING + FULLY VERIFIED USER
        -- Skip OTP → check limit, consume invite,
        --            activate membership, create session
        -- ════════════════════════════════════════════════════

        SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

        -- 🚫 Check seat limit before activating membership
        PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

        -- Consume invite
        UPDATE admarkify.team_invitations
        SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
        WHERE id = v_invite.id;

        -- Activate membership
        INSERT INTO admarkify.organization_members
            (org_id, user_id, role, status, invited_by, joined_at)
        VALUES
            (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
        ON CONFLICT (org_id, user_id) DO UPDATE
            SET role       = EXCLUDED.role,
                status     = 'active',
                joined_at  = NOW(),
                updated_at = NOW()
        RETURNING * INTO v_member;

        -- Create session
        v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
        v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

        INSERT INTO admarkify.user_sessions
            (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
        VALUES
            (v_user.id, v_org.id, v_token_hash2, v_member.role,
             p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
        RETURNING id INTO v_session_id;

        UPDATE admarkify.users SET last_login_at = NOW() WHERE id = v_user.id;

        RETURN jsonb_build_object(
            'is_new_user', FALSE,
            'raw_token',   v_raw_token,
            'session_id',  v_session_id,
            'expires_at',  NOW() + INTERVAL '7 days',
            'user', jsonb_build_object(
                'id',          v_user.id,
                'email',       v_user.email,
                'full_name',   v_user.full_name,
                'avatar_url',  v_user.avatar_url,
                'is_verified', TRUE
            ),
            'org', jsonb_build_object(
                'id',       v_org.id,
                'name',     v_org.name,
                'slug',     v_org.slug,
                'timezone', v_org.timezone
            ),
            'membership', jsonb_build_object(
                'role',      v_member.role,
                'status',    'active',
                'joined_at', v_member.joined_at
            ),
            'plan', jsonb_build_object(
                'name',             v_plan.name,
                'plan_type',        v_plan.plan_type,
                'max_team_members', v_plan.max_team_members
            )
        );

    ELSE

        -- ════════════════════════════════════════════════════
        -- 🆕 NEW USER  ── or ──  EXISTING BUT UNVERIFIED USER
        -- Validate fields, create/update user, send OTPs
        -- Limit check deferred to fn_verify_invite_otp
        -- ════════════════════════════════════════════════════

        -- 🚫 Validate required fields
        IF p_full_name IS NULL OR TRIM(p_full_name) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: full_name is required';
        END IF;

        IF p_password IS NULL OR TRIM(p_password) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: password is required';
        END IF;

        IF p_mobile IS NULL OR TRIM(p_mobile) = '' THEN
            RAISE EXCEPTION 'VALIDATION_ERROR: mobile is required';
        END IF;

        IF NOT FOUND THEN
            -- Brand new user — create record (inactive until verified)
            INSERT INTO admarkify.users (email, password_hash, full_name, mobile, is_active)
            VALUES (
                v_invite.email,
                public.crypt(p_password, public.gen_salt('bf', 10)),
                p_full_name,
                p_mobile,
                FALSE
            )
            RETURNING * INTO v_user;

        ELSE
            -- Exists but unverified — refresh details + reset verification flags
            UPDATE admarkify.users
            SET password_hash      = public.crypt(p_password, public.gen_salt('bf', 10)),
                full_name          = p_full_name,
                mobile             = p_mobile,
                is_email_verified  = FALSE,
                is_mobile_verified = FALSE,
                is_active          = FALSE,
                updated_at         = NOW()
            WHERE id = v_user.id
            RETURNING * INTO v_user;
        END IF;

        -- 🔢 Expire any leftover invite OTPs
        UPDATE admarkify.user_otps
        SET is_used = TRUE
        WHERE user_id = v_user.id
          AND otp_type IN ('invite_email', 'invite_mobile')
          AND is_used = FALSE;

        -- 🔢 Generate fresh OTPs
        v_email_otp  := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');
        v_mobile_otp := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

        INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
        VALUES
            (v_user.id, v_email_otp,  'invite_email',  NOW() + INTERVAL '10 minutes'),
            (v_user.id, v_mobile_otp, 'invite_mobile', NOW() + INTERVAL '10 minutes');

        RETURN jsonb_build_object(
            'is_new_user',   TRUE,
            'user_id',       v_user.id,
            'email',         v_user.email,
            'email_masked',  CONCAT(
                                 LEFT(v_user.email, 2),
                                 '***@',
                                 SPLIT_PART(v_user.email, '@', 2)
                             ),
            'mobile',        v_user.mobile,
            'mobile_masked', CONCAT('***', RIGHT(v_user.mobile, 3)),
            'email_otp',     v_email_otp,
            'mobile_otp',    v_mobile_otp
        );

    END IF;
END;
$BODY$;


CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp(
    p_email      VARCHAR,
    p_mobile     VARCHAR,
    p_otp        VARCHAR,
    p_type       VARCHAR,
    p_raw_token  TEXT,
    p_ip_address INET DEFAULT NULL,
    p_user_agent TEXT DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
AS $BODY$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- 🔍 Resolve user by email + mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE email = p_email AND mobile = p_mobile
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response, no limit check yet
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → validate invite + check limit +
    --                    finalize membership + create session
    -- ════════════════════════════════════════════════════════

    -- 🔍 Validate + consume invite
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    -- 🔍 Get org + plan
    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    -- 🚫 Check seat limit before activating membership
    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    -- ✅ Consume invite
    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    -- ✅ Create / activate membership
    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    -- ✅ Activate user account
    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- 🎉 Create session
    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$BODY$;


-- ============================================================
-- 1. REQUEST OTP FOR CHANGE PASSWORD
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_password(
    p_email      VARCHAR,
    p_ip_address INET DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_password'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'change_password', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id', v_user.id,
        'email',   v_user.email,
        'mobile',  v_user.mobile,
        'otp',     v_otp_code
    );
END;
$$;


-- ============================================================
-- 2. VERIFY OTP + CHANGE PASSWORD
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_password(
    p_email        VARCHAR,
    p_otp          VARCHAR,
    p_new_password TEXT
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user admarkify.users%ROWTYPE;
    v_otp  admarkify.user_otps%ROWTYPE;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_password'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update password
    UPDATE admarkify.users
    SET password_hash = public.crypt(p_new_password, public.gen_salt('bf', 10)),
        updated_at    = NOW()
    WHERE id = v_user.id;

    -- Revoke all sessions for security
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = v_user.id AND is_active = TRUE;

    RETURN jsonb_build_object(
        'message',          'Password changed successfully',
        'email',            v_user.email,
        'sessions_revoked', TRUE
    );
END;
$$;


-- ============================================================
-- 3. REQUEST OTP FOR CHANGE EMAIL
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_email(
    p_email     VARCHAR,
    p_new_email VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email     := LOWER(TRIM(p_email));
    p_new_email := LOWER(TRIM(p_new_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New email must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = p_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', p_new_email;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_email'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_email',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_email', p_new_email)
    );

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'new_email', p_new_email,
        'otp',       v_otp_code   -- send this to new_email
    );
END;
$$;


-- ============================================================
-- 4. VERIFY OTP + CHANGE EMAIL
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_email(
    p_email VARCHAR,
    p_otp   VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user      admarkify.users%ROWTYPE;
    v_otp       admarkify.user_otps%ROWTYPE;
    v_new_email TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_email'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new email from metadata
    v_new_email := v_otp.metadata ->> 'new_email';

    IF v_new_email IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing email metadata';
    END IF;

    -- Double-check new email not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE email = v_new_email AND id != v_user.id) THEN
        RAISE EXCEPTION 'EMAIL_TAKEN: % is already registered', v_new_email;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update email
    UPDATE admarkify.users
    SET email             = v_new_email,
        is_email_verified = TRUE,
        updated_at        = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',   'Email changed successfully',
        'old_email', p_email,
        'new_email', v_new_email
    );
END;
$$;


-- ============================================================
-- 5. REQUEST OTP FOR CHANGE MOBILE
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_request_change_mobile(
    p_email      VARCHAR,
    p_new_mobile VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    IF NOT v_user.is_active THEN
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED';
    END IF;

    -- New mobile must not already be taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = p_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', p_new_mobile;
    END IF;

    -- Expire old OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id = v_user.id
      AND otp_type = 'change_mobile'
      AND is_used = FALSE;

    -- Generate OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at, metadata)
    VALUES (
        v_user.id, v_otp_code, 'change_mobile',
        NOW() + INTERVAL '10 minutes',
        jsonb_build_object('new_mobile', p_new_mobile)
    );

    RETURN jsonb_build_object(
        'user_id',    v_user.id,
        'email',      v_user.email,
        'new_mobile', p_new_mobile,
        'otp',        v_otp_code   -- send this via SMS
    );
END;
$$;


-- ============================================================
-- 6. VERIFY OTP + CHANGE MOBILE
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_change_mobile(
    p_email VARCHAR,
    p_otp   VARCHAR
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user       admarkify.users%ROWTYPE;
    v_otp        admarkify.user_otps%ROWTYPE;
    v_new_mobile TEXT;
BEGIN
    p_email := LOWER(TRIM(p_email));

    SELECT * INTO v_user FROM admarkify.users WHERE email = p_email;
    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND: % not found', p_email;
    END IF;

    -- Validate OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = 'change_mobile'
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- Extract new mobile from metadata
    v_new_mobile := v_otp.metadata ->> 'new_mobile';

    IF v_new_mobile IS NULL THEN
        RAISE EXCEPTION 'INVALID_OTP: missing mobile metadata';
    END IF;

    -- Double-check not taken
    IF EXISTS (SELECT 1 FROM admarkify.users WHERE mobile = v_new_mobile AND id != v_user.id) THEN
        RAISE EXCEPTION 'MOBILE_TAKEN: % is already registered', v_new_mobile;
    END IF;

    -- Consume OTP
    UPDATE admarkify.user_otps SET is_used = TRUE WHERE id = v_otp.id;

    -- Update mobile
    UPDATE admarkify.users
    SET mobile             = v_new_mobile,
        is_mobile_verified = TRUE,
        updated_at         = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'Mobile changed successfully',
        'email',      v_user.email,
        'new_mobile', v_new_mobile
    );
END;
$$;


CREATE OR REPLACE FUNCTION admarkify.fn_verify_invite_otp_single(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_otp        VARCHAR  DEFAULT NULL,
    p_type       VARCHAR  DEFAULT NULL,
    p_raw_token  TEXT     DEFAULT NULL,
    p_ip_address INET     DEFAULT NULL,
    p_user_agent TEXT     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_otp         RECORD;
    v_user        admarkify.users%ROWTYPE;
    v_invite      admarkify.team_invitations%ROWTYPE;
    v_member      admarkify.organization_members%ROWTYPE;
    v_org         admarkify.organizations%ROWTYPE;
    v_plan        admarkify.subscription_plans%ROWTYPE;
    v_token_hash  TEXT;
    v_raw_token   TEXT;
    v_token_hash2 TEXT;
    v_session_id  UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid invite OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP: otp is incorrect or expired';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification flag
    IF p_type = 'invite_email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;

    ELSIF p_type = 'invite_mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE, updated_at = NOW()
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified yet → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- ════════════════════════════════════════════════════════
    -- 🎉 BOTH VERIFIED → finalize invite + create session
    -- ════════════════════════════════════════════════════════
    v_token_hash := encode(public.digest(p_raw_token, 'sha256'), 'hex');

    SELECT * INTO v_invite
    FROM admarkify.team_invitations
    WHERE token_hash = v_token_hash AND status = 'pending';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVITE_INVALID: invite no longer valid';
    END IF;

    SELECT * INTO v_org  FROM admarkify.organizations      WHERE id = v_invite.org_id;
    SELECT * INTO v_plan FROM admarkify.subscription_plans WHERE id = v_org.plan_id;

    PERFORM admarkify.fn_check_team_member_limit(v_invite.org_id);

    UPDATE admarkify.team_invitations
    SET status = 'accepted', accepted_at = NOW(), updated_at = NOW()
    WHERE id = v_invite.id;

    INSERT INTO admarkify.organization_members
        (org_id, user_id, role, status, invited_by, joined_at)
    VALUES
        (v_invite.org_id, v_user.id, v_invite.role, 'active', v_invite.invited_by, NOW())
    ON CONFLICT (org_id, user_id) DO UPDATE
        SET role       = EXCLUDED.role,
            status     = 'active',
            joined_at  = NOW(),
            updated_at = NOW()
    RETURNING * INTO v_member;

    UPDATE admarkify.users
    SET is_active     = TRUE,
        last_login_at = NOW(),
        updated_at    = NOW()
    WHERE id = v_user.id;

    v_raw_token   := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash2 := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, v_org.id, v_token_hash2, v_member.role,
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    RETURN jsonb_build_object(
        'message',    'Invite accepted successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),
        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    'active',
            'joined_at', v_member.joined_at
        ),
        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );
END;
$$;


-- ============================================================
-- fn_verify_otp — email OR mobile (not both required)
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_verify_otp(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_otp        VARCHAR,
    p_type       VARCHAR,
    p_ip_address INET     DEFAULT NULL,
    p_user_agent TEXT     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_otp        RECORD;
    v_user       admarkify.users%ROWTYPE;
    v_raw_token  TEXT;
    v_token_hash TEXT;
    v_session_id UUID;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    -- 🔍 Resolve user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'USER_NOT_FOUND';
    END IF;

    -- 🔍 Find valid OTP
    SELECT * INTO v_otp
    FROM admarkify.user_otps
    WHERE user_id  = v_user.id
      AND otp_code = p_otp
      AND otp_type = p_type
      AND is_used  = FALSE
      AND expires_at > NOW();

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_OTP';
    END IF;

    -- ✅ Consume OTP
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE id = v_otp.id;

    -- ✅ Update verification status
    IF p_type = 'email' THEN
        UPDATE admarkify.users
        SET is_email_verified = TRUE
        WHERE id = v_user.id;
    ELSIF p_type = 'mobile' THEN
        UPDATE admarkify.users
        SET is_mobile_verified = TRUE
        WHERE id = v_user.id;
    END IF;

    -- 🔍 Re-fetch updated user
    SELECT * INTO v_user FROM admarkify.users WHERE id = v_user.id;

    -- 🚨 Not fully verified → partial response
    IF NOT (v_user.is_email_verified AND v_user.is_mobile_verified) THEN
        RETURN jsonb_build_object(
            'message',         'OTP verified',
            'user_id',         v_user.id,
            'email_verified',  v_user.is_email_verified,
            'mobile_verified', v_user.is_mobile_verified
        );
    END IF;

    -- 🎉 FULLY VERIFIED → CREATE SESSION
    v_raw_token  := encode(public.gen_random_bytes(40), 'hex');
    v_token_hash := encode(public.digest(v_raw_token, 'sha256'), 'hex');

    INSERT INTO admarkify.user_sessions
        (user_id, org_id, token_hash, role, ip_address, user_agent, expires_at)
    VALUES
        (v_user.id, NULL, v_token_hash, 'admin',
         p_ip_address, p_user_agent, NOW() + INTERVAL '7 days')
    RETURNING id INTO v_session_id;

    UPDATE admarkify.users
    SET last_login_at = NOW()
    WHERE id = v_user.id;

    RETURN jsonb_build_object(
        'message',    'User verified successfully',
        'raw_token',  v_raw_token,
        'session_id', v_session_id,
        'expires_at', NOW() + INTERVAL '7 days',
        'user', jsonb_build_object(
            'id',          v_user.id,
            'email',       v_user.email,
            'full_name',   v_user.full_name,
            'avatar_url',  v_user.avatar_url,
            'is_verified', TRUE
        ),
        'org', NULL
    );
END;
$$;


-- ============================================================
-- fn_send_login_otp — email OR mobile (not both required)
-- ============================================================
CREATE OR REPLACE FUNCTION admarkify.fn_send_login_otp(
    p_email      VARCHAR  DEFAULT NULL,
    p_mobile     VARCHAR  DEFAULT NULL,
    p_ip_address INET     DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_user     admarkify.users%ROWTYPE;
    v_otp_code TEXT;
BEGIN
    -- ✅ At least one identifier required
    IF p_email IS NULL AND p_mobile IS NULL THEN
        RAISE EXCEPTION 'VALIDATION_ERROR: email or mobile is required';
    END IF;

    IF p_email IS NOT NULL THEN
        p_email := LOWER(TRIM(p_email));
    END IF;

    -- 🔍 Find user by email OR mobile
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE
        (p_email  IS NOT NULL AND email  = p_email)
     OR (p_mobile IS NOT NULL AND mobile = p_mobile)
    LIMIT 1;

    IF NOT FOUND THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (COALESCE(p_email, p_mobile), p_ip_address, FALSE, 'user_not_found');
        RAISE EXCEPTION 'AUTH_FAILED: user not found';
    END IF;

    -- 🚫 Account active?
    IF NOT v_user.is_active THEN
        INSERT INTO admarkify.login_attempts
            (email, ip_address, success, failure_reason)
        VALUES
            (v_user.email, p_ip_address, FALSE, 'user_suspended');
        RAISE EXCEPTION 'ACCOUNT_SUSPENDED: this user account is disabled';
    END IF;

    -- 🚫 Verified check based on which identifier was provided
    IF p_email IS NOT NULL AND NOT v_user.is_email_verified THEN
        RAISE EXCEPTION 'EMAIL_NOT_VERIFIED: verify your email before logging in';
    END IF;

    IF p_mobile IS NOT NULL AND NOT v_user.is_mobile_verified THEN
        RAISE EXCEPTION 'MOBILE_NOT_VERIFIED: verify your mobile before logging in';
    END IF;

    -- 🔢 Expire existing unused login OTPs
    UPDATE admarkify.user_otps
    SET is_used = TRUE
    WHERE user_id  = v_user.id
      AND otp_type = 'login'
      AND is_used  = FALSE;

    -- 🔢 Generate 6-digit OTP
    v_otp_code := LPAD(FLOOR(RANDOM() * 1000000)::TEXT, 6, '0');

    INSERT INTO admarkify.user_otps (user_id, otp_code, otp_type, expires_at)
    VALUES (v_user.id, v_otp_code, 'login', NOW() + INTERVAL '10 minutes');

    RETURN jsonb_build_object(
        'user_id',   v_user.id,
        'email',     v_user.email,
        'mobile',    v_user.mobile,
        'login_otp', v_otp_code
    );
END;
$$;


CREATE OR REPLACE FUNCTION admarkify.fn_get_all_channel_providers(
	p_channel character varying DEFAULT NULL::character varying,
	p_code character varying DEFAULT NULL::character varying,
	p_id integer DEFAULT NULL::integer)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'id',                 id,
            'code',               code,
            'name',               name,
            'main_providers',               main_providers,
            'channel',            channel,
            'description',        description,
            'logo_url',           logo_url,
            'credentials_schema', credentials_schema,
            'providers_schema', providers_schema,
            'is_active',          is_active,
            'created_at',         created_at
        )
        ORDER BY channel, name
    )
    INTO v_result
    FROM admarkify.channel_providers
    WHERE is_active = TRUE
      AND (p_channel IS NULL OR channel = p_channel)
      AND (p_code    IS NULL OR code    = p_code)
      AND (p_id      IS NULL OR id      = p_id);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$BODY$;



CREATE OR REPLACE FUNCTION admarkify.fn_get_org_providers(
	p_org_id uuid,
	p_channel character varying DEFAULT NULL::character varying)
    RETURNS jsonb
    LANGUAGE 'plpgsql'
    COST 100
    STABLE PARALLEL UNSAFE
AS $BODY$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'config_id',    opc.id,
            'label',        opc.label,
            'provider_code',cp.code,
            'provider_name',cp.name,
            'channel',      cp.channel,
            'is_default',   opc.is_default,
            'is_active',    opc.is_active,
            'settings',     opc.settings,
            'providers_schema',     cp.providers_schema,
            'credentials',     opc.credentials,
            'created_at',   opc.created_at
            -- Note: credentials intentionally excluded from read response
        )
        ORDER BY cp.channel, opc.is_default DESC, opc.created_at
    )
    INTO v_result
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.org_id    = p_org_id
      AND opc.is_active = TRUE
      AND (p_channel IS NULL OR cp.channel = p_channel);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$BODY$;

CREATE OR REPLACE FUNCTION admarkify.fn_add_org_provider(
    p_org_id         uuid,
    p_actor_id       uuid,
    p_provider_code  character varying,
    p_label          character varying,
    p_credentials    jsonb,
    p_settings       jsonb DEFAULT '{}'::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_provider        admarkify.channel_providers%ROWTYPE;
    v_actor_role      VARCHAR;
    v_config_id       UUID;
    v_is_default      BOOLEAN;
    v_existing_count  INT;

    -- schema validation
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    jsonb;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Actor must be admin or manager
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id   = p_org_id
      AND user_id  = p_actor_id
      AND status   = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin', 'manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can add providers';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Load provider from master list
    -- ----------------------------------------------------------------
    SELECT * INTO v_provider
    FROM admarkify.channel_providers
    WHERE code      = p_provider_code
      AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'PROVIDER_NOT_FOUND: "%" is not a supported provider', p_provider_code;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Validate p_credentials against credentials_schema
    --
    --    Supported schema types : "string", "number", "boolean"
    --
    --    Rules per field:
    --      • field must be present and non-null          → MISSING
    --      • string  → jsonb type must be string,
    --                   value must not be empty/whitespace,
    --                   value must not be a literal
    --                   placeholder ("string","number","boolean","null")
    --      • number  → jsonb type must be number
    --      • boolean → jsonb type must be boolean
    --
    --    All errors are collected first, then raised together.
    -- ----------------------------------------------------------------
    IF v_provider.credentials_schema IS NOT NULL
       AND v_provider.credentials_schema <> '{}'::jsonb
    THEN
        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'       -- unwrap quoted string value
            FROM jsonb_each(v_provider.credentials_schema)
        LOOP
            v_actual_value := p_credentials -> v_field_name;

            -- 3a) field must exist and not be JSON null
            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;                    -- no point type-checking a missing field
            END IF;

            -- 3b) type + value check
            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}')) IN ('string','number','boolean','null')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE
                    -- unknown schema type → skip silently
                    NULL;

            END CASE;
        END LOOP;

        -- 3c) raise ONE combined error listing every problem
        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_CREDENTIALS: provider "%" schema validation failed.%s%s',
                p_provider_code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Auto-default if no active config exists yet for this channel
    -- ----------------------------------------------------------------
    SELECT COUNT(*) INTO v_existing_count
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers    cp  ON cp.id = opc.provider_id
    WHERE opc.org_id    = p_org_id
      AND cp.channel    = v_provider.channel
      AND opc.is_active = TRUE;

    v_is_default := (v_existing_count = 0);

    -- ----------------------------------------------------------------
    -- 5) Insert
    -- ----------------------------------------------------------------
    INSERT INTO admarkify.org_provider_configs
        (org_id, provider_id, label, credentials, settings, is_default, created_by)
    VALUES
        (p_org_id, v_provider.id, p_label, p_credentials, p_settings,
         v_is_default, p_actor_id)
    RETURNING id INTO v_config_id;

    -- ----------------------------------------------------------------
    -- 6) Return summary
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'config_id',  v_config_id,
        'provider',   v_provider.code,
        'channel',    v_provider.channel,
        'label',      p_label,
        'is_default', v_is_default
    );
END;
$BODY$;

CREATE OR REPLACE FUNCTION admarkify.fn_update_org_provider(
    p_org_id       uuid,
    p_actor_id     uuid,
    p_config_id    uuid,
    p_label        character varying DEFAULT NULL::character varying,
    p_credentials  jsonb             DEFAULT NULL::jsonb,
    p_settings     jsonb             DEFAULT NULL::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role      VARCHAR;
    v_config          admarkify.org_provider_configs%ROWTYPE;
    v_provider        admarkify.channel_providers%ROWTYPE;

    -- schema validation
    v_merged_creds    jsonb;
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    jsonb;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Actor must be admin or manager
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin', 'manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can update providers';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Load existing config
    -- ----------------------------------------------------------------
    SELECT * INTO v_config
    FROM admarkify.org_provider_configs
    WHERE id       = p_config_id
      AND org_id   = p_org_id
      AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'NOT_FOUND: provider config "%" does not exist or is inactive', p_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Load provider info
    -- ----------------------------------------------------------------
    SELECT * INTO v_provider
    FROM admarkify.channel_providers
    WHERE id = v_config.provider_id;

    -- ----------------------------------------------------------------
    -- 4) Validate credentials only when p_credentials is passed
    --    Merge existing credentials with incoming so partial updates
    --    (only sending changed keys) are also fully validated.
    --
    --    e.g. existing: {"authkey":"abc", "integrated_number":"123"}
    --         incoming: {"authkey": "newkey"}
    --         merged:   {"authkey":"newkey", "integrated_number":"123"}
    --    → full schema is always satisfied after merge
    -- ----------------------------------------------------------------
    IF p_credentials IS NOT NULL THEN

        -- merge: existing || incoming  (incoming keys win on conflict)
        v_merged_creds := v_config.credentials || p_credentials;

        IF v_provider.credentials_schema IS NOT NULL
           AND v_provider.credentials_schema <> '{}'::jsonb
        THEN
            FOR v_field_name, v_expected_type IN
                SELECT key, value #>> '{}'
                FROM jsonb_each(v_provider.credentials_schema)
            LOOP
                v_actual_value := v_merged_creds -> v_field_name;

                -- 4a) field must exist and not be JSON null
                IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                    v_missing_fields := v_missing_fields || v_field_name;
                    CONTINUE;
                END IF;

                -- 4b) type + value check
                CASE v_expected_type

                    WHEN 'string' THEN
                        IF jsonb_typeof(v_actual_value) <> 'string'
                           OR TRIM(v_actual_value #>> '{}') = ''
                           OR LOWER(TRIM(v_actual_value #>> '{}')) IN ('string','number','boolean','null')
                        THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected a real non-empty string, received "'
                                    || (v_actual_value #>> '{}') || '"');
                        END IF;

                    WHEN 'number' THEN
                        IF jsonb_typeof(v_actual_value) <> 'number' THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected number, got '
                                    || jsonb_typeof(v_actual_value));
                        END IF;

                    WHEN 'boolean' THEN
                        IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                            v_type_errors := v_type_errors
                                || (v_field_name
                                    || ': expected boolean, got '
                                    || jsonb_typeof(v_actual_value));
                        END IF;

                    ELSE
                        NULL; -- unknown schema type → skip silently

                END CASE;
            END LOOP;

            -- 4c) raise ONE combined error listing every problem
            IF array_length(v_missing_fields, 1) > 0
               OR array_length(v_type_errors,  1) > 0
            THEN
                RAISE EXCEPTION 'INVALID_CREDENTIALS: provider "%" schema validation failed.%s%s',
                    v_provider.code,
                    CASE WHEN array_length(v_missing_fields, 1) > 0
                         THEN E'\n  Missing required fields: '
                              || array_to_string(v_missing_fields, ', ')
                         ELSE ''
                    END,
                    CASE WHEN array_length(v_type_errors, 1) > 0
                         THEN E'\n  Type errors: '
                              || array_to_string(v_type_errors, ' | ')
                         ELSE ''
                    END;
            END IF;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Update only provided fields (COALESCE keeps old value if NULL)
    -- ----------------------------------------------------------------
    UPDATE admarkify.org_provider_configs
    SET
        label       = COALESCE(p_label,       label),
        credentials = COALESCE(p_credentials, credentials),
        settings    = COALESCE(p_settings,    settings),
        updated_at  = NOW()
    WHERE id = p_config_id;

    -- ----------------------------------------------------------------
    -- 6) Return summary
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'config_id',  p_config_id,
        'provider',   v_provider.code,
        'channel',    v_provider.channel,
        'label',      COALESCE(p_label, v_config.label),
        'is_default', v_config.is_default,
        'updated_at', NOW()
    );
END;
$BODY$;



CREATE OR REPLACE FUNCTION admarkify.fn_create_template(
    p_org_id                  uuid,
    p_actor_id                uuid,
    p_name                    character varying,
    p_channel                 character varying,
    p_provider_config_id      uuid              DEFAULT NULL::uuid,
    p_external_template_name  character varying DEFAULT NULL::character varying,
    p_provider_payload        jsonb             DEFAULT NULL::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role      VARCHAR;
    v_template_id     UUID;
    v_variables       JSONB;
    v_provider        admarkify.channel_providers%ROWTYPE;
    v_body            TEXT;
    v_subject         TEXT;

    -- schema validation
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    JSONB;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Permission check
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can create templates';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Validate channel
    -- ----------------------------------------------------------------
    IF p_channel NOT IN ('sms','whatsapp','email','voice','push') THEN
        RAISE EXCEPTION 'INVALID_CHANNEL: "%"', p_channel;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Validate provider config + load provider master row
    -- ----------------------------------------------------------------
    IF p_provider_config_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM admarkify.org_provider_configs
            WHERE id       = p_provider_config_id
              AND org_id   = p_org_id
              AND is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config does not belong to this org';
        END IF;

        SELECT cp.* INTO v_provider
        FROM admarkify.org_provider_configs opc
        JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
        WHERE opc.id = p_provider_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Validate p_provider_payload against providers_schema
    --    and extract body/subject dynamically from payload
    --
    --    Supported types:
    --      "string"      → non-empty string, not a placeholder word
    --      "html"        → non-empty string (HTML content) → used as body
    --      "slug_string" → letters, digits, _ or - only
    --      "number"      → JSON number
    --      "boolean"     → JSON boolean
    -- ----------------------------------------------------------------
    IF v_provider.providers_schema IS NOT NULL
       AND v_provider.providers_schema <> '{}'::jsonb
    THEN
        -- payload is required when schema exists
        IF p_provider_payload IS NULL THEN
            RAISE EXCEPTION
                'PROVIDER_PAYLOAD_REQUIRED: provider "%" requires a payload with fields: %',
                v_provider.code,
                (SELECT string_agg(key, ', ')
                 FROM jsonb_each_text(v_provider.providers_schema));
        END IF;

        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'
            FROM jsonb_each(v_provider.providers_schema)
        LOOP
            v_actual_value := p_provider_payload -> v_field_name;

            -- 4a) field must exist and not be JSON null
            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;
            END IF;

            -- 4b) type check
            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}'))
                              IN ('string','number','boolean','null','html','slug_string')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                -- html → also captured as v_body
                WHEN 'html' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name || ': expected non-empty HTML string');
                    ELSE
                        v_body := v_actual_value #>> '{}';
                    END IF;

                WHEN 'slug_string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR (v_actual_value #>> '{}') !~ '^[a-zA-Z0-9_-]+$'
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a slug (letters, digits, _ or - only), received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE
                    NULL; -- unknown type → skip silently

            END CASE;

            -- capture subject dynamically: any field named "subject"
            IF v_field_name = 'subject'
               AND jsonb_typeof(v_actual_value) = 'string'
               AND TRIM(v_actual_value #>> '{}') <> ''
            THEN
                v_subject := v_actual_value #>> '{}';
            END IF;

        END LOOP;

        -- 4c) raise ONE combined error
        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_PROVIDER_PAYLOAD: provider "%" payload validation failed.%s%s',
                v_provider.code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Email requires subject — check after extracting from payload
    -- ----------------------------------------------------------------
    IF p_channel = 'email' AND (v_subject IS NULL OR TRIM(v_subject) = '') THEN
        RAISE EXCEPTION 'SUBJECT_REQUIRED: email templates must have a subject field in payload';
    END IF;

    -- ----------------------------------------------------------------
    -- 6) Extract {{variable}} placeholders from body (if present)
    -- ----------------------------------------------------------------
    IF v_body IS NOT NULL THEN
        SELECT jsonb_agg(DISTINCT match[1])
        INTO v_variables
        FROM regexp_matches(v_body, '\{\{(\w+)\}\}', 'g') AS match;
    END IF;

    v_variables := COALESCE(v_variables, '[]'::jsonb);

    -- ----------------------------------------------------------------
    -- 7) Insert template
    -- ----------------------------------------------------------------
    INSERT INTO admarkify.templates
        (org_id, provider_config_id, name, channel, subject, body,
         variables, external_template_name, provider_payload,
         status, created_by)
    VALUES
        (p_org_id, p_provider_config_id, TRIM(p_name), p_channel,
         v_subject, v_body, v_variables, p_external_template_name,
         p_provider_payload, 'draft', p_actor_id)
    RETURNING id INTO v_template_id;

    -- ----------------------------------------------------------------
    -- 8) Return
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'template_id',      v_template_id,
        'name',             TRIM(p_name),
        'channel',          p_channel,
        'status',           'draft',
        'variables',        v_variables,
		'end_point',        v_provider.end_point, 
        'provider_payload', p_provider_payload
    );
END;
$BODY$;

CREATE OR REPLACE FUNCTION admarkify.fn_get_provider_config(
    p_config_id uuid
)
RETURNS jsonb
LANGUAGE plpgsql
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_result jsonb;
BEGIN
    SELECT jsonb_build_object(
        -- ── org_provider_configs fields ──────────────────────────
        'config_id',         opc.id,
        'org_id',            opc.org_id,
        'label',             opc.label,
        'credentials',       opc.credentials,
        'settings',          opc.settings,
        'is_default',        opc.is_default,
        'is_active',         opc.is_active,
        'created_by',        opc.created_by,
        'created_at',        opc.created_at,
        'updated_at',        opc.updated_at,
        'providers_schema',        cp.providers_schema,

        -- ── channel_providers fields ─────────────────────────────
        'provider', jsonb_build_object(
            'provider_id',         cp.id,
            'code',                cp.code,
            'name',                cp.name,
            'channel',             cp.channel,
            'description',         cp.description,
            'logo_url',            cp.logo_url,
            'credentials_schema',  cp.credentials_schema,
            'providers_schema',    cp.providers_schema,
            'main_providers',      cp.main_providers,
            'end_point',           cp.end_point,
            'is_active',           cp.is_active,
            'created_at',          cp.created_at
        )
    )
    INTO v_result
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
    WHERE opc.id = p_config_id;

    IF v_result IS NULL THEN
        RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config "%" does not exist', p_config_id;
    END IF;

    RETURN v_result;
END;
$BODY$;


CREATE OR REPLACE FUNCTION admarkify.fn_create_template(
    p_org_id                  uuid,
    p_actor_id                uuid,
    p_name                    character varying,
    p_channel                 character varying,
    p_provider_config_id      uuid              DEFAULT NULL::uuid,
    p_external_template_name  character varying DEFAULT NULL::character varying,
    p_provider_payload        jsonb             DEFAULT NULL::jsonb,
    p_variables               jsonb             DEFAULT NULL::jsonb
)
RETURNS jsonb
LANGUAGE plpgsql
COST 100
VOLATILE PARALLEL UNSAFE
AS $BODY$
DECLARE
    v_actor_role      VARCHAR;
    v_template_id     UUID;
    v_variables       JSONB;
    v_provider        admarkify.channel_providers%ROWTYPE;
    v_body            TEXT;
    v_subject         TEXT;

    -- schema validation
    v_field_name      TEXT;
    v_expected_type   TEXT;
    v_actual_value    JSONB;
    v_missing_fields  TEXT[] := ARRAY[]::TEXT[];
    v_type_errors     TEXT[] := ARRAY[]::TEXT[];
BEGIN
    -- ----------------------------------------------------------------
    -- 1) Permission check
    -- ----------------------------------------------------------------
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id  = p_org_id
      AND user_id = p_actor_id
      AND status  = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can create templates';
    END IF;

    -- ----------------------------------------------------------------
    -- 2) Validate channel
    -- ----------------------------------------------------------------
    IF p_channel NOT IN ('sms','whatsapp','email','voice','push') THEN
        RAISE EXCEPTION 'INVALID_CHANNEL: "%"', p_channel;
    END IF;

    -- ----------------------------------------------------------------
    -- 3) Validate provider config + load provider master row
    -- ----------------------------------------------------------------
    IF p_provider_config_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM admarkify.org_provider_configs
            WHERE id       = p_provider_config_id
              AND org_id   = p_org_id
              AND is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config does not belong to this org';
        END IF;

        SELECT cp.* INTO v_provider
        FROM admarkify.org_provider_configs opc
        JOIN admarkify.channel_providers    cp ON cp.id = opc.provider_id
        WHERE opc.id = p_provider_config_id;
    END IF;

    -- ----------------------------------------------------------------
    -- 4) Validate p_provider_payload against providers_schema
    --    and extract body/subject dynamically from payload
    -- ----------------------------------------------------------------
    IF v_provider.providers_schema IS NOT NULL
       AND v_provider.providers_schema <> '{}'::jsonb
    THEN
        IF p_provider_payload IS NULL THEN
            RAISE EXCEPTION
                'PROVIDER_PAYLOAD_REQUIRED: provider "%" requires a payload with fields: %',
                v_provider.code,
                (SELECT string_agg(key, ', ')
                 FROM jsonb_each_text(v_provider.providers_schema));
        END IF;

        FOR v_field_name, v_expected_type IN
            SELECT key, value #>> '{}'
            FROM jsonb_each(v_provider.providers_schema)
        LOOP
            v_actual_value := p_provider_payload -> v_field_name;

            IF v_actual_value IS NULL OR v_actual_value = 'null'::jsonb THEN
                v_missing_fields := v_missing_fields || v_field_name;
                CONTINUE;
            END IF;

            CASE v_expected_type

                WHEN 'string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR LOWER(TRIM(v_actual_value #>> '{}'))
                              IN ('string','number','boolean','null','html','slug_string')
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a real non-empty string, received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'html' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name || ': expected non-empty HTML string');
                    ELSE
                        v_body := v_actual_value #>> '{}';
                    END IF;

                WHEN 'slug_string' THEN
                    IF jsonb_typeof(v_actual_value) <> 'string'
                       OR TRIM(v_actual_value #>> '{}') = ''
                       OR (v_actual_value #>> '{}') !~ '^[a-zA-Z0-9_-]+$'
                    THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected a slug (letters, digits, _ or - only), received "'
                                || (v_actual_value #>> '{}') || '"');
                    END IF;

                WHEN 'number' THEN
                    IF jsonb_typeof(v_actual_value) <> 'number' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected number, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                WHEN 'boolean' THEN
                    IF jsonb_typeof(v_actual_value) <> 'boolean' THEN
                        v_type_errors := v_type_errors
                            || (v_field_name
                                || ': expected boolean, got '
                                || jsonb_typeof(v_actual_value));
                    END IF;

                ELSE
                    NULL;

            END CASE;

            IF v_field_name = 'subject'
               AND jsonb_typeof(v_actual_value) = 'string'
               AND TRIM(v_actual_value #>> '{}') <> ''
            THEN
                v_subject := v_actual_value #>> '{}';
            END IF;

        END LOOP;

        IF array_length(v_missing_fields, 1) > 0
           OR array_length(v_type_errors,  1) > 0
        THEN
            RAISE EXCEPTION 'INVALID_PROVIDER_PAYLOAD: provider "%" payload validation failed.%s%s',
                v_provider.code,
                CASE WHEN array_length(v_missing_fields, 1) > 0
                     THEN E'\n  Missing required fields: '
                          || array_to_string(v_missing_fields, ', ')
                     ELSE ''
                END,
                CASE WHEN array_length(v_type_errors, 1) > 0
                     THEN E'\n  Type errors: '
                          || array_to_string(v_type_errors, ' | ')
                     ELSE ''
                END;
        END IF;
    END IF;

    -- ----------------------------------------------------------------
    -- 5) Email requires subject
    -- ----------------------------------------------------------------
    IF p_channel = 'email' AND (v_subject IS NULL OR TRIM(v_subject) = '') THEN
        RAISE EXCEPTION 'SUBJECT_REQUIRED: email templates must have a subject field in payload';
    END IF;

    -- ----------------------------------------------------------------
    -- 6) Use caller-supplied variables (default to empty array)
    -- ----------------------------------------------------------------
    v_variables := COALESCE(p_variables, '[]'::jsonb);

    -- ----------------------------------------------------------------
    -- 7) Insert template
    -- ----------------------------------------------------------------
    INSERT INTO admarkify.templates
        (org_id, provider_config_id, name, channel, subject, body,
         variables, external_template_name, provider_payload,
         status, created_by)
    VALUES
        (p_org_id, p_provider_config_id, TRIM(p_name), p_channel,
         v_subject, v_body, v_variables, p_external_template_name,
         p_provider_payload, 'draft', p_actor_id)
    RETURNING id INTO v_template_id;

    -- ----------------------------------------------------------------
    -- 8) Return
    -- ----------------------------------------------------------------
    RETURN jsonb_build_object(
        'template_id',      v_template_id,
        'name',             TRIM(p_name),
        'channel',          p_channel,
        'status',           'draft',
        'variables',        v_variables,
        'end_point',        v_provider.end_point,
        'provider_payload', p_provider_payload
    );
END;
$BODY$;