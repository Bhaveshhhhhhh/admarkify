CREATE OR REPLACE FUNCTION admarkify.search_organizations(
    p_search TEXT DEFAULT NULL,
    p_plan_id INT DEFAULT NULL,
    p_only_active BOOLEAN DEFAULT FALSE,
    p_page INT DEFAULT 1,
    p_page_size INT DEFAULT 10,
    p_sort_by TEXT DEFAULT 'created_at',
    p_sort_order TEXT DEFAULT 'desc'
)
RETURNS JSON
LANGUAGE plpgsql
AS $$
DECLARE
    v_offset INT;
    v_sql TEXT;
    v_result JSON;
BEGIN

    ------------------------------------------------------------
    -- 1️⃣ VALIDATE PLAN_ID
    ------------------------------------------------------------
    IF p_plan_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM admarkify.subscription_plans sp
            WHERE sp.id = p_plan_id
              AND sp.is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PLAN_NOT_FOUND: plan_id=%s', p_plan_id;
        END IF;
    END IF;

    ------------------------------------------------------------
    -- 2️⃣ PAGINATION
    ------------------------------------------------------------
    v_offset := (p_page - 1) * p_page_size;

    ------------------------------------------------------------
    -- 3️⃣ SAFE SORT COLUMN
    ------------------------------------------------------------
    IF p_sort_by NOT IN ('name','created_at') THEN
        p_sort_by := 'created_at';
    END IF;

    ------------------------------------------------------------
    -- 4️⃣ BUILD QUERY (ONLY REQUIRED FIELDS)
    ------------------------------------------------------------
    v_sql := format($f$
        SELECT COALESCE(json_agg(row_data), '[]'::json)
            FROM (
                SELECT 
                    o.id,
                    o.name,
                    o.slug,
                    o.created_at
                FROM admarkify.organizations o
                WHERE
                    (%L IS NULL OR
                        o.name ILIKE '%%' || %L || '%%' OR
                        o.slug ILIKE '%%' || %L || '%%'
                    )
                    AND (%L IS NULL OR o.plan_id = %L)
                    AND (%L = FALSE OR o.is_active = TRUE)
                ORDER BY %I %s
                LIMIT %s OFFSET %s
            ) row_data
        $f$,

        p_search, p_search, p_search,
        p_plan_id, p_plan_id,
        p_only_active,

        p_sort_by,
        CASE WHEN LOWER(p_sort_order) = 'asc' THEN 'ASC' ELSE 'DESC' END,

        p_page_size,
        v_offset
    );

    ------------------------------------------------------------
    -- 5️⃣ EXECUTE
    ------------------------------------------------------------
    EXECUTE v_sql INTO v_result;

    RETURN v_result;

END;
$$;



CREATE OR REPLACE FUNCTION admarkify.fn_logout_all_by_token(p_raw_token TEXT)
RETURNS INT
LANGUAGE plpgsql
AS $$
DECLARE
    v_token_hash TEXT;
    v_user_id UUID;
    v_count INT;
BEGIN
    ------------------------------------------------------------
    -- 1️⃣ HASH TOKEN (same as login/logout)
    ------------------------------------------------------------
    v_token_hash := encode(digest(p_raw_token, 'sha256'), 'hex');

    ------------------------------------------------------------
    -- 2️⃣ GET USER FROM SESSION
    ------------------------------------------------------------
    SELECT us.user_id
    INTO v_user_id
    FROM admarkify.user_sessions us
    WHERE us.token_hash = v_token_hash
      AND us.is_active = TRUE
    LIMIT 1;

    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'INVALID_TOKEN';
    END IF;

    ------------------------------------------------------------
    -- 3️⃣ LOGOUT ALL SESSIONS FOR USER
    ------------------------------------------------------------
    UPDATE admarkify.user_sessions
    SET is_active = FALSE
    WHERE user_id = v_user_id
      AND is_active = TRUE;

    GET DIAGNOSTICS v_count = ROW_COUNT;

    RETURN v_count;
END;
$$;

CREATE OR REPLACE FUNCTION admarkify.fn_get_session_by_token(
    p_raw_token TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
AS $$
DECLARE
    v_token_hash TEXT;

    v_session    admarkify.user_sessions%ROWTYPE;
    v_user       admarkify.users%ROWTYPE;
    v_org        admarkify.organizations%ROWTYPE;
    v_member     admarkify.organization_members%ROWTYPE;
    v_plan       admarkify.subscription_plans%ROWTYPE;
BEGIN

    ------------------------------------------------------------
    -- 1️⃣ HASH TOKEN
    ------------------------------------------------------------
    v_token_hash := encode(digest(p_raw_token, 'sha256'), 'hex');

    ------------------------------------------------------------
    -- 2️⃣ GET SESSION
    ------------------------------------------------------------
    SELECT *
    INTO v_session
    FROM admarkify.user_sessions
    WHERE token_hash = v_token_hash
      AND is_active = TRUE
      AND (expires_at IS NULL OR expires_at > NOW())
    LIMIT 1;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'INVALID_SESSION';
    END IF;

    ------------------------------------------------------------
    -- 3️⃣ GET USER
    ------------------------------------------------------------
    SELECT * INTO v_user
    FROM admarkify.users
    WHERE id = v_session.user_id;

    ------------------------------------------------------------
    -- 4️⃣ GET ORG
    ------------------------------------------------------------
    SELECT * INTO v_org
    FROM admarkify.organizations
    WHERE id = v_session.org_id;

    ------------------------------------------------------------
    -- 5️⃣ GET MEMBERSHIP
    ------------------------------------------------------------
    SELECT * INTO v_member
    FROM admarkify.organization_members
    WHERE org_id = v_org.id
      AND user_id = v_user.id;

    ------------------------------------------------------------
    -- 6️⃣ GET PLAN
    ------------------------------------------------------------
    SELECT * INTO v_plan
    FROM admarkify.subscription_plans
    WHERE id = v_org.plan_id;

    ------------------------------------------------------------
    -- 7️⃣ RETURN SAME STRUCTURE AS LOGIN
    ------------------------------------------------------------
    RETURN jsonb_build_object(
        'session_id',   v_session.id,
        'expires_at',   v_session.expires_at,

        'user', jsonb_build_object(
            'id',           v_user.id,
            'email',        v_user.email,
            'full_name',    v_user.full_name,
            'avatar_url',   v_user.avatar_url,
            'is_verified',  v_user.is_verified
        ),

        'org', jsonb_build_object(
            'id',       v_org.id,
            'name',     v_org.name,
            'slug',     v_org.slug,
            'timezone', v_org.timezone
        ),

        'membership', jsonb_build_object(
            'role',      v_member.role,
            'status',    v_member.status,
            'joined_at', v_member.joined_at
        ),

        'plan', jsonb_build_object(
            'name',             v_plan.name,
            'plan_type',        v_plan.plan_type,
            'max_team_members', v_plan.max_team_members
        )
    );

END;
$$;