-- ============================================================
--  admarkify — PROVIDERS + TEMPLATES
--  Schema: admarkify
--  Stored per: ORGANIZATION  (created_by tracks which user)
--
--  Why org-level, not user-level?
--    • Providers (MSG91/Twilio/WATI) are team credentials
--      shared by every member — not personal accounts.
--    • Templates are reusable assets for campaigns across
--      the whole team. Any member with the right role uses them.
--    • created_by keeps audit trail of who set it up.
-- ============================================================


-- ============================================================
--  SECTION 1 — PROVIDER MASTER  (system-level, seeded by admin)
--  Lists every supported external provider.
--  NOT per org — this is a global registry.
-- ============================================================

CREATE TABLE IF NOT EXISTS admarkify.channel_providers (
    id              SERIAL          PRIMARY KEY,
    code            VARCHAR(64)     NOT NULL UNIQUE,    -- 'msg91' | 'twilio' | 'wati' | 'sendgrid' etc.
    name            VARCHAR(128)    NOT NULL,
    channel         VARCHAR(32)     NOT NULL,           -- 'sms' | 'whatsapp' | 'email' | 'voice' | 'push'
    description     TEXT,
    logo_url        TEXT,
    -- JSON schema that describes what credentials this provider needs.
    -- Used by the front-end to render the setup form dynamically.
    -- e.g. {"api_key":"string","sender_id":"string","base_url":"string"}
    credentials_schema  JSONB       NOT NULL DEFAULT '{}',
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    CONSTRAINT chk_provider_channel
        CHECK (channel IN ('sms','whatsapp','email','voice','push'))
);

CREATE INDEX IF NOT EXISTS idx_channel_providers_channel
    ON admarkify.channel_providers(channel);
CREATE INDEX IF NOT EXISTS idx_channel_providers_code
    ON admarkify.channel_providers(code);

-- ── Seed supported providers ─────────────────────────────────
INSERT INTO admarkify.channel_providers
    (code, name, channel, description, credentials_schema)
VALUES
    ('msg91_sms',
     'MSG91 SMS', 'sms',
     'India-first SMS gateway — OTP, transactional, promotional',
     '{"auth_key":"string","sender_id":"string","route":"string"}'),

    ('msg91_whatsapp',
     'MSG91 WhatsApp', 'whatsapp',
     'MSG91 WhatsApp Business API',
     '{"auth_key":"string","integrated_number":"string"}'),

    ('twilio_sms',
     'Twilio SMS', 'sms',
     'Global SMS via Twilio',
     '{"account_sid":"string","auth_token":"string","from_number":"string"}'),

    ('twilio_whatsapp',
     'Twilio WhatsApp', 'whatsapp',
     'WhatsApp via Twilio sandbox or approved number',
     '{"account_sid":"string","auth_token":"string","from_number":"string"}'),

    ('wati',
     'WATI', 'whatsapp',
     'WhatsApp Team Inbox — WATI',
     '{"api_endpoint":"string","bearer_token":"string"}'),

    ('sendgrid',
     'SendGrid', 'email',
     'Transactional + marketing email via SendGrid',
     '{"api_key":"string","from_email":"string","from_name":"string"}'),

    ('mailgun',
     'Mailgun', 'email',
     'Developer-friendly email API',
     '{"api_key":"string","domain":"string","from_email":"string"}'),

    ('smtp_generic',
     'Custom SMTP', 'email',
     'Any SMTP server (Gmail relay, SES SMTP, etc.)',
     '{"host":"string","port":"number","username":"string","password":"string","from_email":"string","tls":"boolean"}'),

    ('firebase_push',
     'Firebase FCM', 'push',
     'Mobile + web push via Firebase Cloud Messaging',
     '{"server_key":"string","project_id":"string"}')

ON CONFLICT (code) DO NOTHING;


-- ============================================================
--  SECTION 2 — ORG PROVIDER CONFIG  (per org)
--  Each org connects their own credentials for a provider.
--  One org can have multiple configs for the same channel
--  (e.g. two SMS providers — one for OTP, one for marketing).
-- ============================================================

CREATE TABLE IF NOT EXISTS admarkify.org_provider_configs (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id          UUID            NOT NULL
                        REFERENCES admarkify.organizations(id) ON DELETE CASCADE,
    provider_id     INT             NOT NULL
                        REFERENCES admarkify.channel_providers(id),
    -- Human label so the team can tell configs apart:
    --   "MSG91 - OTP sender" vs "MSG91 - Promo sender"
    label           VARCHAR(128)    NOT NULL,
    -- Encrypted at application layer before storing here.
    -- Keys match credentials_schema of the provider.
    credentials     JSONB           NOT NULL DEFAULT '{}',
    -- Extra per-config settings (webhooks, retry policy, etc.)
    settings        JSONB           NOT NULL DEFAULT '{}',
    -- One default config per channel per org (enforced by fn_set_default_provider)
    is_default      BOOLEAN         NOT NULL DEFAULT FALSE,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_by      UUID            NOT NULL
                        REFERENCES admarkify.users(id),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_org_providers_org
    ON admarkify.org_provider_configs(org_id);
CREATE INDEX IF NOT EXISTS idx_org_providers_provider
    ON admarkify.org_provider_configs(provider_id);
-- Partial unique: only one default per channel per org
CREATE UNIQUE INDEX IF NOT EXISTS uq_org_default_provider
    ON admarkify.org_provider_configs(org_id, provider_id)
    WHERE is_default = TRUE;


-- ============================================================
--  SECTION 3 — TEMPLATES  (per org)
--  A template is a reusable message body for a channel.
--  Linked to a specific provider config (optional — if NULL,
--  the org's default provider for that channel is used at send time).
-- ============================================================

CREATE TABLE IF NOT EXISTS admarkify.templates (
    id                  UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    org_id              UUID            NOT NULL
                            REFERENCES admarkify.organizations(id) ON DELETE CASCADE,
    -- Optional: pin template to a specific provider config
    provider_config_id  UUID
                            REFERENCES admarkify.org_provider_configs(id)
                            ON DELETE SET NULL,
    name                VARCHAR(255)    NOT NULL,
    channel             VARCHAR(32)     NOT NULL,
    -- For WhatsApp: must match approved template name on provider dashboard
    external_template_name  VARCHAR(255),
    -- Email only
    subject             TEXT,
    -- The message body. Use {{variable_name}} placeholders.
    body                TEXT            NOT NULL,
    -- Extracted variable list for validation & UI hints
    -- e.g. ["name", "otp", "company"]
    variables           JSONB           NOT NULL DEFAULT '[]',
    -- 'draft' while editing | 'active' ready to use | 'archived' retired
    status              VARCHAR(32)     NOT NULL DEFAULT 'draft',
    is_active           BOOLEAN         NOT NULL DEFAULT TRUE,
    created_by          UUID            NOT NULL
                            REFERENCES admarkify.users(id),
    updated_by          UUID
                            REFERENCES admarkify.users(id),
    created_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ     NOT NULL DEFAULT NOW(),

    -- Template names must be unique within an org + channel
    CONSTRAINT uq_template_name_per_org UNIQUE (org_id, channel, name),
    CONSTRAINT chk_template_channel
        CHECK (channel IN ('sms','whatsapp','email','voice','push')),
    CONSTRAINT chk_template_status
        CHECK (status IN ('draft','active','archived'))
);

CREATE INDEX IF NOT EXISTS idx_templates_org
    ON admarkify.templates(org_id);
CREATE INDEX IF NOT EXISTS idx_templates_channel
    ON admarkify.templates(org_id, channel);
CREATE INDEX IF NOT EXISTS idx_templates_status
    ON admarkify.templates(org_id, status);


-- ============================================================
--  SECTION 4 — PROVIDER FUNCTIONS
-- ============================================================

-- ------------------------------------------------------------
--  4A. admarkify.fn_add_org_provider
--  Admin connects an external provider for their org.
--  • Validates provider exists and is active
--  • Validates actor is admin
--  • If first config for this channel, auto-sets as default
--  Returns the new provider config UUID.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_add_org_provider(
    p_org_id        UUID,
    p_actor_id      UUID,       -- must be admin or manager
    p_provider_code VARCHAR,    -- e.g. 'msg91_sms'
    p_label         VARCHAR,    -- e.g. 'MSG91 - OTP'
    p_credentials   JSONB,      -- encrypted at app layer before passing in
    p_settings      JSONB       DEFAULT '{}'
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_provider      admarkify.channel_providers%ROWTYPE;
    v_actor_role    VARCHAR;
    v_config_id     UUID;
    v_is_default    BOOLEAN;
    v_existing_count INT;
BEGIN
    -- Actor must be admin or manager
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can add providers';
    END IF;

    -- Load provider from master list
    SELECT * INTO v_provider
    FROM admarkify.channel_providers
    WHERE code = p_provider_code AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'PROVIDER_NOT_FOUND: "%" is not a supported provider', p_provider_code;
    END IF;

    -- Auto-default if no active config exists yet for this channel in this org
    SELECT COUNT(*) INTO v_existing_count
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.org_id   = p_org_id
      AND cp.channel   = v_provider.channel
      AND opc.is_active = TRUE;

    v_is_default := (v_existing_count = 0);

    INSERT INTO admarkify.org_provider_configs
        (org_id, provider_id, label, credentials, settings, is_default, created_by)
    VALUES
        (p_org_id, v_provider.id, p_label, p_credentials, p_settings,
         v_is_default, p_actor_id)
    RETURNING id INTO v_config_id;

    RETURN jsonb_build_object(
        'config_id',    v_config_id,
        'provider',     v_provider.code,
        'channel',      v_provider.channel,
        'label',        p_label,
        'is_default',   v_is_default
    );
END;
$$;


-- ------------------------------------------------------------
--  4B. admarkify.fn_set_default_provider
--  Marks a provider config as the default for its channel.
--  Clears any existing default for the same channel first.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_set_default_provider(
    p_org_id        UUID,
    p_actor_id      UUID,
    p_config_id     UUID
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
    v_actor_role    VARCHAR;
    v_channel       VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin or manager can change default provider';
    END IF;

    -- Get channel of the target config
    SELECT cp.channel INTO v_channel
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.id = p_config_id AND opc.org_id = p_org_id AND opc.is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'CONFIG_NOT_FOUND: provider config not found or inactive';
    END IF;

    -- Clear current default for this channel in this org
    UPDATE admarkify.org_provider_configs opc
    SET is_default = FALSE, updated_at = NOW()
    FROM admarkify.channel_providers cp
    WHERE cp.id       = opc.provider_id
      AND opc.org_id  = p_org_id
      AND cp.channel  = v_channel
      AND opc.is_default = TRUE;

    -- Set new default
    UPDATE admarkify.org_provider_configs
    SET is_default = TRUE, updated_at = NOW()
    WHERE id = p_config_id;
END;
$$;


-- ------------------------------------------------------------
--  4C. admarkify.fn_get_org_providers
--  Returns all active provider configs for an org.
--  Optionally filter by channel.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_get_org_providers(
    p_org_id    UUID,
    p_channel   VARCHAR DEFAULT NULL    -- NULL = all channels
)
RETURNS JSONB LANGUAGE plpgsql STABLE AS $$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'config_id',    opc.id,
            'label',        opc.label,
            'provider_code',cp.code,
            'provider_name',cp.name,
            'channel',      cp.channel,
            'is_default',   opc.is_default,
            'is_active',    opc.is_active,
            'settings',     opc.settings,
            'created_at',   opc.created_at
            -- Note: credentials intentionally excluded from read response
        )
        ORDER BY cp.channel, opc.is_default DESC, opc.created_at
    )
    INTO v_result
    FROM admarkify.org_provider_configs opc
    JOIN admarkify.channel_providers cp ON cp.id = opc.provider_id
    WHERE opc.org_id    = p_org_id
      AND opc.is_active = TRUE
      AND (p_channel IS NULL OR cp.channel = p_channel);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$$;


-- ------------------------------------------------------------
--  4D. admarkify.fn_remove_org_provider
--  Soft-deletes a provider config (marks inactive).
--  Blocks removal if active templates reference it.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_remove_org_provider(
    p_org_id    UUID,
    p_actor_id  UUID,
    p_config_id UUID
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE
    v_actor_role    VARCHAR;
    v_template_count INT;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role != 'admin' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admins can remove providers';
    END IF;

    -- Block if active templates are still linked
    SELECT COUNT(*) INTO v_template_count
    FROM admarkify.templates
    WHERE provider_config_id = p_config_id
      AND status != 'archived'
      AND is_active = TRUE;

    IF v_template_count > 0 THEN
        RAISE EXCEPTION
            'PROVIDER_IN_USE: % active template(s) reference this provider — archive them first',
            v_template_count;
    END IF;

    UPDATE admarkify.org_provider_configs
    SET is_active = FALSE, is_default = FALSE, updated_at = NOW()
    WHERE id = p_config_id AND org_id = p_org_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'CONFIG_NOT_FOUND';
    END IF;
END;
$$;


-- ============================================================
--  SECTION 5 — TEMPLATE FUNCTIONS
-- ============================================================

-- ------------------------------------------------------------
--  5A. admarkify.fn_create_template
--  Creates a new message template for an org.
--  • Admin / manager / lead can create
--  • Validates provider config belongs to same org if supplied
--  • Auto-extracts {{variable}} placeholders from body
--  Returns the new template JSONB.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_create_template(
    p_org_id                UUID,
    p_actor_id              UUID,
    p_name                  VARCHAR,
    p_channel               VARCHAR,    -- sms|whatsapp|email|voice|push
    p_body                  TEXT,
    p_subject               TEXT        DEFAULT NULL,   -- email only
    p_provider_config_id    UUID        DEFAULT NULL,   -- NULL = use org default
    p_external_template_name VARCHAR    DEFAULT NULL    -- WhatsApp approved name
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_actor_role    VARCHAR;
    v_template_id   UUID;
    v_variables     JSONB;
BEGIN
    -- Who can create: admin, manager, lead  (executive cannot)
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can create templates';
    END IF;

    -- Validate channel
    IF p_channel NOT IN ('sms','whatsapp','email','voice','push') THEN
        RAISE EXCEPTION 'INVALID_CHANNEL: "%"', p_channel;
    END IF;

    -- Email requires subject
    IF p_channel = 'email' AND (p_subject IS NULL OR TRIM(p_subject) = '') THEN
        RAISE EXCEPTION 'SUBJECT_REQUIRED: email templates must have a subject';
    END IF;

    -- Validate provider config belongs to this org (if supplied)
    IF p_provider_config_id IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1 FROM admarkify.org_provider_configs
            WHERE id = p_provider_config_id
              AND org_id = p_org_id
              AND is_active = TRUE
        ) THEN
            RAISE EXCEPTION 'PROVIDER_CONFIG_NOT_FOUND: config does not belong to this org';
        END IF;
    END IF;

    -- Extract {{variable}} placeholders from body as a JSON array
    SELECT jsonb_agg(DISTINCT match[1])
    INTO v_variables
    FROM regexp_matches(p_body, '\{\{(\w+)\}\}', 'g') AS match;

    v_variables := COALESCE(v_variables, '[]'::JSONB);

    INSERT INTO admarkify.templates
        (org_id, provider_config_id, name, channel, subject, body,
         variables, external_template_name, status, created_by)
    VALUES
        (p_org_id, p_provider_config_id, TRIM(p_name), p_channel,
         p_subject, p_body, v_variables, p_external_template_name,
         'draft', p_actor_id)
    RETURNING id INTO v_template_id;

    RETURN jsonb_build_object(
        'template_id',  v_template_id,
        'name',         TRIM(p_name),
        'channel',      p_channel,
        'status',       'draft',
        'variables',    v_variables
    );
END;
$$;


-- ------------------------------------------------------------
--  5B. admarkify.fn_update_template
--  Updates body / subject / name of a template.
--  Re-extracts variables automatically.
--  Resets status to 'draft' on body change (re-review needed).
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_update_template(
    p_org_id        UUID,
    p_actor_id      UUID,
    p_template_id   UUID,
    p_name          VARCHAR     DEFAULT NULL,
    p_body          TEXT        DEFAULT NULL,
    p_subject       TEXT        DEFAULT NULL,
    p_provider_config_id UUID   DEFAULT NULL
)
RETURNS JSONB LANGUAGE plpgsql AS $$
DECLARE
    v_actor_role    VARCHAR;
    v_tmpl          admarkify.templates%ROWTYPE;
    v_variables     JSONB;
    v_new_body      TEXT;
    v_new_status    VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role = 'executive' THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: admin/manager/lead can update templates';
    END IF;

    SELECT * INTO v_tmpl
    FROM admarkify.templates
    WHERE id = p_template_id AND org_id = p_org_id AND is_active = TRUE;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND';
    END IF;

    IF v_tmpl.status = 'archived' THEN
        RAISE EXCEPTION 'TEMPLATE_ARCHIVED: cannot edit an archived template';
    END IF;

    -- Body changed → re-extract variables, reset to draft
    v_new_body   := COALESCE(p_body, v_tmpl.body);
    v_new_status := CASE
        WHEN p_body IS NOT NULL AND p_body != v_tmpl.body THEN 'draft'
        ELSE v_tmpl.status
    END;

    SELECT jsonb_agg(DISTINCT match[1])
    INTO v_variables
    FROM regexp_matches(v_new_body, '\{\{(\w+)\}\}', 'g') AS match;

    UPDATE admarkify.templates SET
        name                  = COALESCE(TRIM(p_name), name),
        body                  = v_new_body,
        subject               = COALESCE(p_subject, subject),
        variables             = COALESCE(v_variables, '[]'::JSONB),
        provider_config_id    = COALESCE(p_provider_config_id, provider_config_id),
        status                = v_new_status,
        updated_by            = p_actor_id,
        updated_at            = NOW()
    WHERE id = p_template_id;

    RETURN jsonb_build_object(
        'template_id',  p_template_id,
        'status',       v_new_status,
        'variables',    COALESCE(v_variables, '[]'::JSONB)
    );
END;
$$;


-- ------------------------------------------------------------
--  5C. admarkify.fn_publish_template
--  Moves a draft template to 'active' (ready to use in campaigns).
--  Only admin or manager can publish.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_publish_template(
    p_org_id        UUID,
    p_actor_id      UUID,
    p_template_id   UUID
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin/manager can publish templates';
    END IF;

    UPDATE admarkify.templates
    SET status = 'active', updated_by = p_actor_id, updated_at = NOW()
    WHERE id = p_template_id AND org_id = p_org_id AND status = 'draft';

    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND or already active/archived';
    END IF;
END;
$$;


-- ------------------------------------------------------------
--  5D. admarkify.fn_archive_template
--  Soft-deletes a template (sets status = 'archived').
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_archive_template(
    p_org_id        UUID,
    p_actor_id      UUID,
    p_template_id   UUID
)
RETURNS VOID LANGUAGE plpgsql AS $$
DECLARE v_actor_role VARCHAR;
BEGIN
    SELECT role INTO v_actor_role
    FROM admarkify.organization_members
    WHERE org_id = p_org_id AND user_id = p_actor_id AND status = 'active';

    IF v_actor_role IS NULL OR v_actor_role NOT IN ('admin','manager') THEN
        RAISE EXCEPTION 'PERMISSION_DENIED: only admin/manager can archive templates';
    END IF;

    UPDATE admarkify.templates
    SET status     = 'archived',
        is_active  = FALSE,
        updated_by = p_actor_id,
        updated_at = NOW()
    WHERE id = p_template_id AND org_id = p_org_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'TEMPLATE_NOT_FOUND';
    END IF;
END;
$$;


-- ------------------------------------------------------------
--  5E. admarkify.fn_get_templates
--  Returns templates for an org.
--  Filters: channel, status, provider_config_id.
-- ------------------------------------------------------------

CREATE OR REPLACE FUNCTION admarkify.fn_get_templates(
    p_org_id            UUID,
    p_channel           VARCHAR     DEFAULT NULL,   -- NULL = all
    p_status            VARCHAR     DEFAULT NULL,   -- NULL = all except archived
    p_provider_config_id UUID       DEFAULT NULL    -- NULL = all providers
)
RETURNS JSONB LANGUAGE plpgsql STABLE AS $$
DECLARE v_result JSONB;
BEGIN
    SELECT jsonb_agg(
        jsonb_build_object(
            'template_id',              t.id,
            'name',                     t.name,
            'channel',                  t.channel,
            'subject',                  t.subject,
            'body',                     t.body,
            'variables',                t.variables,
            'external_template_name',   t.external_template_name,
            'status',                   t.status,
            'provider_config_id',       t.provider_config_id,
            'provider_label',           opc.label,
            'provider_code',            cp.code,
            'created_by',               t.created_by,
            'created_at',               t.created_at,
            'updated_at',               t.updated_at
        )
        ORDER BY t.channel, t.name
    )
    INTO v_result
    FROM admarkify.templates t
    LEFT JOIN admarkify.org_provider_configs opc ON opc.id = t.provider_config_id
    LEFT JOIN admarkify.channel_providers    cp  ON cp.id  = opc.provider_id
    WHERE t.org_id    = p_org_id
      AND t.is_active = TRUE
      AND (p_channel            IS NULL OR t.channel             = p_channel)
      AND (p_provider_config_id IS NULL OR t.provider_config_id  = p_provider_config_id)
      AND (
            p_status IS NOT NULL
            OR t.status != 'archived'           -- default: hide archived
          )
      AND (p_status IS NULL OR t.status = p_status);

    RETURN COALESCE(v_result, '[]'::JSONB);
END;
$$;


-- ============================================================
--  QUICK REFERENCE — SETUP FLOW
-- ============================================================
--
--  ── Step 1: Register user + create org (from auth file) ───
--
--     SELECT admarkify.fn_register_user('alice@co.com','Pass1!','Alice');
--     SELECT admarkify.fn_create_organization('<user_uuid>','My Co','my-co',1,'Asia/Kolkata');
--     SELECT admarkify.fn_login('alice@co.com','Pass1!','my-co');
--
--  ── Step 2: Connect a provider ────────────────────────────
--
--     -- Add MSG91 for SMS (auto-sets as default since it's first SMS config)
--     SELECT admarkify.fn_add_org_provider(
--         '<org_uuid>',
--         '<admin_uuid>',
--         'msg91_sms',
--         'MSG91 - OTP',
--         '{"auth_key":"XXXX","sender_id":"MYAPP","route":"4"}'::JSONB
--     );
--
--     -- Add WATI for WhatsApp
--     SELECT admarkify.fn_add_org_provider(
--         '<org_uuid>', '<admin_uuid>',
--         'wati', 'WATI - Main',
--         '{"api_endpoint":"https://live-mt-server.wati.io/xxx","bearer_token":"eyJ..."}'::JSONB
--     );
--
--     -- Add SendGrid for Email
--     SELECT admarkify.fn_add_org_provider(
--         '<org_uuid>', '<admin_uuid>',
--         'sendgrid', 'SendGrid - Transactional',
--         '{"api_key":"SG.xxx","from_email":"hello@myco.com","from_name":"MyCo"}'::JSONB
--     );
--
--  ── Step 3: Create a template ─────────────────────────────
--
--     -- SMS OTP template
--     SELECT admarkify.fn_create_template(
--         '<org_uuid>', '<admin_uuid>',
--         'OTP Verification',                -- name
--         'sms',                             -- channel
--         'Your {{company}} OTP is {{otp}}. Valid for {{minutes}} minutes.',
--         NULL,                              -- subject (email only)
--         '<msg91_config_uuid>'              -- provider_config_id (or NULL for default)
--     );
--     -- variables auto-extracted: ["company","otp","minutes"]
--
--     -- WhatsApp welcome template
--     SELECT admarkify.fn_create_template(
--         '<org_uuid>', '<admin_uuid>',
--         'Welcome Message', 'whatsapp',
--         'Hi {{name}}, welcome to {{company}}! Your account is ready.',
--         NULL, '<wati_config_uuid>',
--         'welcome_message'                  -- external_template_name (WhatsApp approved name)
--     );
--
--     -- Email template
--     SELECT admarkify.fn_create_template(
--         '<org_uuid>', '<admin_uuid>',
--         'Order Confirmation', 'email',
--         'Hi {{name}}, your order #{{order_id}} has been confirmed. Total: {{amount}}.',
--         'Order Confirmed — {{company}}',   -- subject
--         '<sendgrid_config_uuid>'
--     );
--
--  ── Step 4: Publish template (makes it usable in campaigns) ─
--
--     SELECT admarkify.fn_publish_template('<org_uuid>','<admin_uuid>','<template_uuid>');
--
--  ── Read ──────────────────────────────────────────────────
--
--     -- All providers for org
--     SELECT admarkify.fn_get_org_providers('<org_uuid>');
--
--     -- SMS providers only
--     SELECT admarkify.fn_get_org_providers('<org_uuid>', 'sms');
--
--     -- All active templates
--     SELECT admarkify.fn_get_templates('<org_uuid>');
--
--     -- WhatsApp templates only
--     SELECT admarkify.fn_get_templates('<org_uuid>', 'whatsapp');
--
--     -- Draft templates only
--     SELECT admarkify.fn_get_templates('<org_uuid>', NULL, 'draft');
--
-- ============================================================