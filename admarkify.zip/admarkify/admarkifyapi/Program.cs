using admarkifyapi.Extensions;
using admarkifyapi.Middleware;
using Microsoft.OpenApi.Models;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen(options =>
{
    options.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Admarkify API",
        Version = "v1"
    });

    options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.Http,
        Scheme = "bearer",
        BearerFormat = "Token",
        In = ParameterLocation.Header,
        Description = "Paste the raw_token from /api/auth/login. Example: Bearer abc123..."
    });

    // ✅ Key MUST carry a Reference that matches the definition name above
    options.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference          // ← was missing
                {
                    Type = ReferenceType.SecurityScheme,
                    Id   = "Bearer"                       // must match definition name
                }
            },
            Array.Empty<string>()
        }
    });
});

// All DI registrations live here (ITemplateService, IIntegrationService, WatiService, etc.)
builder.Services.AddAdmarkifyServices(builder.Configuration);

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

app.UseMiddleware<SessionMiddleware>();
app.MapControllers();

app.Run();