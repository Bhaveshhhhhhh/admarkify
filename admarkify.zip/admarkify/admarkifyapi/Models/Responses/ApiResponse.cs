namespace admarkifyapi.Models.Responses;

public record ApiResponse<T>(bool Success, T? Data, string? Error = null)
{
    public static ApiResponse<T> Ok(T data)           => new(true,  data,  null);
    public static ApiResponse<T> Fail(string message) => new(false, default, message);
}

public record ErrorResponse(string Error);
