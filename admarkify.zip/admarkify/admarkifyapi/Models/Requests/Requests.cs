using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace admarkifyapi.Models.Requests;

// ── Auth ──────────────────────────────────────────────────────

public record RegisterRequest(
    [Required][EmailAddress] string Email,
    [Required][MinLength(8)] string Password,
    [Required]               string FullName,
    [Required]               string Mobile
);

public record VerifyOtpRequest(
    [Required] string Email,
    [Required] string Mobile,
    [Required] string Otp,
    [Required] string Type   // "email" or "mobile"
);

// Password login (existing)
public record LoginRequest(
    [Required][EmailAddress] string  Email,
    [Required]               string  Password,
                             string? OrgSlug = null
);

// OTP login — Step 1: request OTP
public record SendLoginOtpRequest(
    [Required][EmailAddress] string Email
);

// OTP login — Step 2: verify OTP
public record LoginWithOtpRequest(
    [Required][EmailAddress] string  Email,
    [Required]               string  Otp,
                             string? OrgSlug = null
);

public record AcceptInviteRequest(
    [Required] string  RawToken,
               string? FullName = null,
               string? Password = null,
               string? Mobile   = null
);

public record VerifyInviteOtpRequest(
    [Required][EmailAddress] string Email,
    [Required]               string Mobile,
    [Required]               string Otp,
    [Required]               string Type,      // "invite_email" or "invite_mobile"
    [Required]               string RawToken   // ← needed to finalize invite
);
// ── Account Changes ───────────────────────────────────────────

public record RequestChangePasswordRequest(
    [Required][EmailAddress] string Email
);

public record ChangePasswordRequest(
    [Required][EmailAddress] string Email,
    [Required]               string Otp,
    [Required][MinLength(8)] string NewPassword
);

public record RequestChangeEmailRequest(
    [Required][EmailAddress] string Email,
    [Required][EmailAddress] string NewEmail
);

public record ChangeEmailRequest(
    [Required][EmailAddress] string Email,
    [Required]               string Otp
);

public record RequestChangeMobileRequest(
    [Required][EmailAddress] string Email,
    [Required]               string NewMobile
);

public record ChangeMobileRequest(
    [Required][EmailAddress] string Email,
    [Required]               string Otp
);
// ── Organization ──────────────────────────────────────────────

public record CreateOrgRequest(
    [Required] string Name,
    [Required] string Slug,
               int    PlanId   = 1,
               string Timezone = "UTC"
);

public record SearchOrgRequest(
    string? Search,
    int?    PlanId,
    bool    OnlyActive = false,
    int     Page       = 1,
    int     PageSize   = 10,
    string  SortBy     = "created_at",
    string  SortOrder  = "desc"
);

public record UpgradePlanRequest(
    [Required] int       NewPlanId,
               DateTime? ExpiresAt
);

// ── Team ─────────────────────────────────────────────────────

public record InviteMemberRequest(
    [Required][EmailAddress] string Email,
                             string Role = "executive"   // admin|manager|lead|executive
);

public record UpdateRoleRequest(
    [Required] Guid   TargetUserId,
    [Required] string NewRole
);

public record RemoveMemberRequest(
    [Required] Guid TargetUserId
);

public record GetMembersRequest(
    string? Status   = null,   // active | invited | suspended
    string? Role     = null,   // admin | manager | lead | executive
    string? Search   = null,
    int     Page     = 1,
    int     PageSize = 10
);

// ── Providers ─────────────────────────────────────────────────

public record AddProviderRequest(
    [Required] string     ProviderCode,
    [Required] string     Label,
    [Required] JsonObject Credentials,
               JsonObject? Settings
);

public record UpdateProviderRequest(
    [Required] Guid        ConfigId,
               string?     Label,
               JsonObject? Credentials,
               JsonObject? Settings
);

public record SetDefaultProviderRequest(
    [Required] Guid ConfigId
);

public record RemoveProviderRequest(
    [Required] Guid ConfigId
);

// ── Templates ─────────────────────────────────────────────────

public record CreateTemplateRequest
{
    [Required] public required string  Name                 { get; init; }
    [Required] public required string  Channel              { get; init; }
    [Required] public required string  Body                 { get; init; }

    public string?       Subject              { get; init; }
    public Guid?         ProviderConfigId     { get; init; }
    public string?       ExternalTemplateName { get; init; }
    public JsonElement?  ProviderPayload      { get; init; }
}

public record UpdateTemplateRequest(
    string? Name,
    string? Body,
    string? Subject,
    Guid?   ProviderConfigId
);