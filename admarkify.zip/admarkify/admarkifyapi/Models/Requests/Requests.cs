using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace admarkifyapi.Models.Requests;

// ── Auth ──────────────────────────────────────────────────────

public record RegisterRequest(
    [Required][EmailAddress] string Email,
    [Required][MinLength(8)] string Password,
    [Required] string FullName,
    [Required] string OrgName,
    [Required] string OrgSlug
);
public record LoginRequest(
    [Required][EmailAddress] string Email,
    [Required]               string Password,
    [Required]               string OrgSlug
);

public record AcceptInviteRequest(
    [Required] string RawToken,
    string?           FullName,
    string?           Password    // required only if new user
);

// ── Organization ──────────────────────────────────────────────

public record CreateOrgRequest(
    [Required] string Name,
    [Required] string Slug,
    int               PlanId   = 1,
    string            Timezone = "UTC"
);

public record UpgradePlanRequest(
    [Required] int          NewPlanId,
    DateTime?               ExpiresAt
);

// ── Team ─────────────────────────────────────────────────────

public record InviteMemberRequest(
    [Required][EmailAddress] string Email,
    string                         Role = "executive"   // admin|manager|lead|executive
);

public record UpdateRoleRequest(
    [Required] Guid   TargetUserId,
    [Required] string NewRole
);

public record RemoveMemberRequest(
    [Required] Guid TargetUserId
);

// ── Providers ─────────────────────────────────────────────────

public record AddProviderRequest(
    [Required] string    ProviderCode,   // 'msg91_sms' | 'twilio_sms' | 'wati' etc.
    [Required] string    Label,          // human name e.g. "MSG91 - OTP"
    [Required] JsonObject Credentials,  // must be encrypted by caller before sending
    JsonObject?           Settings
);

public record SetDefaultProviderRequest(
    [Required] Guid ConfigId
);

public record RemoveProviderRequest(
    [Required] Guid ConfigId
);

// ── Templates ─────────────────────────────────────────────────

public record CreateTemplateRequest
{
    [Required] public string Name { get; init; }
    [Required] public string Channel { get; init; }
    [Required] public string Body { get; init; }

    public string? Subject { get; init; }
    public Guid? ProviderConfigId { get; init; }
    public string? ExternalTemplateName { get; init; }

    public JsonElement? ProviderPayload { get; init; }
}
public record UpdateTemplateRequest(
    string? Name,
    string? Body,
    string? Subject,
    Guid?   ProviderConfigId
);
