using admarkifyapi.Services;

namespace admarkifyapi.Middleware;

public class SessionMiddleware(RequestDelegate next)
{
    private static readonly HashSet<string> _publicPaths =
    [
        "/api/auth/register",
        "/api/auth/login",
        "/api/auth/verify-otp",
        "/api/auth/send-login-otp",
        "/api/auth/accept-invite",
        "/api/auth/verify-invite-otp",
        "/api/auth/change-password",
        "/api/auth/request-change-password",
        "/api/organizations/search",
        "/api/organizations/plans",
        "/api/providers/all",
        "/swagger",
        "/swagger/index.html",
        "/swagger/v1/swagger.json",
    ];

    public async Task InvokeAsync(HttpContext context, IAuthService authService)
    {
        var path = context.Request.Path.Value ?? "";

        if (_publicPaths.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
        {
            await next(context);
            return;
        }

        var authHeader = context.Request.Headers.Authorization.FirstOrDefault();
        if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer "))
        {
            context.Response.StatusCode = 401;
            await context.Response.WriteAsJsonAsync(new
            {
                status  = "UNAUTHORIZED",
                message = "Missing or invalid Bearer token.",
                data    = (object?)null
            });
            return;
        }

        var rawToken = authHeader["Bearer ".Length..].Trim();

        try
        {
            var session = await authService.VerifySessionAsync(rawToken);
            context.Items["Session"] = session;
            context.Items["OrgId"]   = session.GetProperty("org_id").GetString();
            context.Items["UserId"]  = session.GetProperty("user_id").GetString();
            context.Items["Role"]    = session.GetProperty("role").GetString();
            await next(context);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Session error: {ex.Message}");

            var isAuthError = ex.Message.StartsWith("SESSION_INVALID") ||
                              ex.Message.StartsWith("AUTH_FAILED");

            context.Response.StatusCode = isAuthError ? 401 : 403;
            await context.Response.WriteAsJsonAsync(new
            {
                status  = isAuthError ? "SESSION_INVALID" : "FORBIDDEN",
                message = ex.Message,
                data    = (object?)null
            });
        }
    }
}