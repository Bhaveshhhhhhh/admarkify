using admarkifyapi.Services;
using System.Text.Json;

namespace admarkifyapi.Middleware;

/// <summary>
/// Validates the Bearer token via admarkify.fn_verify_session() on every
/// request that targets a protected route. Injects session context into
/// HttpContext.Items so controllers can read it without another DB round-trip.
/// </summary>
public class SessionMiddleware(RequestDelegate next)
{
    // Routes that don't require authentication
    private static readonly HashSet<string> _publicPaths =
    [
        "/api/auth/register",
        "/api/auth/login",
        "/api/auth/accept-invite",
        "/swagger",
        "/swagger/index.html",
        "/swagger/v1/swagger.json",
    ];

    public async Task InvokeAsync(HttpContext context, IAuthService authService)
    {
        var path = context.Request.Path.Value ?? "";

        // Allow public paths and Swagger through without a token
        if (_publicPaths.Any(p => path.StartsWith(p, StringComparison.OrdinalIgnoreCase)))
        {
            await next(context);
            return;
        }

        var authHeader = context.Request.Headers.Authorization.FirstOrDefault();
        if (string.IsNullOrWhiteSpace(authHeader) || !authHeader.StartsWith("Bearer "))
        {
            context.Response.StatusCode = 401;
            await context.Response.WriteAsJsonAsync(new { error = "UNAUTHORIZED: missing Bearer token" });
            return;
        }

        var rawToken = authHeader["Bearer ".Length..].Trim();

        try
        {
            var session = await authService.VerifySessionAsync(rawToken);
            // Inject for controllers
            context.Items["Session"]  = session;
            context.Items["OrgId"]    = session.GetProperty("org_id").GetString();
            context.Items["UserId"]   = session.GetProperty("user_id").GetString();
            context.Items["Role"]     = session.GetProperty("role").GetString();
            await next(context);
        }
        catch (Exception ex)
        {
            var code = ex.Message.StartsWith("SESSION_INVALID") ? 401 : 403;
            context.Response.StatusCode = code;
            await context.Response.WriteAsJsonAsync(new { error = ex.Message });
        }
    }
}
