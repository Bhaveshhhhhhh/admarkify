using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace admarkifyapi.Controllers;

[Route("api/templates")]
public class TemplateController(
    ITemplateService        templateService,
    IIntegrationService     integrationService,
    WhatsAppProviderService whatsAppService,
    EmailProviderService    emailService)           // ✅ replaces Msg91EmailService
    : AdmarkifyControllerBase
{
    // ── GET /api/templates ────────────────────────────────────
    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? channel          = null,
        [FromQuery] string? status           = null,
        [FromQuery] Guid?   providerConfigId = null)
    {
        try
        {
            var result = await templateService.GetAllAsync(OrgId, channel, status, providerConfigId);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/templates ───────────────────────────────────
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTemplateRequest req)
    {
        try
        {
            // Step 1: Save template in DB
            var result = await templateService.CreateAsync(
                OrgId, UserId,
                req.Name, req.Channel,
                req.ProviderConfigId,
                req.ExternalTemplateName,
                req.ProviderPayload,
                req.Variables);

            var templateId = Guid.Parse(result.GetProperty("template_id").GetString()!);

            // Step 2: Push to provider if payload supplied
            if (req.ProviderConfigId != null && req.ProviderPayload != null)
            {
                var provider = await integrationService.GetByIdAsync(req.ProviderConfigId.Value);
                var config   = Decrypt(provider.Credentials);
                var endPoint = provider.EndPoint;

                switch (provider.Code)
                {
                    // ── WATI (WhatsApp) ───────────────────────
                    case "wati":
                    {
                        var raw = await whatsAppService.CreateWatiTemplateAsync(  // ✅
                            config["api_endpoint"],
                            config["bearer_token"],
                            req.ProviderPayload.Value);

                        var json       = JsonDocument.Parse(raw).RootElement;
                        var externalId = json.GetProperty("result")
                                             .GetProperty("id")
                                             .GetString();

                        await templateService.UpdateExternalAsync(
                            templateId, externalId, req.ProviderPayload.Value, json);
                        break;
                    }

                    // ── Meta WhatsApp ─────────────────────────
                    case "meta_whatsapp":
                    {
                        var raw = await whatsAppService.CreateMetaTemplateAsync(  // ✅
                            config["access_token"],
                            config["waba_id"],
                            req.ProviderPayload.Value);

                        var json       = JsonDocument.Parse(raw).RootElement;
                        var externalId = json.GetProperty("id").GetString();

                        await templateService.UpdateExternalAsync(
                            templateId, externalId, req.ProviderPayload.Value, json);
                        break;
                    }

                    // ── MSG91 Email ───────────────────────────
                    case "msg91_email":
                    {
                        var raw = await emailService.CreateMsg91TemplateAsync(  // ✅
                            endPoint!,
                            config["authkey"],
                            req.ProviderPayload.Value);

                        var json = JsonDocument.Parse(raw).RootElement;

                        string? externalId = null;
                        if (json.TryGetProperty("data", out var data) &&
                            data.TryGetProperty("id", out var idProp))
                        {
                            externalId = idProp.GetString();
                        }

                        await templateService.UpdateExternalAsync(
                            templateId, externalId, req.ProviderPayload.Value, json);
                        break;
                    }
                }
            }

            return StatusCode(201, result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── PUT /api/templates/{id} ───────────────────────────────
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateTemplateRequest req)
    {
        try
        {
            var result = await templateService.UpdateAsync(
                OrgId, UserId, id,
                req.Name, req.ProviderConfigId, req.ProviderPayload);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/templates/{id}/publish ─────────────────────
    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id)
    {
        try
        {
            await templateService.PublishAsync(OrgId, UserId, id);
            return Respond(new { published = true, template_id = id });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── DELETE /api/templates/{id} ────────────────────────────
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Archive(Guid id)
    {
        try
        {
            await templateService.ArchiveAsync(OrgId, UserId, id);
            return Respond(new { archived = true, template_id = id });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── Helpers ───────────────────────────────────────────────
    private static Dictionary<string, string> Decrypt(string credentialsJson)
        => JsonSerializer.Deserialize<Dictionary<string, string>>(credentialsJson)
           ?? throw new InvalidOperationException("Failed to deserialize provider credentials.");
}