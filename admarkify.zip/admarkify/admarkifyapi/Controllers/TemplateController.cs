using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace admarkifyapi.Controllers;

[Route("api/templates")]
public class TemplateController(
    ITemplateService templateService,
    IIntegrationService integrationService,
    WatiService watiService,
    MetaWhatsAppService metaWhatsAppService)   // ← added
    : AdmarkifyControllerBase
{
    // ── GET /api/templates ────────────────────────────────────
    [HttpGet]
    public async Task<IActionResult> GetAll(
        [FromQuery] string? channel = null,
        [FromQuery] string? status = null,
        [FromQuery] Guid? providerConfigId = null)
    {
        try
        {
            var result = await templateService.GetAllAsync(OrgId, channel, status, providerConfigId);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/templates ───────────────────────────────────
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTemplateRequest req)
    {
        try
        {
            // Step 1: Save template in DB
            var result = await templateService.CreateAsync(
                OrgId, UserId,
                req.Name, req.Channel, req.Body,
                req.Subject, req.ProviderConfigId, req.ExternalTemplateName);

            var templateId = Guid.Parse(result.GetProperty("template_id").GetString()!);

            // Step 2: If WhatsApp → call the right provider
            if (req.Channel == "whatsapp" && req.ProviderConfigId != null && req.ProviderPayload != null)
            {
                var provider = await integrationService.GetByIdAsync(req.ProviderConfigId.Value);
                var config = Decrypt(provider.Credentials);

                switch (provider.Code)
                {
                    // ── WATI ──────────────────────────────────
                    case "wati":
                        {
                            var raw = await watiService.CreateTemplateAsync(
                                config["api_endpoint"],
                                config["bearer_token"],
                                req.ProviderPayload.Value);

                            var json = JsonDocument.Parse(raw).RootElement;
                            var externalId = json.GetProperty("result")
                                                 .GetProperty("id")
                                                 .GetString();

                            await templateService.UpdateExternalAsync(
                                templateId, externalId, req.ProviderPayload.Value, json);
                            break;
                        }

                    // ── Meta WhatsApp ──────────────────────────
                    case "meta_whatsapp":
                        {
                            var raw = await metaWhatsAppService.CreateTemplateAsync(
                                config["access_token"],
                                config["waba_id"],
                                req.ProviderPayload.Value);

                            var json = JsonDocument.Parse(raw).RootElement;

                            // Meta returns { "id": "...", "status": "PENDING", "category": "..." }
                            var externalId = json.GetProperty("id").GetString();

                            await templateService.UpdateExternalAsync(
                                templateId, externalId, req.ProviderPayload.Value, json);
                            break;
                        }
                }
            }

            return StatusCode(201, result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── PUT /api/templates/{id} ───────────────────────────────
    [HttpPut("{id:guid}")]
    public async Task<IActionResult> Update(Guid id, [FromBody] UpdateTemplateRequest req)
    {
        try
        {
            var result = await templateService.UpdateAsync(
                OrgId, UserId, id,
                req.Name, req.Body, req.Subject, req.ProviderConfigId);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/templates/{id}/publish ─────────────────────
    [HttpPost("{id:guid}/publish")]
    public async Task<IActionResult> Publish(Guid id)
    {
        try
        {
            await templateService.PublishAsync(OrgId, UserId, id);
            return Respond(new { published = true, template_id = id });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── DELETE /api/templates/{id} ────────────────────────────
    [HttpDelete("{id:guid}")]
    public async Task<IActionResult> Archive(Guid id)
    {
        try
        {
            await templateService.ArchiveAsync(OrgId, UserId, id);
            return Respond(new { archived = true, template_id = id });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── Helpers ───────────────────────────────────────────────
    private static Dictionary<string, string> Decrypt(string credentialsJson)
        => JsonSerializer.Deserialize<Dictionary<string, string>>(credentialsJson)
           ?? throw new InvalidOperationException("Failed to decrypt provider credentials.");
}