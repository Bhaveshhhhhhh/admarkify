using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

[Route("api/team")]
public class TeamController(ITeamService teamService) : AdmarkifyControllerBase
{
    // ─────────────────────────────────────────────────────────
    // 🔹 Common Response Helpers
    // ─────────────────────────────────────────────────────────
    private IActionResult Success(string message, object? data = null, string? status = "OK")
    {
        return Ok(new { status, message, data });
    }

    private IActionResult Error(Exception ex)
    {
        return BadRequest(new
        {
            status  = "EXCEPTION",
            message = ex.Message,
            data    = (object?)null
        });
    }

    // ── POST /api/team/invite ─────────────────────────────────
    [HttpPost("invite")]
    public async Task<IActionResult> Invite([FromBody] InviteMemberRequest req)
    {
        try
        {
            var result = await teamService.InviteMemberAsync(OrgId, UserId, req.Email, req.Role);
            return Success("Member invited successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── PUT /api/team/role ────────────────────────────────────
    [HttpPut("role")]
    public async Task<IActionResult> UpdateRole([FromBody] UpdateRoleRequest req)
    {
        try
        {
            await teamService.UpdateMemberRoleAsync(OrgId, UserId, req.TargetUserId, req.NewRole);
            return Success("Member role updated successfully", new { updated = true });
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── GET /api/team/members ─────────────────────────────────
    [HttpGet("members")]
    public async Task<IActionResult> GetMembers(
        [FromQuery] string? status   = null,
        [FromQuery] string? role     = null,
        [FromQuery] string? search   = null,
        [FromQuery] int     page     = 1,
        [FromQuery] int     pageSize = 10)
    {
        try
        {
            var result = await teamService.GetMembersAsync(OrgId, status, role, search, page, pageSize);
            return Success("Members fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── DELETE /api/team/member ───────────────────────────────
    [HttpDelete("member")]
    public async Task<IActionResult> RemoveMember([FromBody] RemoveMemberRequest req)
    {
        try
        {
            await teamService.RemoveMemberAsync(OrgId, UserId, req.TargetUserId);
            return Success("Member removed successfully", new { removed = true });
        }
        catch (Exception ex) { return Error(ex); }
    }
}