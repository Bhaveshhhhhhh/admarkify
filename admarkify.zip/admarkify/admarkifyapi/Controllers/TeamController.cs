using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

/// <summary>
/// Team / member management — all endpoints require Bearer token.
/// POST   /api/team/invite          → invite a member
/// PUT    /api/team/role            → change a member's role
/// DELETE /api/team/member          → remove a member
/// </summary>
[Route("api/team")]
public class TeamController(ITeamService teamService) : AdmarkifyControllerBase
{
    // ── POST /api/team/invite ─────────────────────────────────
    /// <summary>
    /// Invite a new member to the org by email.
    /// Returns raw_token to embed in the invitation email URL.
    /// Roles: admin | manager | lead | executive
    /// </summary>
    [HttpPost("invite")]
    public async Task<IActionResult> Invite([FromBody] InviteMemberRequest req)
    {
        try
        {
            var result = await teamService.InviteMemberAsync(OrgId, UserId, req.Email, req.Role);
            return StatusCode(201, result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── PUT /api/team/role ────────────────────────────────────
    /// <summary>Change a team member's role. Actor must be admin.</summary>
    [HttpPut("role")]
    public async Task<IActionResult> UpdateRole([FromBody] UpdateRoleRequest req)
    {
        try
        {
            await teamService.UpdateMemberRoleAsync(OrgId, UserId, req.TargetUserId, req.NewRole);
            return Respond(new { updated = true });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── DELETE /api/team/member ───────────────────────────────
    /// <summary>
    /// Remove (suspend) a member from the org and revoke their sessions.
    /// Actor must be admin.
    /// </summary>
    [HttpDelete("member")]
    public async Task<IActionResult> RemoveMember([FromBody] RemoveMemberRequest req)
    {
        try
        {
            await teamService.RemoveMemberAsync(OrgId, UserId, req.TargetUserId);
            return Respond(new { removed = true });
        }
        catch (Exception ex) { return HandleError(ex); }
    }
}
