using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

/// <summary>
/// Organization management — all endpoints require Bearer token.
/// POST   /api/organizations           → create org
/// POST   /api/organizations/upgrade   → upgrade plan
/// </summary>
[Route("api/organizations")]
public class OrganizationController(IOrganizationService orgService)
    : AdmarkifyControllerBase
{
    // ── POST /api/organizations ───────────────────────────────
    /// <summary>
    /// Create a new organization. The authenticated user becomes admin.
    /// plan_id: 1=Free, 2=Paid, 3=Pro
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateOrgRequest req)
    {
        try
        {
            var orgId = await orgService.CreateAsync(
                UserId, req.Name, req.Slug, req.PlanId, req.Timezone);
            return StatusCode(201, new { org_id = orgId });
        }
        catch (Exception ex) { return HandleError(ex); }
    }
    
    [HttpPost("search")]
    public async Task<IActionResult> Search([FromBody] SearchOrgRequest req)
    {
        try
        {
            var result = await orgService.SearchAsync(req);
            return Ok(result);
        }
        catch (Exception ex)
        {
            return HandleError(ex);
        }
    }

    // ── POST /api/organizations/upgrade ──────────────────────
    /// <summary>Upgrade or change the org's subscription plan.</summary>
    [HttpPost("upgrade")]
    public async Task<IActionResult> UpgradePlan([FromBody] UpgradePlanRequest req)
    {
        try
        {
            var result = await orgService.UpgradePlanAsync(OrgId, req.NewPlanId, req.ExpiresAt);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }
}
