using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

[Route("api/organizations")]
public class OrganizationController(IOrganizationService orgService)
    : AdmarkifyControllerBase
{
    // ─────────────────────────────────────────────────────────
    // 🔹 Common Response Helpers
    // ─────────────────────────────────────────────────────────
    private IActionResult Success(string message, object? data = null, string? status = "OK")
    {
        return Ok(new { status, message, data });
    }

    private IActionResult Error(Exception ex)
    {
        return BadRequest(new
        {
            status  = "EXCEPTION",
            message = ex.Message,
            data    = (object?)null
        });
    }

    // ── POST /api/organizations ───────────────────────────────
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateOrgRequest req)
    {
        try
        {
            var orgId = await orgService.CreateAsync(
                UserId, req.Name, req.Slug, req.PlanId, req.Timezone);
            return Success("Organization created successfully", new { org_id = orgId });
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── POST /api/organizations/search ────────────────────────
    [HttpPost("search")]
    public async Task<IActionResult> Search([FromBody] SearchOrgRequest req)
    {
        try
        {
            var result = await orgService.SearchAsync(req);
            return Success("Organizations fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── GET /api/organizations/details ────────────────────────
    [HttpGet("details")]
    public async Task<IActionResult> GetDetails([FromQuery] Guid? orgId, [FromQuery] string? slug)
    {
        try
        {
            var result = await orgService.GetOrganizationDetailsAsync(orgId, slug);
            return Success("Organization details fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── GET /api/organizations/plans ──────────────────────────
    [HttpGet("plans")]
    public async Task<IActionResult> GetPlans([FromQuery] bool onlyActive = true)
    {
        try
        {
            var result = await orgService.GetAllPlansAsync(onlyActive);
            return Success("Plans fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── POST /api/organizations/upgrade ──────────────────────
    [HttpPost("upgrade")]
    public async Task<IActionResult> UpgradePlan([FromBody] UpgradePlanRequest req)
    {
        try
        {
            var result = await orgService.UpgradePlanAsync(OrgId, req.NewPlanId, req.ExpiresAt);
            return Success("Plan upgraded successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }
}