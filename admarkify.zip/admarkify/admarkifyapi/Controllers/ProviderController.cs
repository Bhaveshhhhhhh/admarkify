using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

[Route("api/providers")]
public class ProviderController(IProviderService providerService) : AdmarkifyControllerBase
{
    // ─────────────────────────────────────────────────────────
    // 🔹 Common Response Helpers
    // ─────────────────────────────────────────────────────────
    private IActionResult Success(string message, object? data = null, string? status = "OK")
    {
        return Ok(new { status, message, data });
    }

    private IActionResult Error(Exception ex)
    {
        return BadRequest(new
        {
            status  = "EXCEPTION",
            message = ex.Message,
            data    = (object?)null
        });
    }

    // ── GET /api/providers ────────────────────────────────────
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? channel = null)
    {
        try
        {
            var result = await providerService.GetAllAsync(OrgId, channel);
            return Success("Providers fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── POST /api/providers ───────────────────────────────────
    [HttpPost]
    public async Task<IActionResult> Add([FromBody] AddProviderRequest req)
    {
        try
        {
            var result = await providerService.AddAsync(
                OrgId, UserId,
                req.ProviderCode, req.Label,
                req.Credentials, req.Settings);
            return Success("Provider added successfully", result);  // ✅ was StatusCode(201, result) — no message/status
        }
        catch (Exception ex) { return Error(ex); }
    }
    // ── PUT /api/providers ────────────────────────────────────
    [HttpPut]
    public async Task<IActionResult> Update([FromBody] UpdateProviderRequest req)
    {
        try
        {
            var result = await providerService.UpdateAsync(
                OrgId, UserId,
                req.ConfigId, req.Label,
                req.Credentials, req.Settings);
            return Success("Provider updated successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }
    // ── PUT /api/providers/default ────────────────────────────
    [HttpPut("default")]
    public async Task<IActionResult> SetDefault([FromBody] SetDefaultProviderRequest req)
    {
        try
        {
            await providerService.SetDefaultAsync(OrgId, UserId, req.ConfigId);
            return Success("Default provider updated successfully", new { updated = true });
        }
        catch (Exception ex) { return Error(ex); }
    }

    // ── DELETE /api/providers ─────────────────────────────────
    [HttpDelete]
    public async Task<IActionResult> Remove([FromBody] RemoveProviderRequest req)
    {
        try
        {
            await providerService.RemoveAsync(OrgId, UserId, req.ConfigId);
            return Success("Provider removed successfully", new { removed = true });
        }
        catch (Exception ex) { return Error(ex); }
    }

    [HttpGet("all")]
    public async Task<IActionResult> GetAllChannelProviders(
        [FromQuery] string? channel = null,
        [FromQuery] string? code    = null,
        [FromQuery] int?    id      = null)
    {
        try
        {
            var result = await providerService.GetAllChannelProvidersAsync(channel, code, id);
            return Success("Channel providers fetched successfully", result);
        }
        catch (Exception ex) { return Error(ex); }
    }
}