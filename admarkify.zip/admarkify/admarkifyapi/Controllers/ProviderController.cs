using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

/// <summary>
/// External provider config management.
/// GET    /api/providers              → list org's provider configs
/// GET    /api/providers?channel=sms  → filter by channel
/// POST   /api/providers              → connect a new provider
/// PUT    /api/providers/default      → set default provider
/// DELETE /api/providers              → remove a provider config
/// </summary>
[Route("api/providers")]
public class ProviderController(IProviderService providerService) : AdmarkifyControllerBase
{
    // ── GET /api/providers ────────────────────────────────────
    /// <summary>
    /// List all connected provider configs for the org.
    /// Optional query param: channel=sms|whatsapp|email|voice|push
    /// </summary>
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? channel = null)
    {
        try
        {
            var result = await providerService.GetAllAsync(OrgId, channel);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/providers ───────────────────────────────────
    /// <summary>
    /// Connect an external provider to this org.
    /// ProviderCode examples: msg91_sms, twilio_sms, wati, sendgrid, mailgun, smtp_generic, firebase_push
    /// Credentials must be encrypted at the client before sending.
    /// First provider for a channel is automatically set as default.
    /// </summary>
    [HttpPost]
    public async Task<IActionResult> Add([FromBody] AddProviderRequest req)
    {
        try
        {
            var result = await providerService.AddAsync(
                OrgId, UserId,
                req.ProviderCode, req.Label,
                req.Credentials, req.Settings);
            return StatusCode(201, result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── PUT /api/providers/default ────────────────────────────
    /// <summary>Mark a provider config as the default for its channel.</summary>
    [HttpPut("default")]
    public async Task<IActionResult> SetDefault([FromBody] SetDefaultProviderRequest req)
    {
        try
        {
            await providerService.SetDefaultAsync(OrgId, UserId, req.ConfigId);
            return Respond(new { updated = true });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── DELETE /api/providers ─────────────────────────────────
    /// <summary>
    /// Remove (deactivate) a provider config.
    /// Blocked if active templates still reference it.
    /// </summary>
    [HttpDelete]
    public async Task<IActionResult> Remove([FromBody] RemoveProviderRequest req)
    {
        try
        {
            await providerService.RemoveAsync(OrgId, UserId, req.ConfigId);
            return Respond(new { removed = true });
        }
        catch (Exception ex) { return HandleError(ex); }
    }
}
