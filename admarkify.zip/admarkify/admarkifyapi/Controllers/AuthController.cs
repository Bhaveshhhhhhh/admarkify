using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

[Route("api/auth")]
public class AuthController(IAuthService authService, IHttpContextAccessor http)
    : AdmarkifyControllerBase
{
    // ─────────────────────────────────────────────────────────
    // 🔹 Common Response Helpers
    // ─────────────────────────────────────────────────────────
    private IActionResult Success(string message, object? data = null, string? status = "OK")
    {
        return Ok(new
        {
            status,
            message,
            data
        });
    }

    private IActionResult Error(Exception ex)
    {
        return BadRequest(new
        {
            status  = "EXCEPTION",
            message = ex.Message,
            data    = (object?)null
        });
    }

    // ── POST /api/auth/register ───────────────────────────────
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req)
    {
        try
        {
            var userId = await authService.RegisterAsync(
                req.Email,
                req.Password,
                req.FullName,
                req.Mobile
            );

            if (userId == Guid.Empty)
            {
                return BadRequest(new
                {
                    status  = "NOT_OK",
                    message = "Failed to send OTP",
                    data    = (object?)null
                });
            }

            return Success("OTP sent successfully");
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }

    // ── POST /api/auth/verify-otp ─────────────────────────────
    [HttpPost("verify-otp")]
    public async Task<IActionResult> VerifyOtp([FromBody] VerifyOtpRequest req)
    {
        if (string.IsNullOrEmpty(req.Email) && string.IsNullOrEmpty(req.Mobile))
        return BadRequest(new { status = "NOT_OK", message = "Email or Mobile is required", data = (object?)null });
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();

            var result = await authService.VerifyOtpAsync(
                req.Email,
                req.Mobile,
                req.Otp,
                req.Type,
                ip,
                ua
            );

            if (result.TryGetProperty("raw_token", out _))
                return Success("Verification successful", result);

            return Success("OTP verified", result);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }

    // ── POST /api/auth/login ──────────────────────────────────
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();

            var session = await authService.LoginAsync(
                req.Email,
                req.Password,
                req.OrgSlug,
                ip,
                ua
            );

            return Success("Login successful", session);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }
    // ── POST /api/auth/send-login-otp ─────────────────────────
    [HttpPost("send-login-otp")]
    public async Task<IActionResult> SendLoginOtp([FromBody] SendLoginOtpRequest req)
    {
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();

            // Exceptions from service/DB handle all failure cases
            await authService.SendLoginOtpAsync(req.Email, ip);

            return Success("OTP sent to your registered email and mobile");
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }
    // ── POST /api/auth/login-otp ──────────────────────────────
    [HttpPost("login-otp")]
    public async Task<IActionResult> LoginWithOtp([FromBody] LoginWithOtpRequest req)
    {
        try
        {
            var ip      = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua      = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();
            var session = await authService.LoginWithOtpAsync(req.Email, req.Otp, req.OrgSlug, ip, ua);

            return Success("Login successful", session);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }
    // ── GET /api/auth/UserDetails ─────────────────────────────
    [HttpGet("UserDetails")]
    public async Task<IActionResult> GetCurrentSession()
    {
        try
        {
            var authHeader = Request.Headers.Authorization.FirstOrDefault();

            if (string.IsNullOrWhiteSpace(authHeader) ||
                !authHeader.StartsWith("Bearer ", StringComparison.OrdinalIgnoreCase))
            {
                return BadRequest(new
                {
                    status  = "NOT_OK",
                    message = "Invalid Authorization header",
                    data    = (object?)null
                });
            }

            var token   = authHeader.Substring("Bearer ".Length).Trim();
            var session = await authService.GetSessionByTokenAsync(token);

            return Success("Session fetched successfully", session);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }

    // ── POST /api/auth/logout ─────────────────────────────────
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        try
        {
            var token = Request.Headers.Authorization
                .FirstOrDefault()?.Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                return BadRequest(new
                {
                    status  = "NOT_OK",
                    message = "Authorization token is missing",
                    data    = (object?)null
                });
            }

            var revoked = await authService.LogoutAsync(token);

            return Success("Logout successful", revoked);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }

    // ── POST /api/auth/logout-all ─────────────────────────────
    [HttpPost("logout-all")]
    public async Task<IActionResult> LogoutAll()
    {
        try
        {
            var token = Request.Headers.Authorization
                .FirstOrDefault()?.Replace("Bearer ", "");

            if (string.IsNullOrEmpty(token))
            {
                return BadRequest(new
                {
                    status  = "NOT_OK",
                    message = "Authorization token is missing",
                    data    = (object?)null
                });
            }

            var count = await authService.LogoutAllAsync(token);

            return Success("All sessions logged out successfully", count);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }

    // ── POST /api/auth/accept-invite ──────────────────────────
    [HttpPost("accept-invite")]
    public async Task<IActionResult> AcceptInvite([FromBody] AcceptInviteRequest req)
    {
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();

            var result = await authService.AcceptInviteAsync(
                req.RawToken,
                req.FullName,
                req.Password,
                ip,
                ua
            );

            return Success("Invitation accepted successfully", result);
        }
        catch (Exception ex)
        {
            return Error(ex);
        }
    }
}