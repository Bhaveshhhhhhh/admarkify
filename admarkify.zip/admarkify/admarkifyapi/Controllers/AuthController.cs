using admarkifyapi.Models.Requests;
using admarkifyapi.Services;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

/// <summary>
/// Public auth endpoints — no Bearer token required.
/// POST /api/auth/register
/// POST /api/auth/login
/// POST /api/auth/logout
/// POST /api/auth/logout-all
/// POST /api/auth/accept-invite
/// </summary>
[Route("api/auth")]
public class AuthController(IAuthService authService, IHttpContextAccessor http)
    : AdmarkifyControllerBase
{
    // ── POST /api/auth/register ───────────────────────────────
    /// <summary>Create a new user account.</summary>
    [HttpPost("register")]
    public async Task<IActionResult> Register([FromBody] RegisterRequest req)
    {
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();
            var result = await authService.RegisterAsync(
                req.Email,
                req.Password,
                req.FullName,
                req.OrgName,
                req.OrgSlug,
                ip,
                ua
            );

            return Ok(new
            {
                status = "OK",
                message = "User + Organization created successfully",
                data = result
            });
        }
        catch (Exception ex)
        {
            return BadRequest(new
            {
                status = "Exception",
                message = ex.Message,
                data = (object?)null
            });
        }
    }

    // ── POST /api/auth/login ──────────────────────────────────
    /// <summary>
    /// Authenticate user for a specific org.
    /// Returns raw_token — store securely and send as Bearer on all future requests.
    /// </summary>
    [HttpPost("login")]
    public async Task<IActionResult> Login([FromBody] LoginRequest req)
    {
        try
        {
            var ip      = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua      = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();
            var session = await authService.LoginAsync(req.Email, req.Password, req.OrgSlug, ip, ua);
            return Respond(session);
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/auth/logout ─────────────────────────────────
    /// <summary>Revoke the current session token.</summary>
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        try
        {
            var token = Request.Headers.Authorization.FirstOrDefault()?.Replace("Bearer ", "");
            if (token is null) return BadRequest(new { error = "No token" });
            var revoked = await authService.LogoutAsync(token);
            return Respond(new { revoked });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/auth/logout-all ─────────────────────────────
    /// <summary>Revoke ALL sessions for the current user across all orgs.</summary>
    [HttpPost("logout-all")]
    public async Task<IActionResult> LogoutAll()
    {
        try
        {
            var count = await authService.LogoutAllAsync(UserId);
            return Respond(new { sessions_revoked = count });
        }
        catch (Exception ex) { return HandleError(ex); }
    }

    // ── POST /api/auth/accept-invite ──────────────────────────
    /// <summary>
    /// Accept a team invitation.
    /// New user → supply FullName + Password.
    /// Existing user → omit both; then call /login.
    /// </summary>
    [HttpPost("accept-invite")]
    public async Task<IActionResult> AcceptInvite([FromBody] AcceptInviteRequest req)
    {
        try
        {
            var ip = http.HttpContext?.Connection.RemoteIpAddress?.ToString();
            var ua = http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();
            var result = await authService.AcceptInviteAsync(
                req.RawToken, req.FullName, req.Password, ip, ua);
            return Respond(result);
        }
        catch (Exception ex) { return HandleError(ex); }
    }
}
