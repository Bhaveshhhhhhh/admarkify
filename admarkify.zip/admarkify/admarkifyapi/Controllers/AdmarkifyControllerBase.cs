using admarkifyapi.Models.Responses;
using Microsoft.AspNetCore.Mvc;

namespace admarkifyapi.Controllers;

/// <summary>
/// All admarkify controllers inherit this.
/// Provides session context helpers and uniform error handling.
/// </summary>
[ApiController]
public abstract class AdmarkifyControllerBase : ControllerBase
{
    protected Guid OrgId   => Guid.Parse(HttpContext.Items["OrgId"]!.ToString()!);
    protected Guid UserId  => Guid.Parse(HttpContext.Items["UserId"]!.ToString()!);
    protected string Role  => HttpContext.Items["Role"]!.ToString()!;

    protected IActionResult Respond<T>(T data)
        => Ok(ApiResponse<T>.Ok(data));

    protected IActionResult HandleError(Exception ex)
    {
        var msg = ex.Message;

        if (msg.Contains("NOT_FOUND"))         return NotFound(new ErrorResponse(msg));
        if (msg.Contains("AUTH_FAILED"))       return Unauthorized(new ErrorResponse(msg));
        if (msg.Contains("SESSION_INVALID"))   return Unauthorized(new ErrorResponse(msg));
        if (msg.Contains("PERMISSION_DENIED")) return Forbid();
        if (msg.Contains("PLAN_LIMIT"))        return StatusCode(402, new ErrorResponse(msg));
        if (msg.Contains("PLAN_EXPIRED"))      return StatusCode(402, new ErrorResponse(msg));

        return BadRequest(new ErrorResponse(msg));
    }
}
