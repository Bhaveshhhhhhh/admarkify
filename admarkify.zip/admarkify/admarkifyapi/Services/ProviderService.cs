using Npgsql;
using System.Text.Json;
using System.Text.Json.Nodes;

namespace admarkifyapi.Services;

public interface IProviderService
{
    Task<JsonElement> AddAsync(Guid orgId, Guid actorId, string providerCode, string label, JsonObject credentials, JsonObject? settings);
    Task<JsonElement> GetAllAsync(Guid orgId, string? channel);
    Task              SetDefaultAsync(Guid orgId, Guid actorId, Guid configId);
    Task              RemoveAsync(Guid orgId, Guid actorId, Guid configId);
}

public class ProviderService(NpgsqlDataSource ds) : DbServiceBase(ds), IProviderService
{
    public Task<JsonElement> AddAsync(Guid orgId, Guid actorId, string providerCode,
        string label, JsonObject credentials, JsonObject? settings)
        => QueryJsonAsync(
            @"SELECT admarkify.fn_add_org_provider(
                @orgId, @actorId, @providerCode, @label,
                @credentials::JSONB, @settings::JSONB)",
            new
            {
                orgId,
                actorId,
                providerCode,
                label,
                credentials = credentials.ToJsonString(),
                settings    = (settings ?? new JsonObject()).ToJsonString()
            });

    public Task<JsonElement> GetAllAsync(Guid orgId, string? channel)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_org_providers(@orgId, @channel)",
            new { orgId, channel });

    public Task SetDefaultAsync(Guid orgId, Guid actorId, Guid configId)
        => ExecAsync(
            "SELECT admarkify.fn_set_default_provider(@orgId, @actorId, @configId)",
            new { orgId, actorId, configId });

    public Task RemoveAsync(Guid orgId, Guid actorId, Guid configId)
        => ExecAsync(
            "SELECT admarkify.fn_remove_org_provider(@orgId, @actorId, @configId)",
            new { orgId, actorId, configId });
}
