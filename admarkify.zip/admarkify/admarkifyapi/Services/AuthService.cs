using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public interface IAuthService
{
    Task<Guid> RegisterAsync(
        string email,
        string password,
        string fullName,
        string mobile
    );
    Task<JsonElement> VerifyOtpAsync(string email, string mobile, string otp, string type, string? ip, string? ua);
    Task<JsonElement> LoginAsync(string email, string password, string? orgSlug, string? ip, string? ua);

    Task<JsonElement> SendLoginOtpAsync(string email, string? ip);
    Task<JsonElement> LoginWithOtpAsync(string email, string otp, string? orgSlug, string? ip, string? ua);

    Task<JsonElement> VerifySessionAsync(string rawToken);
    Task<JsonElement> GetSessionByTokenAsync(string token);
    Task<bool>        LogoutAsync(string rawToken);
    Task<int>         LogoutAllAsync(string rawToken);
    Task<JsonElement> AcceptInviteAsync(string rawToken, string? fullName, string? password, string? ip, string? ua);

}

public class AuthService(NpgsqlDataSource ds, IHttpContextAccessor http)
    : DbServiceBase(ds), IAuthService
{
    public async Task<Guid> RegisterAsync(
        string email,
        string password,
        string fullName,
        string mobile)
    {
        var result = await QueryJsonAsync(
            "SELECT admarkify.fn_register_user(@email, @password, @fullName, @mobile)",
            new { email, password, fullName, mobile });

        var userId = result.GetProperty("user_id").GetGuid();

        var emailOtp  = result.GetProperty("email_otp").GetString();
        var mobileOtp = result.GetProperty("mobile_otp").GetString();

        var userEmail  = result.GetProperty("email").GetString();
        var userMobile = result.GetProperty("mobile").GetString();

        if (string.IsNullOrEmpty(emailOtp) || string.IsNullOrEmpty(userEmail))
            throw new Exception("Invalid email OTP");

        if (string.IsNullOrEmpty(mobileOtp) || string.IsNullOrEmpty(userMobile))
            throw new Exception("Invalid mobile OTP");

        await SendEmailOtp(userEmail, emailOtp);
        await SendSmsOtp(userMobile, mobileOtp);

        return userId;
    }

    public async Task<JsonElement> VerifyOtpAsync(
        string email,
        string mobile,
        string otp,
        string type,
        string? ip,
        string? ua)
    {
        return await QueryJsonAsync(
            "SELECT admarkify.fn_verify_otp(@email, @mobile, @otp, @type, @ip::INET, @ua)",
            new { email, mobile, otp, type, ip, ua });
    }

    public Task<JsonElement> LoginAsync(string email, string password, string? orgSlug, string? ip, string? ua)
    => QueryJsonAsync(
        "SELECT admarkify.fn_login(@email, @password, NULL, @orgSlug, @ip::INET, @ua)",
        new { email, password, orgSlug, ip, ua });

    public async Task<JsonElement> SendLoginOtpAsync(string email, string? ip)
    {
        // fn_send_login_otp returns: { user_id, email, mobile, login_otp }
        var result = await QueryJsonAsync(
            "SELECT admarkify.fn_send_login_otp(@email, @ip::INET)",
            new { email, ip });

        var loginOtp   = result.GetProperty("login_otp").GetString();
        var userEmail  = result.GetProperty("email").GetString();
        var userMobile = result.GetProperty("mobile").GetString();

        if (string.IsNullOrEmpty(loginOtp))
            throw new Exception("Failed to generate login OTP");

        // Send the SAME OTP via both channels
        if (!string.IsNullOrEmpty(userEmail))
            await SendEmailOtp(userEmail, loginOtp);

        if (!string.IsNullOrEmpty(userMobile))
            await SendSmsOtp(userMobile, loginOtp);

        return result;
    }

    public Task<JsonElement> LoginWithOtpAsync(string email, string otp, string? orgSlug, string? ip, string? ua)
        => QueryJsonAsync(
            "SELECT admarkify.fn_login(@email, NULL, @otp, @orgSlug, @ip::INET, @ua)",
            new { email, otp, orgSlug, ip, ua });
            
    public Task<JsonElement> VerifySessionAsync(string rawToken)
        => QueryJsonAsync(
            "SELECT admarkify.fn_verify_session(@rawToken)",
            new { rawToken });

    public Task<JsonElement> GetSessionByTokenAsync(string token)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_session_by_token(@token)",
            new { token });

    public async Task<bool> LogoutAsync(string rawToken)
        => await QueryScalarAsync<bool>(
            "SELECT admarkify.fn_logout(@rawToken)",
            new { rawToken });

    public async Task<int> LogoutAllAsync(string rawToken)
        => await QueryScalarAsync<int>(
            "SELECT admarkify.fn_logout_all_by_token(@rawToken)",
            new { rawToken });

    public Task<JsonElement> AcceptInviteAsync(string rawToken, string? fullName, string? password, string? ip, string? ua)
        => QueryJsonAsync(
            "SELECT admarkify.fn_accept_invite(@rawToken, @fullName, @password, @ip::INET, @ua)",
            new { rawToken, fullName, password, ip, ua });

    // ── Private OTP senders ───────────────────────────────────
    private async Task SendEmailOtp(string email, string otp)
    {
        // TODO: integrate SMTP / SendGrid / etc.
        Console.WriteLine($"EMAIL OTP to {email}: {otp}");
        await Task.CompletedTask;
    }

    private async Task SendSmsOtp(string mobile, string otp)
    {
        // TODO: integrate MSG91 / Twilio / WhatsApp
        Console.WriteLine($"SMS OTP to {mobile}: {otp}");
        await Task.CompletedTask;
    }
}