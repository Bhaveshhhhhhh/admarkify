using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public interface IAuthService
{
    Task<JsonElement> RegisterAsync(
        string email,
        string password,
        string fullName,
        string? orgName,   // ✅ nullable
        string? orgSlug,   // ✅ nullable
        string? ip, string? ua
    );
    Task<JsonElement> LoginAsync(string email, string password, string? orgSlug, string? ip, string? ua); // ✅ nullable
    
    Task<JsonElement> VerifySessionAsync(string rawToken);
    Task<JsonElement> GetSessionByTokenAsync(string token);
    Task<bool>        LogoutAsync(string rawToken);
    Task<int>         LogoutAllAsync(string rawToken);
    Task<JsonElement> AcceptInviteAsync(string rawToken, string? fullName, string? password, string? ip, string? ua);
}

public class AuthService(NpgsqlDataSource ds, IHttpContextAccessor http)
    : DbServiceBase(ds), IAuthService
{
    public Task<JsonElement> RegisterAsync(
        string email, string password, string fullName,
        string? orgName, string? orgSlug, string? ip, string? ua)
        => QueryJsonAsync(
            "SELECT admarkify.fn_register_user(@email, @password, @fullName, @orgName, @orgSlug, @ip::INET, @ua)",
            new { email, password, fullName, orgName, orgSlug, ip, ua });

    public Task<JsonElement> LoginAsync(string email, string password, string? orgSlug, string? ip, string? ua)
        => QueryJsonAsync(
            "SELECT admarkify.fn_login(@email, @password, @orgSlug, @ip::INET, @ua)",
            new { email, password, orgSlug, ip, ua });

    public Task<JsonElement> VerifySessionAsync(string rawToken)
        => QueryJsonAsync(
            "SELECT admarkify.fn_verify_session(@rawToken)",
            new { rawToken });

    public Task<JsonElement> GetSessionByTokenAsync(string token)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_session_by_token(@token)",
            new { token }
        );
        
    public async Task<bool> LogoutAsync(string rawToken)
        => await QueryScalarAsync<bool>(
            "SELECT admarkify.fn_logout(@rawToken)",
            new { rawToken });

    public async Task<int> LogoutAllAsync(string rawToken)
        => await QueryScalarAsync<int>(
            "SELECT admarkify.fn_logout_all_by_token(@rawToken)",
            new { rawToken });

    public Task<JsonElement> AcceptInviteAsync(string rawToken, string? fullName, string? password, string? ip, string? ua)
        => QueryJsonAsync(
            "SELECT admarkify.fn_accept_invite(@rawToken, @fullName, @password, @ip::INET, @ua)",
            new { rawToken, fullName, password, ip, ua });
}
