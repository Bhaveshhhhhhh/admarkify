using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public interface ITeamService
{
    Task<JsonElement> InviteMemberAsync(Guid orgId, Guid invitedBy, string email, string role);
    Task              UpdateMemberRoleAsync(Guid orgId, Guid actorId, Guid targetUserId, string newRole);
    Task              RemoveMemberAsync(Guid orgId, Guid actorId, Guid targetUserId);
}

public class TeamService(NpgsqlDataSource ds) : DbServiceBase(ds), ITeamService
{
    public Task<JsonElement> InviteMemberAsync(Guid orgId, Guid invitedBy, string email, string role)
        => QueryJsonAsync(
            "SELECT admarkify.fn_invite_member(@orgId, @invitedBy, @email, @role)",
            new { orgId, invitedBy, email, role });

    public Task UpdateMemberRoleAsync(Guid orgId, Guid actorId, Guid targetUserId, string newRole)
        => ExecAsync(
            "SELECT admarkify.fn_update_member_role(@orgId, @actorId, @targetUserId, @newRole)",
            new { orgId, actorId, targetUserId, newRole });

    public Task RemoveMemberAsync(Guid orgId, Guid actorId, Guid targetUserId)
        => ExecAsync(
            "SELECT admarkify.fn_remove_member(@orgId, @actorId, @targetUserId)",
            new { orgId, actorId, targetUserId });
}
