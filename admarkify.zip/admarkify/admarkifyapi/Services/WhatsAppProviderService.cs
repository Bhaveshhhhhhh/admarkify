using System.Text;
using System.Text.Json;

namespace admarkifyapi.Services;

// ── WATI ──────────────────────────────────────────────────────
public class WatiService(HttpClient http)
{
    public async Task<string> CreateTemplateAsync(
        string baseUrl, string token, JsonElement payload)
    {
        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{baseUrl}/api/v1/whatsApp/templates");

        request.Headers.Add("Authorization", $"Bearer {token}");
        request.Headers.Add("accept", "application/json");
        request.Content = new StringContent(
            payload.ToString(), Encoding.UTF8, "application/json");

        var response = await http.SendAsync(request);
        return await response.Content.ReadAsStringAsync();
    }
}

// ── Meta WhatsApp ─────────────────────────────────────────────
public class MetaWhatsAppService(HttpClient http)
{
    private const string BaseUrl = "https://graph.facebook.com/v19.0";

    public async Task<string> CreateTemplateAsync(
        string accessToken, string wabaId, JsonElement payload)
    {
        var request = new HttpRequestMessage(
            HttpMethod.Post,
            $"{BaseUrl}/{wabaId}/message_templates");

        request.Headers.Add("Authorization", $"Bearer {accessToken}");
        request.Content = new StringContent(
            payload.ToString(), Encoding.UTF8, "application/json");

        var response = await http.SendAsync(request);
        return await response.Content.ReadAsStringAsync();
    }
}