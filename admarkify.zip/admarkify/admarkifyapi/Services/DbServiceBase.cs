using Dapper;
using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

/// <summary>
/// Base helper used by every service. All admarkify logic lives in PG functions,
/// so every call here is simply: call function → return JSONB result.
/// </summary>
public abstract class DbServiceBase(NpgsqlDataSource dataSource)
{
    protected NpgsqlDataSource DataSource { get; } = dataSource;

    /// <summary>Calls a void PG function.</summary>
    protected async Task ExecAsync(string sql, object? param = null)
    {
        await using var conn = await DataSource.OpenConnectionAsync();
        try
        {
            await conn.ExecuteAsync(sql, param);
        }
        catch (PostgresException ex)
        {
            throw new InvalidOperationException(ex.MessageText);
        }
    }

    /// <summary>Calls a PG function that returns JSONB → deserialises to JsonElement.</summary>
    protected async Task<JsonElement> QueryJsonAsync(string sql, object? param = null)
    {
        await using var conn = await DataSource.OpenConnectionAsync();
        try
        {
            var raw = await conn.QuerySingleAsync<string>(sql, param);
            return JsonDocument.Parse(raw ?? "{}").RootElement;
        }
        catch (PostgresException ex)
        {
            throw new InvalidOperationException(ex.MessageText);
        }
    }

    /// <summary>Calls a PG function that returns a scalar (UUID, INT, BOOL).</summary>
    protected async Task<T> QueryScalarAsync<T>(string sql, object? param = null)
    {
        await using var conn = await DataSource.OpenConnectionAsync();
        try
        {
            return await conn.ExecuteScalarAsync<T>(sql, param)
                   ?? throw new InvalidOperationException("NULL returned from DB");
        }
        catch (PostgresException ex)
        {
            throw new InvalidOperationException(ex.MessageText);
        }
    }

    /// <summary>Extracts IP from HttpContext for audit logging.</summary>
    protected static string? GetIp(IHttpContextAccessor http)
        => http.HttpContext?.Connection.RemoteIpAddress?.ToString();

    protected static string? GetUserAgent(IHttpContextAccessor http)
        => http.HttpContext?.Request.Headers.UserAgent.FirstOrDefault();
}
