using System.Text;
using System.Text.Json;

namespace admarkifyapi.Services;

public class EmailProviderService(HttpClient http)
{
    // ── MSG91 Email ────────────────────────────────────────────
    public async Task<string> CreateMsg91TemplateAsync(
        string endPoint, string authKey, JsonElement payload)
    {
        var request = new HttpRequestMessage(HttpMethod.Post, endPoint);

        request.Headers.Add("Accept",  "application/json");
        request.Headers.Add("authkey", authKey);
        request.Content = new StringContent(
            payload.ToString(), Encoding.UTF8, "application/json");

        var response = await http.SendAsync(request);
        var body     = await response.Content.ReadAsStringAsync();

        if (!response.IsSuccessStatusCode)
            throw new InvalidOperationException(
                $"MSG91 email template creation failed [{response.StatusCode}]: {body}");

        return body;
    }
}