using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public interface ITemplateService
{
    Task<JsonElement> CreateAsync(Guid orgId, Guid actorId, string name, string channel,
        string body, string? subject, Guid? providerConfigId, string? externalTemplateName);

    Task<JsonElement> UpdateAsync(Guid orgId, Guid actorId, Guid templateId,
        string? name, string? body, string? subject, Guid? providerConfigId);

    Task UpdateExternalAsync(Guid templateId, string? externalId,
        JsonElement providerPayload, JsonElement providerResponse);

    Task PublishAsync(Guid orgId, Guid actorId, Guid templateId);
    Task ArchiveAsync(Guid orgId, Guid actorId, Guid templateId);
    Task<JsonElement> GetAllAsync(Guid orgId, string? channel, string? status, Guid? providerConfigId);
}

public class TemplateService(NpgsqlDataSource ds) : DbServiceBase(ds), ITemplateService
{
    public Task<JsonElement> CreateAsync(Guid orgId, Guid actorId, string name, string channel,
        string body, string? subject, Guid? providerConfigId, string? externalTemplateName)
        => QueryJsonAsync(
            @"SELECT admarkify.fn_create_template(
                @orgId, @actorId, @name, @channel, @body,
                @subject, @providerConfigId, @externalTemplateName)",
            new { orgId, actorId, name, channel, body, subject, providerConfigId, externalTemplateName });

    public Task<JsonElement> UpdateAsync(Guid orgId, Guid actorId, Guid templateId,
        string? name, string? body, string? subject, Guid? providerConfigId)
        => QueryJsonAsync(
            @"SELECT admarkify.fn_update_template(
                @orgId, @actorId, @templateId, @name, @body, @subject, @providerConfigId)",
            new { orgId, actorId, templateId, name, body, subject, providerConfigId });

    public Task UpdateExternalAsync(Guid templateId, string? externalId,
        JsonElement providerPayload, JsonElement providerResponse)
        => ExecAsync(
            @"SELECT admarkify.fn_update_template_external(
                @templateId, @externalId, @providerPayload::jsonb, @providerResponse::jsonb)",
            new
            {
                templateId,
                externalId,
                providerPayload = providerPayload.ToString(),
                providerResponse = providerResponse.ToString()
            });

    public Task PublishAsync(Guid orgId, Guid actorId, Guid templateId)
        => ExecAsync(
            "SELECT admarkify.fn_publish_template(@orgId, @actorId, @templateId)",
            new { orgId, actorId, templateId });

    public Task ArchiveAsync(Guid orgId, Guid actorId, Guid templateId)
        => ExecAsync(
            "SELECT admarkify.fn_archive_template(@orgId, @actorId, @templateId)",
            new { orgId, actorId, templateId });

    public Task<JsonElement> GetAllAsync(Guid orgId, string? channel, string? status, Guid? providerConfigId)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_templates(@orgId, @channel, @status, @providerConfigId)",
            new { orgId, channel, status, providerConfigId });
}