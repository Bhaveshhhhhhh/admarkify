using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public class ProviderConfig
{
    public Guid Id { get; set; }
    public string Code { get; set; } = "";
    public string Label { get; set; } = "";
    public string Credentials { get; set; } = "";
    public string? Settings { get; set; }
}

public interface IIntegrationService
{
    Task<ProviderConfig> GetByIdAsync(Guid configId);
}

public class IntegrationService(NpgsqlDataSource ds) : DbServiceBase(ds), IIntegrationService
{
    public async Task<ProviderConfig> GetByIdAsync(Guid configId)
    {
        var json = await QueryJsonAsync(
            "SELECT admarkify.fn_get_provider_config(@configId)",
            new { configId });

        return new ProviderConfig
        {
            Id = json.GetProperty("id").GetGuid(),
            Code = json.GetProperty("code").GetString()!,
            Label = json.GetProperty("label").GetString()!,
            Credentials = json.GetProperty("credentials").GetString()!,
            Settings = json.TryGetProperty("settings", out var s) ? s.GetString() : null
        };
    }
}