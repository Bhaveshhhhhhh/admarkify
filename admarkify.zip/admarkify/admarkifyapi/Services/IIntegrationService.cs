using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

// ── Model ─────────────────────────────────────────────────────
public class ProviderConfig
{
    public Guid     ConfigId         { get; set; }
    public Guid     OrgId            { get; set; }
    public string   Label            { get; set; } = "";
    public string   Credentials      { get; set; } = "";
    public string?  Settings         { get; set; }
    public bool     IsDefault        { get; set; }
    public bool     IsActive         { get; set; }

    // from nested "provider" object
    public string   Code             { get; set; } = "";
    public string   Name             { get; set; } = "";
    public string   Channel          { get; set; } = "";
    public string?  EndPoint         { get; set; }
    public string?  ProvidersSchema  { get; set; }
    public string?  CredentialsSchema { get; set; }
}

// ── Interface ─────────────────────────────────────────────────
public interface IIntegrationService
{
    Task<ProviderConfig> GetByIdAsync(Guid configId);
}

// ── Implementation ────────────────────────────────────────────
public class IntegrationService(NpgsqlDataSource ds) : DbServiceBase(ds), IIntegrationService
{
    public async Task<ProviderConfig> GetByIdAsync(Guid configId)
    {
        var json = await QueryJsonAsync(
            "SELECT admarkify.fn_get_provider_config(@configId)",
            new { configId });

        // nested provider object
        var provider = json.GetProperty("provider");

        return new ProviderConfig
        {
            // ── from root ────────────────────────────────────
            ConfigId          = json.GetProperty("config_id").GetGuid(),
            OrgId             = json.GetProperty("org_id").GetGuid(),
            Label             = json.GetProperty("label").GetString()!,
            Credentials       = json.GetProperty("credentials").GetRawText(),
            Settings          = json.TryGetProperty("settings", out var s)
                                    ? s.GetRawText() : null,
            IsDefault         = json.GetProperty("is_default").GetBoolean(),
            IsActive          = json.GetProperty("is_active").GetBoolean(),
            ProvidersSchema   = json.TryGetProperty("providers_schema", out var ps)
                                    ? ps.GetRawText() : null,

            // ── from nested "provider" ────────────────────────
            Code              = provider.GetProperty("code").GetString()!,
            Name              = provider.GetProperty("name").GetString()!,
            Channel           = provider.GetProperty("channel").GetString()!,
            EndPoint          = provider.TryGetProperty("end_point", out var ep)
                                    ? ep.GetString() : null,
            CredentialsSchema = provider.TryGetProperty("credentials_schema", out var cs)
                                    ? cs.GetRawText() : null,
        };
    }
}