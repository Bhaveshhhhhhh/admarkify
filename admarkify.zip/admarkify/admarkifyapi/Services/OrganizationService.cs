using Npgsql;
using System.Text.Json;

namespace admarkifyapi.Services;

public interface IOrganizationService
{
    Task<Guid>        CreateAsync(Guid ownerUserId, string name, string slug, int planId, string timezone);
    Task<JsonElement> UpgradePlanAsync(Guid orgId, int newPlanId, DateTime? expiresAt);
}

public class OrganizationService(NpgsqlDataSource ds)
    : DbServiceBase(ds), IOrganizationService
{
    public Task<Guid> CreateAsync(Guid ownerUserId, string name, string slug, int planId, string timezone)
        => QueryScalarAsync<Guid>(
            "SELECT admarkify.fn_create_organization(@ownerUserId, @name, @slug, @planId, @timezone)",
            new { ownerUserId, name, slug, planId, timezone });

    public Task<JsonElement> UpgradePlanAsync(Guid orgId, int newPlanId, DateTime? expiresAt)
        => QueryJsonAsync(
            "SELECT admarkify.fn_upgrade_plan(@orgId, @newPlanId, @expiresAt)",
            new { orgId, newPlanId, expiresAt });
}
