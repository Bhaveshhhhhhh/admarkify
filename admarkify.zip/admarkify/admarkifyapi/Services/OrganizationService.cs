using Npgsql;
using System.Text.Json;
using admarkifyapi.Models.Requests;
namespace admarkifyapi.Services;

public interface IOrganizationService
{
    Task<Guid>        CreateAsync(Guid ownerUserId, string name, string slug, int planId, string timezone);
    Task<JsonElement> SearchAsync(SearchOrgRequest req);
    Task<JsonElement> UpgradePlanAsync(Guid orgId, int newPlanId, DateTime? expiresAt);
    
    Task<JsonElement> GetOrganizationDetailsAsync(Guid? orgId, string? slug);
    Task<JsonElement> GetAllPlansAsync(bool onlyActive);
}

public class OrganizationService(NpgsqlDataSource ds)
    : DbServiceBase(ds), IOrganizationService
{
    public Task<Guid> CreateAsync(Guid ownerUserId, string name, string slug, int planId, string timezone)
        => QueryScalarAsync<Guid>(
            "SELECT admarkify.fn_create_organization(@ownerUserId, @name, @slug, @planId, @timezone)",
            new { ownerUserId, name, slug, planId, timezone });

    public Task<JsonElement> SearchAsync(SearchOrgRequest req)
        => QueryJsonAsync(
            @"SELECT admarkify.fn_search_organizations(
                @p_search,
                @p_plan_id,
                @p_only_active,
                @p_page,
                @p_page_size,
                @p_sort_by,
                @p_sort_order
            )",
            new
            {
                p_search = req.Search,
                p_plan_id = req.PlanId,
                p_only_active = req.OnlyActive,
                p_page = req.Page,
                p_page_size = req.PageSize,
                p_sort_by = req.SortBy,
                p_sort_order = req.SortOrder
            });

    public Task<JsonElement> UpgradePlanAsync(Guid orgId, int newPlanId, DateTime? expiresAt)
        => QueryJsonAsync(
            "SELECT admarkify.fn_upgrade_plan(@orgId, @newPlanId, @expiresAt)",
            new { orgId, newPlanId, expiresAt });

    // ✅ NEW → Get Org Details
    public Task<JsonElement> GetOrganizationDetailsAsync(Guid? orgId, string? slug)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_organization_details(@p_org_id, @p_slug)",
            new { p_org_id = orgId, p_slug = slug });

    // ✅ NEW → Get Plans
    public Task<JsonElement> GetAllPlansAsync(bool onlyActive)
        => QueryJsonAsync(
            "SELECT admarkify.fn_get_all_plans(@p_only_active)",
            new { p_only_active = onlyActive });
}
