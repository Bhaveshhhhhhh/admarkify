using admarkifyapi.Services;
using Npgsql;

namespace admarkifyapi.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddAdmarkifyServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Npgsql data source — reused across requests (pooled)
        var connStr    = configuration.GetConnectionString("Postgres")!;
        var dataSource = NpgsqlDataSource.Create(connStr);
        services.AddSingleton(dataSource);

        services.AddScoped<IAuthService,         AuthService>();
        services.AddScoped<IOrganizationService, OrganizationService>();
        services.AddScoped<ITeamService,         TeamService>();
        services.AddScoped<IProviderService,     ProviderService>();
        services.AddScoped<ITemplateService,     TemplateService>();
        services.AddScoped<IIntegrationService,  IntegrationService>();

        // ── Typed HttpClients ──────────────────────────────────
        services.AddHttpClient<WhatsAppProviderService>();
        services.AddHttpClient<EmailProviderService>();      // ✅ replaces Msg91EmailService

        services.AddHttpContextAccessor();

        return services;
    }
}