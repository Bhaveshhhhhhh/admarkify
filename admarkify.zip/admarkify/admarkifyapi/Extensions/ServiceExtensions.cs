using admarkifyapi.Services;
using Npgsql;

namespace admarkifyapi.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddAdmarkifyServices(
        this IServiceCollection services,
        IConfiguration configuration)
    {
        // Npgsql data source — reused across requests (pooled)
        var connStr = configuration.GetConnectionString("Postgres")!;
        var dataSource = NpgsqlDataSource.Create(connStr);
        services.AddSingleton(dataSource);

        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<IOrganizationService, OrganizationService>();
        services.AddScoped<ITeamService, TeamService>();
        services.AddScoped<IProviderService, ProviderService>();
        services.AddScoped<ITemplateService, TemplateService>();
        services.AddScoped<IIntegrationService, IntegrationService>(); // ← added
        // HttpContextAccessor — used by middleware-downstream services
        services.AddHttpContextAccessor();

        return services;
    }
}